
<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="https://gmpg.org/xfn/11">
<script type="text/javascript">

	var isInIFrame = ( window.self !== window.top ) ? true : false;

	if(! isInIFrame ) {
		var jsData = ["showcase-cta","https:\/\/websitedemos.net\/learndash-academy-02\/wp-content\/plugins\/astra-sites-server\/admin\/showcase-cta\/switcher\/dist\/style-main.css?ver=308d53dc52d1fcf8ca1e"];
		var style = document.createElement('link');
		style.setAttribute('id', jsData[0]);
		style.setAttribute('rel', 'stylesheet');
		style.setAttribute('type', 'text/css');
		style.setAttribute('media', 'all');
		style.setAttribute('href', jsData[1]);

		document.head.appendChild(style);
	}
	</script>
<script type="text/javascript">

	var isInIFrame = ( window.self !== window.top ) ? true : false;

	if(! isInIFrame ) {
		var jsData = ["showcase-cta-google-fonts","\/\/fonts.googleapis.com\/css?family=DM%20Sans%3A400%2C500%2C700&subset=latin%2Clatin-ext"];
		var style = document.createElement('link');
		style.setAttribute('id', jsData[0]);
		style.setAttribute('rel', 'stylesheet');
		style.setAttribute('type', 'text/css');
		style.setAttribute('media', 'all');
		style.setAttribute('href', jsData[1]);

		document.head.appendChild(style);
	}
	</script>
<meta name="robots" content="noindex, nofollow" />

<title>Home - LearnDash Academy</title>
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="website" />
<meta property="og:title" content="Home - LearnDash Academy" />
<meta property="og:description" content="Learn from Industry Experts Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam maximus tortor at diam gravida posuere. Curabitur et malesuada mi. View All Courses Actionable Training Lorem ipsum dolor sit amet, consectetur adipiscing elit. Interesting Quizzes Lorem ipsum dolor sit amet, consectetur adipiscing elit. Premium Material Lorem ipsum dolor sit amet, consectetur adipiscing [&hellip;]" />
<meta property="og:url" content="https://websitedemos.net/learndash-academy-02/" />
<meta property="og:site_name" content="LearnDash Academy" />
<meta property="article:modified_time" content="2024-01-16T15:19:06+00:00" />
<meta property="og:image" content="https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/06/manager-free-img.png" />
<meta name="twitter:card" content="summary_large_image" />
<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebPage","@id":"https://websitedemos.net/learndash-academy-02/","url":"https://websitedemos.net/learndash-academy-02/","name":"Home - LearnDash Academy","isPartOf":{"@id":"https://websitedemos.net/learndash-academy-02/#website"},"about":{"@id":"https://websitedemos.net/learndash-academy-02/#organization"},"primaryImageOfPage":{"@id":"https://websitedemos.net/learndash-academy-02/#primaryimage"},"image":{"@id":"https://websitedemos.net/learndash-academy-02/#primaryimage"},"thumbnailUrl":"https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/06/manager-free-img.png","datePublished":"2018-11-19T19:50:38+00:00","dateModified":"2024-01-16T15:19:06+00:00","breadcrumb":{"@id":"https://websitedemos.net/learndash-academy-02/#breadcrumb"},"inLanguage":"en-US","potentialAction":[{"@type":"ReadAction","target":["https://websitedemos.net/learndash-academy-02/"]}]},{"@type":"ImageObject","inLanguage":"en-US","@id":"https://websitedemos.net/learndash-academy-02/#primaryimage","url":"https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/06/manager-free-img.png","contentUrl":"https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/06/manager-free-img.png","width":700,"height":700},{"@type":"BreadcrumbList","@id":"https://websitedemos.net/learndash-academy-02/#breadcrumb","itemListElement":[{"@type":"ListItem","position":1,"name":"Home"}]},{"@type":"WebSite","@id":"https://websitedemos.net/learndash-academy-02/#website","url":"https://websitedemos.net/learndash-academy-02/","name":"LearnDash Academy","description":"Online Learning Site","publisher":{"@id":"https://websitedemos.net/learndash-academy-02/#organization"},"potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://websitedemos.net/learndash-academy-02/?s={search_term_string}"},"query-input":"required name=search_term_string"}],"inLanguage":"en-US"},{"@type":"Organization","@id":"https://websitedemos.net/learndash-academy-02/#organization","name":"LearnDash Academy","url":"https://websitedemos.net/learndash-academy-02/","logo":{"@type":"ImageObject","inLanguage":"en-US","@id":"https://websitedemos.net/learndash-academy-02/#/schema/logo/image/","url":"https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/06/learn-dash-white-logo.svg","contentUrl":"https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/06/learn-dash-white-logo.svg","width":147,"height":43,"caption":"LearnDash Academy"},"image":{"@id":"https://websitedemos.net/learndash-academy-02/#/schema/logo/image/"}}]}</script>

<link rel="dns-prefetch" href="//stats.wp.com" />
<link rel="dns-prefetch" href="//fonts.googleapis.com" />
<link rel="alternate" type="application/rss+xml" title="LearnDash Academy &raquo; Feed" href="https://websitedemos.net/learndash-academy-02/feed/" />
<link rel="alternate" type="application/rss+xml" title="LearnDash Academy &raquo; Comments Feed" href="https://websitedemos.net/learndash-academy-02/comments/feed/" />
<script>
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/svg\/","svgExt":".svg","source":{"wpemoji":"https:\/\/websitedemos.net\/learndash-academy-02\/wp-includes\/js\/wp-emoji.js?ver=6.4.3","twemoji":"https:\/\/websitedemos.net\/learndash-academy-02\/wp-includes\/js\/twemoji.js?ver=6.4.3"}};
/**
 * @output wp-includes/js/wp-emoji-loader.js
 */

/**
 * Emoji Settings as exported in PHP via _print_emoji_detection_script().
 * @typedef WPEmojiSettings
 * @type {object}
 * @property {?object} source
 * @property {?string} source.concatemoji
 * @property {?string} source.twemoji
 * @property {?string} source.wpemoji
 * @property {?boolean} DOMReady
 * @property {?Function} readyCallback
 */

/**
 * Support tests.
 * @typedef SupportTests
 * @type {object}
 * @property {?boolean} flag
 * @property {?boolean} emoji
 */

/**
 * IIFE to detect emoji support and load Twemoji if needed.
 *
 * @param {Window} window
 * @param {Document} document
 * @param {WPEmojiSettings} settings
 */
( function wpEmojiLoader( window, document, settings ) {
	if ( typeof Promise === 'undefined' ) {
		return;
	}

	var sessionStorageKey = 'wpEmojiSettingsSupports';
	var tests = [ 'flag', 'emoji' ];

	/**
	 * Checks whether the browser supports offloading to a Worker.
	 *
	 * @since 6.3.0
	 *
	 * @private
	 *
	 * @returns {boolean}
	 */
	function supportsWorkerOffloading() {
		return (
			typeof Worker !== 'undefined' &&
			typeof OffscreenCanvas !== 'undefined' &&
			typeof URL !== 'undefined' &&
			URL.createObjectURL &&
			typeof Blob !== 'undefined'
		);
	}

	/**
	 * @typedef SessionSupportTests
	 * @type {object}
	 * @property {number} timestamp
	 * @property {SupportTests} supportTests
	 */

	/**
	 * Get support tests from session.
	 *
	 * @since 6.3.0
	 *
	 * @private
	 *
	 * @returns {?SupportTests} Support tests, or null if not set or older than 1 week.
	 */
	function getSessionSupportTests() {
		try {
			/** @type {SessionSupportTests} */
			var item = JSON.parse(
				sessionStorage.getItem( sessionStorageKey )
			);
			if (
				typeof item === 'object' &&
				typeof item.timestamp === 'number' &&
				new Date().valueOf() < item.timestamp + 604800 && // Note: Number is a week in seconds.
				typeof item.supportTests === 'object'
			) {
				return item.supportTests;
			}
		} catch ( e ) {}
		return null;
	}

	/**
	 * Persist the supports in session storage.
	 *
	 * @since 6.3.0
	 *
	 * @private
	 *
	 * @param {SupportTests} supportTests Support tests.
	 */
	function setSessionSupportTests( supportTests ) {
		try {
			/** @type {SessionSupportTests} */
			var item = {
				supportTests: supportTests,
				timestamp: new Date().valueOf()
			};

			sessionStorage.setItem(
				sessionStorageKey,
				JSON.stringify( item )
			);
		} catch ( e ) {}
	}

	/**
	 * Checks if two sets of Emoji characters render the same visually.
	 *
	 * This function may be serialized to run in a Worker. Therefore, it cannot refer to variables from the containing
	 * scope. Everything must be passed by parameters.
	 *
	 * @since 4.9.0
	 *
	 * @private
	 *
	 * @param {CanvasRenderingContext2D} context 2D Context.
	 * @param {string} set1 Set of Emoji to test.
	 * @param {string} set2 Set of Emoji to test.
	 *
	 * @return {boolean} True if the two sets render the same.
	 */
	function emojiSetsRenderIdentically( context, set1, set2 ) {
		// Cleanup from previous test.
		context.clearRect( 0, 0, context.canvas.width, context.canvas.height );
		context.fillText( set1, 0, 0 );
		var rendered1 = new Uint32Array(
			context.getImageData(
				0,
				0,
				context.canvas.width,
				context.canvas.height
			).data
		);

		// Cleanup from previous test.
		context.clearRect( 0, 0, context.canvas.width, context.canvas.height );
		context.fillText( set2, 0, 0 );
		var rendered2 = new Uint32Array(
			context.getImageData(
				0,
				0,
				context.canvas.width,
				context.canvas.height
			).data
		);

		return rendered1.every( function ( rendered2Data, index ) {
			return rendered2Data === rendered2[ index ];
		} );
	}

	/**
	 * Determines if the browser properly renders Emoji that Twemoji can supplement.
	 *
	 * This function may be serialized to run in a Worker. Therefore, it cannot refer to variables from the containing
	 * scope. Everything must be passed by parameters.
	 *
	 * @since 4.2.0
	 *
	 * @private
	 *
	 * @param {CanvasRenderingContext2D} context 2D Context.
	 * @param {string} type Whether to test for support of "flag" or "emoji".
	 * @param {Function} emojiSetsRenderIdentically Reference to emojiSetsRenderIdentically function, needed due to minification.
	 *
	 * @return {boolean} True if the browser can render emoji, false if it cannot.
	 */
	function browserSupportsEmoji( context, type, emojiSetsRenderIdentically ) {
		var isIdentical;

		switch ( type ) {
			case 'flag':
				/*
				 * Test for Transgender flag compatibility. Added in Unicode 13.
				 *
				 * To test for support, we try to render it, and compare the rendering to how it would look if
				 * the browser doesn't render it correctly (white flag emoji + transgender symbol).
				 */
				isIdentical = emojiSetsRenderIdentically(
					context,
					'\uD83C\uDFF3\uFE0F\u200D\u26A7\uFE0F', // as a zero-width joiner sequence
					'\uD83C\uDFF3\uFE0F\u200B\u26A7\uFE0F' // separated by a zero-width space
				);

				if ( isIdentical ) {
					return false;
				}

				/*
				 * Test for UN flag compatibility. This is the least supported of the letter locale flags,
				 * so gives us an easy test for full support.
				 *
				 * To test for support, we try to render it, and compare the rendering to how it would look if
				 * the browser doesn't render it correctly ([U] + [N]).
				 */
				isIdentical = emojiSetsRenderIdentically(
					context,
					'\uD83C\uDDFA\uD83C\uDDF3', // as the sequence of two code points
					'\uD83C\uDDFA\u200B\uD83C\uDDF3' // as the two code points separated by a zero-width space
				);

				if ( isIdentical ) {
					return false;
				}

				/*
				 * Test for English flag compatibility. England is a country in the United Kingdom, it
				 * does not have a two letter locale code but rather a five letter sub-division code.
				 *
				 * To test for support, we try to render it, and compare the rendering to how it would look if
				 * the browser doesn't render it correctly (black flag emoji + [G] + [B] + [E] + [N] + [G]).
				 */
				isIdentical = emojiSetsRenderIdentically(
					context,
					// as the flag sequence
					'\uD83C\uDFF4\uDB40\uDC67\uDB40\uDC62\uDB40\uDC65\uDB40\uDC6E\uDB40\uDC67\uDB40\uDC7F',
					// with each code point separated by a zero-width space
					'\uD83C\uDFF4\u200B\uDB40\uDC67\u200B\uDB40\uDC62\u200B\uDB40\uDC65\u200B\uDB40\uDC6E\u200B\uDB40\uDC67\u200B\uDB40\uDC7F'
				);

				return ! isIdentical;
			case 'emoji':
				/*
				 * Why can't we be friends? Everyone can now shake hands in emoji, regardless of skin tone!
				 *
				 * To test for Emoji 14.0 support, try to render a new emoji: Handshake: Light Skin Tone, Dark Skin Tone.
				 *
				 * The Handshake: Light Skin Tone, Dark Skin Tone emoji is a ZWJ sequence combining 🫱 Rightwards Hand,
				 * 🏻 Light Skin Tone, a Zero Width Joiner, 🫲 Leftwards Hand, and 🏿 Dark Skin Tone.
				 *
				 * 0x1FAF1 == Rightwards Hand
				 * 0x1F3FB == Light Skin Tone
				 * 0x200D == Zero-Width Joiner (ZWJ) that links the code points for the new emoji or
				 * 0x200B == Zero-Width Space (ZWS) that is rendered for clients not supporting the new emoji.
				 * 0x1FAF2 == Leftwards Hand
				 * 0x1F3FF == Dark Skin Tone.
				 *
				 * When updating this test for future Emoji releases, ensure that individual emoji that make up the
				 * sequence come from older emoji standards.
				 */
				isIdentical = emojiSetsRenderIdentically(
					context,
					'\uD83E\uDEF1\uD83C\uDFFB\u200D\uD83E\uDEF2\uD83C\uDFFF', // as the zero-width joiner sequence
					'\uD83E\uDEF1\uD83C\uDFFB\u200B\uD83E\uDEF2\uD83C\uDFFF' // separated by a zero-width space
				);

				return ! isIdentical;
		}

		return false;
	}

	/**
	 * Checks emoji support tests.
	 *
	 * This function may be serialized to run in a Worker. Therefore, it cannot refer to variables from the containing
	 * scope. Everything must be passed by parameters.
	 *
	 * @since 6.3.0
	 *
	 * @private
	 *
	 * @param {string[]} tests Tests.
	 * @param {Function} browserSupportsEmoji Reference to browserSupportsEmoji function, needed due to minification.
	 * @param {Function} emojiSetsRenderIdentically Reference to emojiSetsRenderIdentically function, needed due to minification.
	 *
	 * @return {SupportTests} Support tests.
	 */
	function testEmojiSupports( tests, browserSupportsEmoji, emojiSetsRenderIdentically ) {
		var canvas;
		if (
			typeof WorkerGlobalScope !== 'undefined' &&
			self instanceof WorkerGlobalScope
		) {
			canvas = new OffscreenCanvas( 300, 150 ); // Dimensions are default for HTMLCanvasElement.
		} else {
			canvas = document.createElement( 'canvas' );
		}

		var context = canvas.getContext( '2d', { willReadFrequently: true } );

		/*
		 * Chrome on OS X added native emoji rendering in M41. Unfortunately,
		 * it doesn't work when the font is bolder than 500 weight. So, we
		 * check for bold rendering support to avoid invisible emoji in Chrome.
		 */
		context.textBaseline = 'top';
		context.font = '600 32px Arial';

		var supports = {};
		tests.forEach( function ( test ) {
			supports[ test ] = browserSupportsEmoji( context, test, emojiSetsRenderIdentically );
		} );
		return supports;
	}

	/**
	 * Adds a script to the head of the document.
	 *
	 * @ignore
	 *
	 * @since 4.2.0
	 *
	 * @param {string} src The url where the script is located.
	 *
	 * @return {void}
	 */
	function addScript( src ) {
		var script = document.createElement( 'script' );
		script.src = src;
		script.defer = true;
		document.head.appendChild( script );
	}

	settings.supports = {
		everything: true,
		everythingExceptFlag: true
	};

	// Create a promise for DOMContentLoaded since the worker logic may finish after the event has fired.
	var domReadyPromise = new Promise( function ( resolve ) {
		document.addEventListener( 'DOMContentLoaded', resolve, {
			once: true
		} );
	} );

	// Obtain the emoji support from the browser, asynchronously when possible.
	new Promise( function ( resolve ) {
		var supportTests = getSessionSupportTests();
		if ( supportTests ) {
			resolve( supportTests );
			return;
		}

		if ( supportsWorkerOffloading() ) {
			try {
				// Note that the functions are being passed as arguments due to minification.
				var workerScript =
					'postMessage(' +
					testEmojiSupports.toString() +
					'(' +
					[
						JSON.stringify( tests ),
						browserSupportsEmoji.toString(),
						emojiSetsRenderIdentically.toString()
					].join( ',' ) +
					'));';
				var blob = new Blob( [ workerScript ], {
					type: 'text/javascript'
				} );
				var worker = new Worker( URL.createObjectURL( blob ), { name: 'wpTestEmojiSupports' } );
				worker.onmessage = function ( event ) {
					supportTests = event.data;
					setSessionSupportTests( supportTests );
					worker.terminate();
					resolve( supportTests );
				};
				return;
			} catch ( e ) {}
		}

		supportTests = testEmojiSupports( tests, browserSupportsEmoji, emojiSetsRenderIdentically );
		setSessionSupportTests( supportTests );
		resolve( supportTests );
	} )
		// Once the browser emoji support has been obtained from the session, finalize the settings.
		.then( function ( supportTests ) {
			/*
			 * Tests the browser support for flag emojis and other emojis, and adjusts the
			 * support settings accordingly.
			 */
			for ( var test in supportTests ) {
				settings.supports[ test ] = supportTests[ test ];

				settings.supports.everything =
					settings.supports.everything && settings.supports[ test ];

				if ( 'flag' !== test ) {
					settings.supports.everythingExceptFlag =
						settings.supports.everythingExceptFlag &&
						settings.supports[ test ];
				}
			}

			settings.supports.everythingExceptFlag =
				settings.supports.everythingExceptFlag &&
				! settings.supports.flag;

			// Sets DOMReady to false and assigns a ready function to settings.
			settings.DOMReady = false;
			settings.readyCallback = function () {
				settings.DOMReady = true;
			};
		} )
		.then( function () {
			return domReadyPromise;
		} )
		.then( function () {
			// When the browser can not render everything we need to load a polyfill.
			if ( ! settings.supports.everything ) {
				settings.readyCallback();

				var src = settings.source || {};

				if ( src.concatemoji ) {
					addScript( src.concatemoji );
				} else if ( src.wpemoji && src.twemoji ) {
					addScript( src.twemoji );
					addScript( src.wpemoji );
				}
			}
		} );
} )( window, document, window._wpemojiSettings );
</script>
<link rel="stylesheet" id="learndash_course_grid_bootstrap-css" href="https://websitedemos.net/learndash-academy-02/wp-content/plugins/learndash-course-grid/assets/css/bootstrap.css?ver=1.6.0" media="all" />
<link rel="stylesheet" id="learndash_course_grid_css-css" href="https://websitedemos.net/learndash-academy-02/wp-content/plugins/learndash-course-grid/assets/css/style.css?ver=1.6.0" media="all" />
<link rel="stylesheet" id="astra-theme-css-css" href="https://websitedemos.net/learndash-academy-02/wp-content/themes/astra/assets/css/minified/main.min.css?ver=4.6.4" media="all" />
<style id="astra-theme-css-inline-css">
:root{--ast-container-default-xlg-padding:6.67em;--ast-container-default-lg-padding:5.67em;--ast-container-default-slg-padding:4.34em;--ast-container-default-md-padding:3.34em;--ast-container-default-sm-padding:6.67em;--ast-container-default-xs-padding:2.4em;--ast-container-default-xxs-padding:1.4em;--ast-code-block-background:#EEEEEE;--ast-comment-inputs-background:#FAFAFA;--ast-normal-container-width:1200px;--ast-narrow-container-width:750px;--ast-blog-title-font-weight:normal;--ast-blog-meta-weight:inherit;}html{font-size:100%;}a,.page-title{color:var(--ast-global-color-0);}a:hover,a:focus{color:var(--ast-global-color-1);}body,button,input,select,textarea,.ast-button,.ast-custom-button{font-family:'Inter',sans-serif;font-weight:400;font-size:16px;font-size:1rem;}blockquote{color:var(--ast-global-color-3);}h1,.entry-content h1,h2,.entry-content h2,h3,.entry-content h3,h4,.entry-content h4,h5,.entry-content h5,h6,.entry-content h6,.site-title,.site-title a{font-family:'Inter',sans-serif;font-weight:700;}.ast-site-identity .site-title a{color:#ffffff;}.site-title{font-size:35px;font-size:2.1875rem;display:none;}header .custom-logo-link img{max-width:165px;}.astra-logo-svg{width:165px;}.site-header .site-description{font-size:15px;font-size:0.9375rem;display:none;}.entry-title{font-size:30px;font-size:1.875rem;}.archive .ast-article-post .ast-article-inner,.blog .ast-article-post .ast-article-inner,.archive .ast-article-post .ast-article-inner:hover,.blog .ast-article-post .ast-article-inner:hover{overflow:hidden;}h1,.entry-content h1{font-size:48px;font-size:3rem;font-weight:700;font-family:'Inter',sans-serif;line-height:1.2em;}h2,.entry-content h2{font-size:35px;font-size:2.1875rem;font-weight:700;font-family:'Inter',sans-serif;line-height:1.2em;}h3,.entry-content h3{font-size:20px;font-size:1.25rem;font-weight:700;font-family:'Inter',sans-serif;line-height:1.3em;}h4,.entry-content h4{font-size:18px;font-size:1.125rem;line-height:1.2em;font-weight:500;font-family:'Inter',sans-serif;}h5,.entry-content h5{font-size:16px;font-size:1rem;line-height:1.2em;font-family:'Inter',sans-serif;}h6,.entry-content h6{font-size:14px;font-size:0.875rem;line-height:1.25em;font-family:'Inter',sans-serif;}::selection{background-color:var(--ast-global-color-0);color:#ffffff;}body,h1,.entry-title a,.entry-content h1,h2,.entry-content h2,h3,.entry-content h3,h4,.entry-content h4,h5,.entry-content h5,h6,.entry-content h6{color:var(--ast-global-color-3);}.tagcloud a:hover,.tagcloud a:focus,.tagcloud a.current-item{color:#ffffff;border-color:var(--ast-global-color-0);background-color:var(--ast-global-color-0);}input:focus,input[type="text"]:focus,input[type="email"]:focus,input[type="url"]:focus,input[type="password"]:focus,input[type="reset"]:focus,input[type="search"]:focus,textarea:focus{border-color:var(--ast-global-color-0);}input[type="radio"]:checked,input[type=reset],input[type="checkbox"]:checked,input[type="checkbox"]:hover:checked,input[type="checkbox"]:focus:checked,input[type=range]::-webkit-slider-thumb{border-color:var(--ast-global-color-0);background-color:var(--ast-global-color-0);box-shadow:none;}.site-footer a:hover + .post-count,.site-footer a:focus + .post-count{background:var(--ast-global-color-0);border-color:var(--ast-global-color-0);}.single .nav-links .nav-previous,.single .nav-links .nav-next{color:var(--ast-global-color-0);}.entry-meta,.entry-meta *{line-height:1.45;color:var(--ast-global-color-0);}.entry-meta a:not(.ast-button):hover,.entry-meta a:not(.ast-button):hover *,.entry-meta a:not(.ast-button):focus,.entry-meta a:not(.ast-button):focus *,.page-links > .page-link,.page-links .page-link:hover,.post-navigation a:hover{color:var(--ast-global-color-1);}#cat option,.secondary .calendar_wrap thead a,.secondary .calendar_wrap thead a:visited{color:var(--ast-global-color-0);}.secondary .calendar_wrap #today,.ast-progress-val span{background:var(--ast-global-color-0);}.secondary a:hover + .post-count,.secondary a:focus + .post-count{background:var(--ast-global-color-0);border-color:var(--ast-global-color-0);}.calendar_wrap #today > a{color:#ffffff;}.page-links .page-link,.single .post-navigation a{color:var(--ast-global-color-0);}.ast-search-menu-icon .search-form button.search-submit{padding:0 4px;}.ast-search-menu-icon form.search-form{padding-right:0;}.ast-search-menu-icon.slide-search input.search-field{width:0;}.ast-header-search .ast-search-menu-icon.ast-dropdown-active .search-form,.ast-header-search .ast-search-menu-icon.ast-dropdown-active .search-field:focus{transition:all 0.2s;}.search-form input.search-field:focus{outline:none;}.wp-block-latest-posts > li > a{color:var(--ast-global-color-2);}.widget-title,.widget .wp-block-heading{font-size:22px;font-size:1.375rem;color:var(--ast-global-color-3);}.ast-search-menu-icon.slide-search a:focus-visible:focus-visible,.astra-search-icon:focus-visible,#close:focus-visible,a:focus-visible,.ast-menu-toggle:focus-visible,.site .skip-link:focus-visible,.wp-block-loginout input:focus-visible,.wp-block-search.wp-block-search__button-inside .wp-block-search__inside-wrapper,.ast-header-navigation-arrow:focus-visible,.woocommerce .wc-proceed-to-checkout > .checkout-button:focus-visible,.woocommerce .woocommerce-MyAccount-navigation ul li a:focus-visible,.ast-orders-table__row .ast-orders-table__cell:focus-visible,.woocommerce .woocommerce-order-details .order-again > .button:focus-visible,.woocommerce .woocommerce-message a.button.wc-forward:focus-visible,.woocommerce #minus_qty:focus-visible,.woocommerce #plus_qty:focus-visible,a#ast-apply-coupon:focus-visible,.woocommerce .woocommerce-info a:focus-visible,.woocommerce .astra-shop-summary-wrap a:focus-visible,.woocommerce a.wc-forward:focus-visible,#ast-apply-coupon:focus-visible,.woocommerce-js .woocommerce-mini-cart-item a.remove:focus-visible,#close:focus-visible,.button.search-submit:focus-visible,#search_submit:focus,.normal-search:focus-visible{outline-style:dotted;outline-color:inherit;outline-width:thin;}input:focus,input[type="text"]:focus,input[type="email"]:focus,input[type="url"]:focus,input[type="password"]:focus,input[type="reset"]:focus,input[type="search"]:focus,input[type="number"]:focus,textarea:focus,.wp-block-search__input:focus,[data-section="section-header-mobile-trigger"] .ast-button-wrap .ast-mobile-menu-trigger-minimal:focus,.ast-mobile-popup-drawer.active .menu-toggle-close:focus,.woocommerce-ordering select.orderby:focus,#ast-scroll-top:focus,#coupon_code:focus,.woocommerce-page #comment:focus,.woocommerce #reviews #respond input#submit:focus,.woocommerce a.add_to_cart_button:focus,.woocommerce .button.single_add_to_cart_button:focus,.woocommerce .woocommerce-cart-form button:focus,.woocommerce .woocommerce-cart-form__cart-item .quantity .qty:focus,.woocommerce .woocommerce-billing-fields .woocommerce-billing-fields__field-wrapper .woocommerce-input-wrapper > .input-text:focus,.woocommerce #order_comments:focus,.woocommerce #place_order:focus,.woocommerce .woocommerce-address-fields .woocommerce-address-fields__field-wrapper .woocommerce-input-wrapper > .input-text:focus,.woocommerce .woocommerce-MyAccount-content form button:focus,.woocommerce .woocommerce-MyAccount-content .woocommerce-EditAccountForm .woocommerce-form-row .woocommerce-Input.input-text:focus,.woocommerce .ast-woocommerce-container .woocommerce-pagination ul.page-numbers li a:focus,body #content .woocommerce form .form-row .select2-container--default .select2-selection--single:focus,#ast-coupon-code:focus,.woocommerce.woocommerce-js .quantity input[type=number]:focus,.woocommerce-js .woocommerce-mini-cart-item .quantity input[type=number]:focus,.woocommerce p#ast-coupon-trigger:focus{border-style:dotted;border-color:inherit;border-width:thin;}input{outline:none;}.woocommerce-js input[type=text]:focus,.woocommerce-js input[type=email]:focus,.woocommerce-js textarea:focus,input[type=number]:focus,.comments-area textarea#comment:focus,.comments-area textarea#comment:active,.comments-area .ast-comment-formwrap input[type="text"]:focus,.comments-area .ast-comment-formwrap input[type="text"]:active{outline-style:disable;outline-color:inherit;outline-width:thin;}.site-logo-img img{ transition:all 0.2s linear;}body .ast-oembed-container *{position:absolute;top:0;width:100%;height:100%;left:0;}body .wp-block-embed-pocket-casts .ast-oembed-container *{position:unset;}.ast-single-post-featured-section + article {margin-top: 2em;}.site-content .ast-single-post-featured-section img {width: 100%;overflow: hidden;object-fit: cover;}.site > .ast-single-related-posts-container {margin-top: 0;}@media (min-width: 922px) {.ast-desktop .ast-container--narrow {max-width: var(--ast-narrow-container-width);margin: 0 auto;}}.ast-page-builder-template .hentry {margin: 0;}.ast-page-builder-template .site-content > .ast-container {max-width: 100%;padding: 0;}.ast-page-builder-template .site .site-content #primary {padding: 0;margin: 0;}.ast-page-builder-template .no-results {text-align: center;margin: 4em auto;}.ast-page-builder-template .ast-pagination {padding: 2em;}.ast-page-builder-template .entry-header.ast-no-title.ast-no-thumbnail {margin-top: 0;}.ast-page-builder-template .entry-header.ast-header-without-markup {margin-top: 0;margin-bottom: 0;}.ast-page-builder-template .entry-header.ast-no-title.ast-no-meta {margin-bottom: 0;}.ast-page-builder-template.single .post-navigation {padding-bottom: 2em;}.ast-page-builder-template.single-post .site-content > .ast-container {max-width: 100%;}.ast-page-builder-template .entry-header {margin-top: 4em;margin-left: auto;margin-right: auto;padding-left: 20px;padding-right: 20px;}.single.ast-page-builder-template .entry-header {padding-left: 20px;padding-right: 20px;}.ast-page-builder-template .ast-archive-description {margin: 4em auto 0;padding-left: 20px;padding-right: 20px;}.ast-page-builder-template.ast-no-sidebar .entry-content .alignwide {margin-left: 0;margin-right: 0;}@media (max-width:921px){#ast-desktop-header{display:none;}}@media (min-width:922px){#ast-mobile-header{display:none;}}.wp-block-buttons.aligncenter{justify-content:center;}.ast-left-sidebar.ast-single-post #primary,.ast-right-sidebar.ast-single-post #primary,.ast-separate-container.ast-single-post.ast-right-sidebar #primary,.ast-separate-container.ast-single-post.ast-left-sidebar #primary,.ast-separate-container.ast-single-post #primary,.ast-narrow-container.ast-single-post #primary{padding-left:40px;padding-right:40px;}.wp-block-buttons .wp-block-button.is-style-outline .wp-block-button__link.wp-element-button,.ast-outline-button,.wp-block-uagb-buttons-child .uagb-buttons-repeater.ast-outline-button{border-color:var(--ast-global-color-0);border-top-width:2px;border-right-width:2px;border-bottom-width:2px;border-left-width:2px;font-family:inherit;font-weight:500;font-size:15px;font-size:0.9375rem;line-height:1em;border-top-left-radius:50px;border-top-right-radius:50px;border-bottom-right-radius:50px;border-bottom-left-radius:50px;}.wp-block-button.is-style-outline .wp-block-button__link:hover,.wp-block-buttons .wp-block-button.is-style-outline .wp-block-button__link:focus,.wp-block-buttons .wp-block-button.is-style-outline > .wp-block-button__link:not(.has-text-color):hover,.wp-block-buttons .wp-block-button.wp-block-button__link.is-style-outline:not(.has-text-color):hover,.ast-outline-button:hover,.ast-outline-button:focus,.wp-block-uagb-buttons-child .uagb-buttons-repeater.ast-outline-button:hover,.wp-block-uagb-buttons-child .uagb-buttons-repeater.ast-outline-button:focus{background-color:var(--ast-global-color-1);}.wp-block-button .wp-block-button__link.wp-element-button.is-style-outline:not(.has-background),.wp-block-button.is-style-outline>.wp-block-button__link.wp-element-button:not(.has-background),.ast-outline-button{background-color:var(--ast-global-color-0);}.entry-content[ast-blocks-layout] > figure{margin-bottom:1em;}@media (max-width:921px){.ast-separate-container #primary,.ast-separate-container #secondary{padding:1.5em 0;}#primary,#secondary{padding:1.5em 0;margin:0;}.ast-left-sidebar #content > .ast-container{display:flex;flex-direction:column-reverse;width:100%;}.ast-separate-container .ast-article-post,.ast-separate-container .ast-article-single{padding:1.5em 2.14em;}.ast-author-box img.avatar{margin:20px 0 0 0;}}@media (min-width:922px){.ast-separate-container.ast-right-sidebar #primary,.ast-separate-container.ast-left-sidebar #primary{border:0;}.search-no-results.ast-separate-container #primary{margin-bottom:4em;}}.elementor-button-wrapper .elementor-button{border-style:solid;text-decoration:none;border-top-width:0;border-right-width:0;border-left-width:0;border-bottom-width:0;}body .elementor-button.elementor-size-sm,body .elementor-button.elementor-size-xs,body .elementor-button.elementor-size-md,body .elementor-button.elementor-size-lg,body .elementor-button.elementor-size-xl,body .elementor-button{border-top-left-radius:50px;border-top-right-radius:50px;border-bottom-right-radius:50px;border-bottom-left-radius:50px;padding-top:15px;padding-right:40px;padding-bottom:16px;padding-left:40px;}.elementor-button-wrapper .elementor-button{border-color:var(--ast-global-color-0);background-color:var(--ast-global-color-0);}.elementor-button-wrapper .elementor-button:hover,.elementor-button-wrapper .elementor-button:focus{color:#ffffff;background-color:var(--ast-global-color-1);border-color:var(--ast-global-color-1);}.wp-block-button .wp-block-button__link ,.elementor-button-wrapper .elementor-button,.elementor-button-wrapper .elementor-button:visited{color:#ffffff;}.elementor-button-wrapper .elementor-button{font-weight:500;font-size:15px;font-size:0.9375rem;line-height:1em;}body .elementor-button.elementor-size-sm,body .elementor-button.elementor-size-xs,body .elementor-button.elementor-size-md,body .elementor-button.elementor-size-lg,body .elementor-button.elementor-size-xl,body .elementor-button{font-size:15px;font-size:0.9375rem;}.wp-block-button .wp-block-button__link:hover,.wp-block-button .wp-block-button__link:focus{color:#ffffff;background-color:var(--ast-global-color-1);border-color:var(--ast-global-color-1);}.elementor-widget-heading h1.elementor-heading-title{line-height:1.2em;}.elementor-widget-heading h2.elementor-heading-title{line-height:1.2em;}.elementor-widget-heading h3.elementor-heading-title{line-height:1.3em;}.elementor-widget-heading h4.elementor-heading-title{line-height:1.2em;}.elementor-widget-heading h5.elementor-heading-title{line-height:1.2em;}.elementor-widget-heading h6.elementor-heading-title{line-height:1.25em;}.wp-block-button .wp-block-button__link,.wp-block-search .wp-block-search__button,body .wp-block-file .wp-block-file__button{border-color:var(--ast-global-color-0);background-color:var(--ast-global-color-0);color:#ffffff;font-family:inherit;font-weight:500;line-height:1em;font-size:15px;font-size:0.9375rem;border-top-left-radius:50px;border-top-right-radius:50px;border-bottom-right-radius:50px;border-bottom-left-radius:50px;padding-top:15px;padding-right:40px;padding-bottom:16px;padding-left:40px;}.menu-toggle,button,.ast-button,.ast-custom-button,.button,input#submit,input[type="button"],input[type="submit"],input[type="reset"],form[CLASS*="wp-block-search__"].wp-block-search .wp-block-search__inside-wrapper .wp-block-search__button,body .wp-block-file .wp-block-file__button,.woocommerce-js a.button,.woocommerce button.button,.woocommerce .woocommerce-message a.button,.woocommerce #respond input#submit.alt,.woocommerce input.button.alt,.woocommerce input.button,.woocommerce input.button:disabled,.woocommerce input.button:disabled[disabled],.woocommerce input.button:disabled:hover,.woocommerce input.button:disabled[disabled]:hover,.woocommerce #respond input#submit,.woocommerce button.button.alt.disabled,.wc-block-grid__products .wc-block-grid__product .wp-block-button__link,.wc-block-grid__product-onsale,[CLASS*="wc-block"] button,.woocommerce-js .astra-cart-drawer .astra-cart-drawer-content .woocommerce-mini-cart__buttons .button:not(.checkout):not(.ast-continue-shopping),.woocommerce-js .astra-cart-drawer .astra-cart-drawer-content .woocommerce-mini-cart__buttons a.checkout,.woocommerce button.button.alt.disabled.wc-variation-selection-needed,[CLASS*="wc-block"] .wc-block-components-button{border-style:solid;border-top-width:0;border-right-width:0;border-left-width:0;border-bottom-width:0;color:#ffffff;border-color:var(--ast-global-color-0);background-color:var(--ast-global-color-0);padding-top:15px;padding-right:40px;padding-bottom:16px;padding-left:40px;font-family:inherit;font-weight:500;font-size:15px;font-size:0.9375rem;line-height:1em;border-top-left-radius:50px;border-top-right-radius:50px;border-bottom-right-radius:50px;border-bottom-left-radius:50px;}button:focus,.menu-toggle:hover,button:hover,.ast-button:hover,.ast-custom-button:hover .button:hover,.ast-custom-button:hover ,input[type=reset]:hover,input[type=reset]:focus,input#submit:hover,input#submit:focus,input[type="button"]:hover,input[type="button"]:focus,input[type="submit"]:hover,input[type="submit"]:focus,form[CLASS*="wp-block-search__"].wp-block-search .wp-block-search__inside-wrapper .wp-block-search__button:hover,form[CLASS*="wp-block-search__"].wp-block-search .wp-block-search__inside-wrapper .wp-block-search__button:focus,body .wp-block-file .wp-block-file__button:hover,body .wp-block-file .wp-block-file__button:focus,.woocommerce-js a.button:hover,.woocommerce button.button:hover,.woocommerce .woocommerce-message a.button:hover,.woocommerce #respond input#submit:hover,.woocommerce #respond input#submit.alt:hover,.woocommerce input.button.alt:hover,.woocommerce input.button:hover,.woocommerce button.button.alt.disabled:hover,.wc-block-grid__products .wc-block-grid__product .wp-block-button__link:hover,[CLASS*="wc-block"] button:hover,.woocommerce-js .astra-cart-drawer .astra-cart-drawer-content .woocommerce-mini-cart__buttons .button:not(.checkout):not(.ast-continue-shopping):hover,.woocommerce-js .astra-cart-drawer .astra-cart-drawer-content .woocommerce-mini-cart__buttons a.checkout:hover,.woocommerce button.button.alt.disabled.wc-variation-selection-needed:hover,[CLASS*="wc-block"] .wc-block-components-button:hover,[CLASS*="wc-block"] .wc-block-components-button:focus{color:#ffffff;background-color:var(--ast-global-color-1);border-color:var(--ast-global-color-1);}@media (max-width:921px){.ast-mobile-header-stack .main-header-bar .ast-search-menu-icon{display:inline-block;}.ast-header-break-point.ast-header-custom-item-outside .ast-mobile-header-stack .main-header-bar .ast-search-icon{margin:0;}.ast-comment-avatar-wrap img{max-width:2.5em;}.ast-comment-meta{padding:0 1.8888em 1.3333em;}.ast-separate-container .ast-comment-list li.depth-1{padding:1.5em 2.14em;}.ast-separate-container .comment-respond{padding:2em 2.14em;}}@media (min-width:544px){.ast-container{max-width:100%;}}@media (max-width:544px){.ast-separate-container .ast-article-post,.ast-separate-container .ast-article-single,.ast-separate-container .comments-title,.ast-separate-container .ast-archive-description{padding:1.5em 1em;}.ast-separate-container #content .ast-container{padding-left:0.54em;padding-right:0.54em;}.ast-separate-container .ast-comment-list .bypostauthor{padding:.5em;}.ast-search-menu-icon.ast-dropdown-active .search-field{width:170px;}}body,.ast-separate-container{background-color:var(--ast-global-color-4);;background-image:none;;}@media (max-width:921px){.site-title{display:none;}.site-header .site-description{display:none;}h1,.entry-content h1{font-size:30px;}h2,.entry-content h2{font-size:25px;}h3,.entry-content h3{font-size:20px;}}@media (max-width:544px){.site-title{display:none;}.site-header .site-description{display:none;}h1,.entry-content h1{font-size:22px;}h2,.entry-content h2{font-size:25px;}h3,.entry-content h3{font-size:20px;}header .custom-logo-link img,.ast-header-break-point .site-branding img,.ast-header-break-point .custom-logo-link img{max-width:90px;}.astra-logo-svg{width:90px;}.ast-header-break-point .site-logo-img .custom-mobile-logo-link img{max-width:90px;}}@media (max-width:921px){html{font-size:91.2%;}}@media (max-width:544px){html{font-size:91.2%;}}@media (min-width:922px){.ast-container{max-width:1240px;}}@media (min-width:922px){.site-content .ast-container{display:flex;}}@media (max-width:921px){.site-content .ast-container{flex-direction:column;}}@media (min-width:922px){.main-header-menu .sub-menu .menu-item.ast-left-align-sub-menu:hover > .sub-menu,.main-header-menu .sub-menu .menu-item.ast-left-align-sub-menu.focus > .sub-menu{margin-left:-0px;}}.ast-theme-transparent-header [data-section="section-header-mobile-trigger"] .ast-button-wrap .ast-mobile-menu-trigger-fill,.ast-theme-transparent-header [data-section="section-header-mobile-trigger"] .ast-button-wrap .ast-mobile-menu-trigger-minimal{border:none;}.site .comments-area{padding-bottom:3em;}.wp-block-file {display: flex;align-items: center;flex-wrap: wrap;justify-content: space-between;}.wp-block-pullquote {border: none;}.wp-block-pullquote blockquote::before {content: "\201D";font-family: "Helvetica",sans-serif;display: flex;transform: rotate( 180deg );font-size: 6rem;font-style: normal;line-height: 1;font-weight: bold;align-items: center;justify-content: center;}.has-text-align-right > blockquote::before {justify-content: flex-start;}.has-text-align-left > blockquote::before {justify-content: flex-end;}figure.wp-block-pullquote.is-style-solid-color blockquote {max-width: 100%;text-align: inherit;}html body {--wp--custom--ast-default-block-top-padding: 3em;--wp--custom--ast-default-block-right-padding: 3em;--wp--custom--ast-default-block-bottom-padding: 3em;--wp--custom--ast-default-block-left-padding: 3em;--wp--custom--ast-container-width: 1200px;--wp--custom--ast-content-width-size: 1200px;--wp--custom--ast-wide-width-size: calc(1200px + var(--wp--custom--ast-default-block-left-padding) + var(--wp--custom--ast-default-block-right-padding));}.ast-narrow-container {--wp--custom--ast-content-width-size: 750px;--wp--custom--ast-wide-width-size: 750px;}@media(max-width: 921px) {html body {--wp--custom--ast-default-block-top-padding: 3em;--wp--custom--ast-default-block-right-padding: 2em;--wp--custom--ast-default-block-bottom-padding: 3em;--wp--custom--ast-default-block-left-padding: 2em;}}@media(max-width: 544px) {html body {--wp--custom--ast-default-block-top-padding: 3em;--wp--custom--ast-default-block-right-padding: 1.5em;--wp--custom--ast-default-block-bottom-padding: 3em;--wp--custom--ast-default-block-left-padding: 1.5em;}}.entry-content > .wp-block-group,.entry-content > .wp-block-cover,.entry-content > .wp-block-columns {padding-top: var(--wp--custom--ast-default-block-top-padding);padding-right: var(--wp--custom--ast-default-block-right-padding);padding-bottom: var(--wp--custom--ast-default-block-bottom-padding);padding-left: var(--wp--custom--ast-default-block-left-padding);}.ast-plain-container.ast-no-sidebar .entry-content > .alignfull,.ast-page-builder-template .ast-no-sidebar .entry-content > .alignfull {margin-left: calc( -50vw + 50%);margin-right: calc( -50vw + 50%);max-width: 100vw;width: 100vw;}.ast-plain-container.ast-no-sidebar .entry-content .alignfull .alignfull,.ast-page-builder-template.ast-no-sidebar .entry-content .alignfull .alignfull,.ast-plain-container.ast-no-sidebar .entry-content .alignfull .alignwide,.ast-page-builder-template.ast-no-sidebar .entry-content .alignfull .alignwide,.ast-plain-container.ast-no-sidebar .entry-content .alignwide .alignfull,.ast-page-builder-template.ast-no-sidebar .entry-content .alignwide .alignfull,.ast-plain-container.ast-no-sidebar .entry-content .alignwide .alignwide,.ast-page-builder-template.ast-no-sidebar .entry-content .alignwide .alignwide,.ast-plain-container.ast-no-sidebar .entry-content .wp-block-column .alignfull,.ast-page-builder-template.ast-no-sidebar .entry-content .wp-block-column .alignfull,.ast-plain-container.ast-no-sidebar .entry-content .wp-block-column .alignwide,.ast-page-builder-template.ast-no-sidebar .entry-content .wp-block-column .alignwide {margin-left: auto;margin-right: auto;width: 100%;}[ast-blocks-layout] .wp-block-separator:not(.is-style-dots) {height: 0;}[ast-blocks-layout] .wp-block-separator {margin: 20px auto;}[ast-blocks-layout] .wp-block-separator:not(.is-style-wide):not(.is-style-dots) {max-width: 100px;}[ast-blocks-layout] .wp-block-separator.has-background {padding: 0;}.entry-content[ast-blocks-layout] > * {max-width: var(--wp--custom--ast-content-width-size);margin-left: auto;margin-right: auto;}.entry-content[ast-blocks-layout] > .alignwide {max-width: var(--wp--custom--ast-wide-width-size);}.entry-content[ast-blocks-layout] .alignfull {max-width: none;}.entry-content .wp-block-columns {margin-bottom: 0;}blockquote {margin: 1.5em;border-color: rgba(0,0,0,0.05);}.wp-block-quote:not(.has-text-align-right):not(.has-text-align-center) {border-left: 5px solid rgba(0,0,0,0.05);}.has-text-align-right > blockquote,blockquote.has-text-align-right {border-right: 5px solid rgba(0,0,0,0.05);}.has-text-align-left > blockquote,blockquote.has-text-align-left {border-left: 5px solid rgba(0,0,0,0.05);}.wp-block-site-tagline,.wp-block-latest-posts .read-more {margin-top: 15px;}.wp-block-loginout p label {display: block;}.wp-block-loginout p:not(.login-remember):not(.login-submit) input {width: 100%;}.wp-block-loginout input:focus {border-color: transparent;}.wp-block-loginout input:focus {outline: thin dotted;}.entry-content .wp-block-media-text .wp-block-media-text__content {padding: 0 0 0 8%;}.entry-content .wp-block-media-text.has-media-on-the-right .wp-block-media-text__content {padding: 0 8% 0 0;}.entry-content .wp-block-media-text.has-background .wp-block-media-text__content {padding: 8%;}.entry-content .wp-block-cover:not([class*="background-color"]) .wp-block-cover__inner-container,.entry-content .wp-block-cover:not([class*="background-color"]) .wp-block-cover-image-text,.entry-content .wp-block-cover:not([class*="background-color"]) .wp-block-cover-text,.entry-content .wp-block-cover-image:not([class*="background-color"]) .wp-block-cover__inner-container,.entry-content .wp-block-cover-image:not([class*="background-color"]) .wp-block-cover-image-text,.entry-content .wp-block-cover-image:not([class*="background-color"]) .wp-block-cover-text {color: var(--ast-global-color-5);}.wp-block-loginout .login-remember input {width: 1.1rem;height: 1.1rem;margin: 0 5px 4px 0;vertical-align: middle;}.wp-block-latest-posts > li > *:first-child,.wp-block-latest-posts:not(.is-grid) > li:first-child {margin-top: 0;}.wp-block-search__inside-wrapper .wp-block-search__input {padding: 0 10px;color: var(--ast-global-color-3);background: var(--ast-global-color-5);border-color: var(--ast-border-color);}.wp-block-latest-posts .read-more {margin-bottom: 1.5em;}.wp-block-search__no-button .wp-block-search__inside-wrapper .wp-block-search__input {padding-top: 5px;padding-bottom: 5px;}.wp-block-latest-posts .wp-block-latest-posts__post-date,.wp-block-latest-posts .wp-block-latest-posts__post-author {font-size: 1rem;}.wp-block-latest-posts > li > *,.wp-block-latest-posts:not(.is-grid) > li {margin-top: 12px;margin-bottom: 12px;}.ast-page-builder-template .entry-content[ast-blocks-layout] > *,.ast-page-builder-template .entry-content[ast-blocks-layout] > .alignfull > * {max-width: none;}.ast-page-builder-template .entry-content[ast-blocks-layout] > .alignwide > * {max-width: var(--wp--custom--ast-wide-width-size);}.ast-page-builder-template .entry-content[ast-blocks-layout] > .inherit-container-width > *,.ast-page-builder-template .entry-content[ast-blocks-layout] > * > *,.entry-content[ast-blocks-layout] > .wp-block-cover .wp-block-cover__inner-container {max-width: var(--wp--custom--ast-content-width-size);margin-left: auto;margin-right: auto;}.entry-content[ast-blocks-layout] .wp-block-cover:not(.alignleft):not(.alignright) {width: auto;}@media(max-width: 1200px) {.ast-separate-container .entry-content > .alignfull,.ast-separate-container .entry-content[ast-blocks-layout] > .alignwide,.ast-plain-container .entry-content[ast-blocks-layout] > .alignwide,.ast-plain-container .entry-content .alignfull {margin-left: calc(-1 * min(var(--ast-container-default-xlg-padding),20px)) ;margin-right: calc(-1 * min(var(--ast-container-default-xlg-padding),20px));}}@media(min-width: 1201px) {.ast-separate-container .entry-content > .alignfull {margin-left: calc(-1 * var(--ast-container-default-xlg-padding) );margin-right: calc(-1 * var(--ast-container-default-xlg-padding) );}.ast-separate-container .entry-content[ast-blocks-layout] > .alignwide,.ast-plain-container .entry-content[ast-blocks-layout] > .alignwide {margin-left: calc(-1 * var(--wp--custom--ast-default-block-left-padding) );margin-right: calc(-1 * var(--wp--custom--ast-default-block-right-padding) );}}@media(min-width: 921px) {.ast-separate-container .entry-content .wp-block-group.alignwide:not(.inherit-container-width) > :where(:not(.alignleft):not(.alignright)),.ast-plain-container .entry-content .wp-block-group.alignwide:not(.inherit-container-width) > :where(:not(.alignleft):not(.alignright)) {max-width: calc( var(--wp--custom--ast-content-width-size) + 80px );}.ast-plain-container.ast-right-sidebar .entry-content[ast-blocks-layout] .alignfull,.ast-plain-container.ast-left-sidebar .entry-content[ast-blocks-layout] .alignfull {margin-left: -60px;margin-right: -60px;}}@media(min-width: 544px) {.entry-content > .alignleft {margin-right: 20px;}.entry-content > .alignright {margin-left: 20px;}}@media (max-width:544px){.wp-block-columns .wp-block-column:not(:last-child){margin-bottom:20px;}.wp-block-latest-posts{margin:0;}}@media( max-width: 600px ) {.entry-content .wp-block-media-text .wp-block-media-text__content,.entry-content .wp-block-media-text.has-media-on-the-right .wp-block-media-text__content {padding: 8% 0 0;}.entry-content .wp-block-media-text.has-background .wp-block-media-text__content {padding: 8%;}}.ast-page-builder-template .entry-header {padding-left: 0;}.ast-narrow-container .site-content .wp-block-uagb-image--align-full .wp-block-uagb-image__figure {max-width: 100%;margin-left: auto;margin-right: auto;}:root .has-ast-global-color-0-color{color:var(--ast-global-color-0);}:root .has-ast-global-color-0-background-color{background-color:var(--ast-global-color-0);}:root .wp-block-button .has-ast-global-color-0-color{color:var(--ast-global-color-0);}:root .wp-block-button .has-ast-global-color-0-background-color{background-color:var(--ast-global-color-0);}:root .has-ast-global-color-1-color{color:var(--ast-global-color-1);}:root .has-ast-global-color-1-background-color{background-color:var(--ast-global-color-1);}:root .wp-block-button .has-ast-global-color-1-color{color:var(--ast-global-color-1);}:root .wp-block-button .has-ast-global-color-1-background-color{background-color:var(--ast-global-color-1);}:root .has-ast-global-color-2-color{color:var(--ast-global-color-2);}:root .has-ast-global-color-2-background-color{background-color:var(--ast-global-color-2);}:root .wp-block-button .has-ast-global-color-2-color{color:var(--ast-global-color-2);}:root .wp-block-button .has-ast-global-color-2-background-color{background-color:var(--ast-global-color-2);}:root .has-ast-global-color-3-color{color:var(--ast-global-color-3);}:root .has-ast-global-color-3-background-color{background-color:var(--ast-global-color-3);}:root .wp-block-button .has-ast-global-color-3-color{color:var(--ast-global-color-3);}:root .wp-block-button .has-ast-global-color-3-background-color{background-color:var(--ast-global-color-3);}:root .has-ast-global-color-4-color{color:var(--ast-global-color-4);}:root .has-ast-global-color-4-background-color{background-color:var(--ast-global-color-4);}:root .wp-block-button .has-ast-global-color-4-color{color:var(--ast-global-color-4);}:root .wp-block-button .has-ast-global-color-4-background-color{background-color:var(--ast-global-color-4);}:root .has-ast-global-color-5-color{color:var(--ast-global-color-5);}:root .has-ast-global-color-5-background-color{background-color:var(--ast-global-color-5);}:root .wp-block-button .has-ast-global-color-5-color{color:var(--ast-global-color-5);}:root .wp-block-button .has-ast-global-color-5-background-color{background-color:var(--ast-global-color-5);}:root .has-ast-global-color-6-color{color:var(--ast-global-color-6);}:root .has-ast-global-color-6-background-color{background-color:var(--ast-global-color-6);}:root .wp-block-button .has-ast-global-color-6-color{color:var(--ast-global-color-6);}:root .wp-block-button .has-ast-global-color-6-background-color{background-color:var(--ast-global-color-6);}:root .has-ast-global-color-7-color{color:var(--ast-global-color-7);}:root .has-ast-global-color-7-background-color{background-color:var(--ast-global-color-7);}:root .wp-block-button .has-ast-global-color-7-color{color:var(--ast-global-color-7);}:root .wp-block-button .has-ast-global-color-7-background-color{background-color:var(--ast-global-color-7);}:root .has-ast-global-color-8-color{color:var(--ast-global-color-8);}:root .has-ast-global-color-8-background-color{background-color:var(--ast-global-color-8);}:root .wp-block-button .has-ast-global-color-8-color{color:var(--ast-global-color-8);}:root .wp-block-button .has-ast-global-color-8-background-color{background-color:var(--ast-global-color-8);}:root{--ast-global-color-0:#0274be;--ast-global-color-1:#0d68ae;--ast-global-color-2:#2f3f50;--ast-global-color-3:#3a3a3a;--ast-global-color-4:#fafafa;--ast-global-color-5:#ffffff;--ast-global-color-6:#fbfcff;--ast-global-color-7:#003bb1;--ast-global-color-8:#BFD1FF;}:root {--ast-border-color : #dddddd;}.ast-single-entry-banner {-js-display: flex;display: flex;flex-direction: column;justify-content: center;text-align: center;position: relative;background: #eeeeee;}.ast-single-entry-banner[data-banner-layout="layout-1"] {max-width: 1200px;background: inherit;padding: 20px 0;}.ast-single-entry-banner[data-banner-width-type="custom"] {margin: 0 auto;width: 100%;}.ast-single-entry-banner + .site-content .entry-header {margin-bottom: 0;}.site .ast-author-avatar {--ast-author-avatar-size: ;}a.ast-underline-text {text-decoration: underline;}.ast-container > .ast-terms-link {position: relative;display: block;}a.ast-button.ast-badge-tax {padding: 4px 8px;border-radius: 3px;font-size: inherit;}header.entry-header .entry-title{font-size:22px;font-size:1.375rem;}header.entry-header > *:not(:last-child){margin-bottom:10px;}@media (max-width:921px){header.entry-header .entry-title{font-size:22px;font-size:1.375rem;}}@media (max-width:544px){header.entry-header .entry-title{font-size:20px;font-size:1.25rem;}}.ast-archive-entry-banner {-js-display: flex;display: flex;flex-direction: column;justify-content: center;text-align: center;position: relative;background: #eeeeee;}.ast-archive-entry-banner[data-banner-width-type="custom"] {margin: 0 auto;width: 100%;}.ast-archive-entry-banner[data-banner-layout="layout-1"] {background: inherit;padding: 20px 0;text-align: left;}body.archive .ast-archive-description{max-width:1200px;width:100%;text-align:left;padding-top:3em;padding-right:3em;padding-bottom:3em;padding-left:3em;}body.archive .ast-archive-description .ast-archive-title,body.archive .ast-archive-description .ast-archive-title *{font-size:40px;font-size:2.5rem;}body.archive .ast-archive-description > *:not(:last-child){margin-bottom:10px;}@media (max-width:921px){body.archive .ast-archive-description{text-align:left;}}@media (max-width:544px){body.archive .ast-archive-description{text-align:left;}}.ast-theme-transparent-header #masthead .site-logo-img .transparent-custom-logo .astra-logo-svg{width:165px;}.ast-theme-transparent-header #masthead .site-logo-img .transparent-custom-logo img{ max-width:165px;}@media (min-width:921px){.ast-theme-transparent-header #masthead{position:absolute;left:0;right:0;}.ast-theme-transparent-header .main-header-bar,.ast-theme-transparent-header.ast-header-break-point .main-header-bar{background:none;}body.elementor-editor-active.ast-theme-transparent-header #masthead,.fl-builder-edit .ast-theme-transparent-header #masthead,body.vc_editor.ast-theme-transparent-header #masthead,body.brz-ed.ast-theme-transparent-header #masthead{z-index:0;}.ast-header-break-point.ast-replace-site-logo-transparent.ast-theme-transparent-header .custom-mobile-logo-link{display:none;}.ast-header-break-point.ast-replace-site-logo-transparent.ast-theme-transparent-header .transparent-custom-logo{display:inline-block;}.ast-theme-transparent-header .ast-above-header,.ast-theme-transparent-header .ast-above-header.ast-above-header-bar{background-image:none;background-color:transparent;}.ast-theme-transparent-header .ast-below-header{background-image:none;background-color:transparent;}}.ast-theme-transparent-header .site-title a,.ast-theme-transparent-header .site-title a:focus,.ast-theme-transparent-header .site-title a:hover,.ast-theme-transparent-header .site-title a:visited{color:var(--ast-global-color-4);}.ast-theme-transparent-header .site-header .site-description{color:var(--ast-global-color-4);}.ast-theme-transparent-header .ast-builder-menu .main-header-menu,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .menu-link,.ast-theme-transparent-header [CLASS*="ast-builder-menu-"] .main-header-menu .menu-item > .menu-link,.ast-theme-transparent-header .ast-masthead-custom-menu-items,.ast-theme-transparent-header .ast-masthead-custom-menu-items a,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .menu-item > .ast-menu-toggle,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .menu-item > .ast-menu-toggle,.ast-theme-transparent-header .ast-above-header-navigation a,.ast-header-break-point.ast-theme-transparent-header .ast-above-header-navigation a,.ast-header-break-point.ast-theme-transparent-header .ast-above-header-navigation > ul.ast-above-header-menu > .menu-item-has-children:not(.current-menu-item) > .ast-menu-toggle,.ast-theme-transparent-header .ast-below-header-menu,.ast-theme-transparent-header .ast-below-header-menu a,.ast-header-break-point.ast-theme-transparent-header .ast-below-header-menu a,.ast-header-break-point.ast-theme-transparent-header .ast-below-header-menu,.ast-theme-transparent-header .main-header-menu .menu-link{color:var(--ast-global-color-4);}.ast-theme-transparent-header .ast-builder-menu .main-header-menu .menu-item:hover > .menu-link,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .menu-item:hover > .ast-menu-toggle,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .ast-masthead-custom-menu-items a:hover,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .focus > .menu-link,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .focus > .ast-menu-toggle,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .current-menu-item > .menu-link,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .current-menu-ancestor > .menu-link,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .current-menu-item > .ast-menu-toggle,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .current-menu-ancestor > .ast-menu-toggle,.ast-theme-transparent-header [CLASS*="ast-builder-menu-"] .main-header-menu .current-menu-item > .menu-link,.ast-theme-transparent-header [CLASS*="ast-builder-menu-"] .main-header-menu .current-menu-ancestor > .menu-link,.ast-theme-transparent-header [CLASS*="ast-builder-menu-"] .main-header-menu .current-menu-item > .ast-menu-toggle,.ast-theme-transparent-header [CLASS*="ast-builder-menu-"] .main-header-menu .current-menu-ancestor > .ast-menu-toggle,.ast-theme-transparent-header .main-header-menu .menu-item:hover > .menu-link,.ast-theme-transparent-header .main-header-menu .current-menu-item > .menu-link,.ast-theme-transparent-header .main-header-menu .current-menu-ancestor > .menu-link{color:var(--ast-global-color-4);}.ast-theme-transparent-header .ast-builder-menu .main-header-menu .menu-item .sub-menu .menu-link,.ast-theme-transparent-header .main-header-menu .menu-item .sub-menu .menu-link{background-color:transparent;}@media (max-width:921px){.ast-theme-transparent-header #masthead{position:absolute;left:0;right:0;}.ast-theme-transparent-header .main-header-bar,.ast-theme-transparent-header.ast-header-break-point .main-header-bar{background:none;}body.elementor-editor-active.ast-theme-transparent-header #masthead,.fl-builder-edit .ast-theme-transparent-header #masthead,body.vc_editor.ast-theme-transparent-header #masthead,body.brz-ed.ast-theme-transparent-header #masthead{z-index:0;}.ast-header-break-point.ast-replace-site-logo-transparent.ast-theme-transparent-header .custom-mobile-logo-link{display:none;}.ast-header-break-point.ast-replace-site-logo-transparent.ast-theme-transparent-header .transparent-custom-logo{display:inline-block;}.ast-theme-transparent-header .ast-above-header,.ast-theme-transparent-header .ast-above-header.ast-above-header-bar{background-image:none;background-color:transparent;}.ast-theme-transparent-header .ast-below-header{background-image:none;background-color:transparent;}}@media (max-width:921px){.ast-theme-transparent-header.ast-header-break-point .ast-builder-menu .main-header-menu,.ast-theme-transparent-header.ast-header-break-point .ast-builder-menu.main-header-menu .sub-menu,.ast-theme-transparent-header.ast-header-break-point .ast-builder-menu.main-header-menu,.ast-theme-transparent-header.ast-header-break-point .ast-builder-menu .main-header-bar-wrap .main-header-menu,.ast-flyout-menu-enable.ast-header-break-point.ast-theme-transparent-header .main-header-bar-navigation .site-navigation,.ast-fullscreen-menu-enable.ast-header-break-point.ast-theme-transparent-header .main-header-bar-navigation .site-navigation,.ast-flyout-above-menu-enable.ast-header-break-point.ast-theme-transparent-header .ast-above-header-navigation-wrap .ast-above-header-navigation,.ast-flyout-below-menu-enable.ast-header-break-point.ast-theme-transparent-header .ast-below-header-navigation-wrap .ast-below-header-actual-nav,.ast-fullscreen-above-menu-enable.ast-header-break-point.ast-theme-transparent-header .ast-above-header-navigation-wrap,.ast-fullscreen-below-menu-enable.ast-header-break-point.ast-theme-transparent-header .ast-below-header-navigation-wrap,.ast-theme-transparent-header .main-header-menu .menu-link{background-color:#ffffff;}.ast-theme-transparent-header .ast-builder-menu .main-header-menu .menu-item .sub-menu,.ast-header-break-point.ast-flyout-menu-enable.ast-header-break-point .ast-builder-menu .main-header-bar-navigation .main-header-menu .menu-item .sub-menu,.ast-theme-transparent-header.astra-hfb-header .ast-builder-menu [CLASS*="ast-builder-menu-"] .main-header-menu .menu-item .sub-menu,.ast-header-break-point.ast-flyout-menu-enable.astra-hfb-header .ast-builder-menu .main-header-bar-navigation [CLASS*="ast-builder-menu-"] .main-header-menu .menu-item .sub-menu,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .menu-item .sub-menu .menu-link,.ast-header-break-point.ast-flyout-menu-enable.ast-header-break-point .ast-builder-menu .main-header-bar-navigation .main-header-menu .menu-item .sub-menu .menu-link,.ast-theme-transparent-header.astra-hfb-header .ast-builder-menu [CLASS*="ast-builder-menu-"] .main-header-menu .menu-item .sub-menu .menu-link,.ast-header-break-point.ast-flyout-menu-enable.astra-hfb-header .ast-builder-menu .main-header-bar-navigation [CLASS*="ast-builder-menu-"] .main-header-menu .menu-item .sub-menu .menu-link,.ast-theme-transparent-header .main-header-menu .menu-item .sub-menu .menu-link,.ast-header-break-point.ast-flyout-menu-enable.ast-header-break-point .main-header-bar-navigation .main-header-menu .menu-item .sub-menu .menu-link,.ast-theme-transparent-header .main-header-menu .menu-item .sub-menu,.ast-header-break-point.ast-flyout-menu-enable.ast-header-break-point .main-header-bar-navigation .main-header-menu .menu-item .sub-menu{background-color:#ffffff;}.ast-theme-transparent-header .ast-builder-menu .main-header-menu,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .menu-link,.ast-theme-transparent-header [CLASS*="ast-builder-menu-"] .main-header-menu .menu-item > .menu-link,.ast-theme-transparent-header .ast-masthead-custom-menu-items,.ast-theme-transparent-header .ast-masthead-custom-menu-items a,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .menu-item > .ast-menu-toggle,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .menu-item > .ast-menu-toggle,.ast-theme-transparent-header .main-header-menu .menu-link{color:#2f3f50;}.ast-theme-transparent-header .ast-builder-menu .main-header-menu .menu-item:hover > .menu-link,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .menu-item:hover > .ast-menu-toggle,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .ast-masthead-custom-menu-items a:hover,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .focus > .menu-link,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .focus > .ast-menu-toggle,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .current-menu-item > .menu-link,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .current-menu-ancestor > .menu-link,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .current-menu-item > .ast-menu-toggle,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .current-menu-ancestor > .ast-menu-toggle,.ast-theme-transparent-header [CLASS*="ast-builder-menu-"] .main-header-menu .current-menu-item > .menu-link,.ast-theme-transparent-header [CLASS*="ast-builder-menu-"] .main-header-menu .current-menu-ancestor > .menu-link,.ast-theme-transparent-header [CLASS*="ast-builder-menu-"] .main-header-menu .current-menu-item > .ast-menu-toggle,.ast-theme-transparent-header [CLASS*="ast-builder-menu-"] .main-header-menu .current-menu-ancestor > .ast-menu-toggle,.ast-theme-transparent-header .main-header-menu .menu-item:hover > .menu-link,.ast-theme-transparent-header .main-header-menu .current-menu-item > .menu-link,.ast-theme-transparent-header .main-header-menu .current-menu-ancestor > .menu-link{color:#0984e3;}}@media (max-width:544px){.ast-theme-transparent-header.ast-header-break-point .ast-builder-menu .main-header-menu,.ast-theme-transparent-header.ast-header-break-point .ast-builder-menu.main-header-menu .sub-menu,.ast-theme-transparent-header.ast-header-break-point .ast-builder-menu.main-header-menu,.ast-theme-transparent-header.ast-header-break-point .ast-builder-menu .main-header-bar-wrap .main-header-menu,.ast-flyout-menu-enable.ast-header-break-point.ast-theme-transparent-header .main-header-bar-navigation .site-navigation,.ast-fullscreen-menu-enable.ast-header-break-point.ast-theme-transparent-header .main-header-bar-navigation .site-navigation,.ast-flyout-above-menu-enable.ast-header-break-point.ast-theme-transparent-header .ast-above-header-navigation-wrap .ast-above-header-navigation,.ast-flyout-below-menu-enable.ast-header-break-point.ast-theme-transparent-header .ast-below-header-navigation-wrap .ast-below-header-actual-nav,.ast-fullscreen-above-menu-enable.ast-header-break-point.ast-theme-transparent-header .ast-above-header-navigation-wrap,.ast-fullscreen-below-menu-enable.ast-header-break-point.ast-theme-transparent-header .ast-below-header-navigation-wrap,.ast-theme-transparent-header .main-header-menu .menu-link{background-color:#ffffff;}.ast-theme-transparent-header .ast-builder-menu .main-header-menu,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .menu-item > .menu-link,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .menu-link,.ast-theme-transparent-header .ast-masthead-custom-menu-items,.ast-theme-transparent-header .ast-masthead-custom-menu-items a,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .menu-item > .ast-menu-toggle,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .menu-item > .ast-menu-toggle,.ast-theme-transparent-header .main-header-menu .menu-link{color:#2f3f50;}.ast-theme-transparent-header .ast-builder-menu .main-header-menu .menu-item:hover > .menu-link,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .menu-item:hover > .ast-menu-toggle,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .ast-masthead-custom-menu-items a:hover,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .focus > .menu-link,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .focus > .ast-menu-toggle,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .current-menu-item > .menu-link,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .current-menu-ancestor > .menu-link,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .current-menu-item > .ast-menu-toggle,.ast-theme-transparent-header .ast-builder-menu .main-header-menu .current-menu-ancestor > .ast-menu-toggle,.ast-theme-transparent-header [CLASS*="ast-builder-menu-"] .main-header-menu .current-menu-item > .menu-link,.ast-theme-transparent-header [CLASS*="ast-builder-menu-"] .main-header-menu .current-menu-ancestor > .menu-link,.ast-theme-transparent-header [CLASS*="ast-builder-menu-"] .main-header-menu .current-menu-item > .ast-menu-toggle,.ast-theme-transparent-header [CLASS*="ast-builder-menu-"] .main-header-menu .current-menu-ancestor > .ast-menu-toggle,.ast-theme-transparent-header .main-header-menu .menu-item:hover > .menu-link,.ast-theme-transparent-header .main-header-menu .current-menu-item > .menu-link,.ast-theme-transparent-header .main-header-menu .current-menu-ancestor > .menu-link{color:#4a80ec;}}.ast-theme-transparent-header #ast-desktop-header > [CLASS*="-header-wrap"]:nth-last-child(2) > [CLASS*="-header-bar"],.ast-theme-transparent-header.ast-header-break-point #ast-mobile-header > [CLASS*="-header-wrap"]:nth-last-child(2) > [CLASS*="-header-bar"]{border-bottom-width:0;border-bottom-style:solid;}.ast-breadcrumbs .trail-browse,.ast-breadcrumbs .trail-items,.ast-breadcrumbs .trail-items li{display:inline-block;margin:0;padding:0;border:none;background:inherit;text-indent:0;text-decoration:none;}.ast-breadcrumbs .trail-browse{font-size:inherit;font-style:inherit;font-weight:inherit;color:inherit;}.ast-breadcrumbs .trail-items{list-style:none;}.trail-items li::after{padding:0 0.3em;content:"\00bb";}.trail-items li:last-of-type::after{display:none;}h1,.entry-content h1,h2,.entry-content h2,h3,.entry-content h3,h4,.entry-content h4,h5,.entry-content h5,h6,.entry-content h6{color:var(--ast-global-color-2);}@media (max-width:921px){.ast-builder-grid-row-container.ast-builder-grid-row-tablet-3-firstrow .ast-builder-grid-row > *:first-child,.ast-builder-grid-row-container.ast-builder-grid-row-tablet-3-lastrow .ast-builder-grid-row > *:last-child{grid-column:1 / -1;}}@media (max-width:544px){.ast-builder-grid-row-container.ast-builder-grid-row-mobile-3-firstrow .ast-builder-grid-row > *:first-child,.ast-builder-grid-row-container.ast-builder-grid-row-mobile-3-lastrow .ast-builder-grid-row > *:last-child{grid-column:1 / -1;}}.ast-builder-layout-element[data-section="title_tagline"]{display:flex;}@media (max-width:921px){.ast-header-break-point .ast-builder-layout-element[data-section="title_tagline"]{display:flex;}}@media (max-width:544px){.ast-header-break-point .ast-builder-layout-element[data-section="title_tagline"]{display:flex;}}.ast-builder-menu-1{font-family:inherit;font-weight:500;}.ast-builder-menu-1 .menu-item > .menu-link{font-size:15px;font-size:0.9375rem;color:var(--ast-global-color-3);}.ast-builder-menu-1 .menu-item > .ast-menu-toggle{color:var(--ast-global-color-3);}.ast-builder-menu-1 .menu-item:hover > .menu-link,.ast-builder-menu-1 .inline-on-mobile .menu-item:hover > .ast-menu-toggle{color:var(--ast-global-color-1);}.ast-builder-menu-1 .menu-item:hover > .ast-menu-toggle{color:var(--ast-global-color-1);}.ast-builder-menu-1 .menu-item.current-menu-item > .menu-link,.ast-builder-menu-1 .inline-on-mobile .menu-item.current-menu-item > .ast-menu-toggle,.ast-builder-menu-1 .current-menu-ancestor > .menu-link{color:var(--ast-global-color-1);}.ast-builder-menu-1 .menu-item.current-menu-item > .ast-menu-toggle{color:var(--ast-global-color-1);}.ast-builder-menu-1 .sub-menu,.ast-builder-menu-1 .inline-on-mobile .sub-menu{border-top-width:0;border-bottom-width:0;border-right-width:0;border-left-width:0;border-color:#adadad;border-style:solid;}.ast-builder-menu-1 .main-header-menu > .menu-item > .sub-menu,.ast-builder-menu-1 .main-header-menu > .menu-item > .astra-full-megamenu-wrapper{margin-top:0;}.ast-desktop .ast-builder-menu-1 .main-header-menu > .menu-item > .sub-menu:before,.ast-desktop .ast-builder-menu-1 .main-header-menu > .menu-item > .astra-full-megamenu-wrapper:before{height:calc( 0px + 5px );}.ast-desktop .ast-builder-menu-1 .menu-item .sub-menu .menu-link{border-bottom-width:1px;border-color:rgba(39,44,108,0.15);border-style:solid;}.ast-desktop .ast-builder-menu-1 .menu-item .sub-menu:last-child > .menu-item > .menu-link{border-bottom-width:1px;}.ast-desktop .ast-builder-menu-1 .menu-item:last-child > .menu-item > .menu-link{border-bottom-width:0;}@media (max-width:921px){.ast-header-break-point .ast-builder-menu-1 .main-header-menu .menu-item > .menu-link{padding-top:0px;padding-bottom:0px;padding-left:20px;padding-right:20px;}.ast-builder-menu-1 .main-header-menu .menu-item > .menu-link{color:#191a19;}.ast-builder-menu-1 .menu-item > .ast-menu-toggle{color:#191a19;}.ast-builder-menu-1 .menu-item:hover > .menu-link,.ast-builder-menu-1 .inline-on-mobile .menu-item:hover > .ast-menu-toggle{color:#4a80ec;}.ast-builder-menu-1 .menu-item:hover > .ast-menu-toggle{color:#4a80ec;}.ast-builder-menu-1 .menu-item.current-menu-item > .menu-link,.ast-builder-menu-1 .inline-on-mobile .menu-item.current-menu-item > .ast-menu-toggle,.ast-builder-menu-1 .current-menu-ancestor > .menu-link,.ast-builder-menu-1 .current-menu-ancestor > .ast-menu-toggle{color:#4a80ec;}.ast-builder-menu-1 .menu-item.current-menu-item > .ast-menu-toggle{color:#4a80ec;}.ast-header-break-point .ast-builder-menu-1 .menu-item.menu-item-has-children > .ast-menu-toggle{top:0px;right:calc( 20px - 0.907em );}.ast-builder-menu-1 .inline-on-mobile .menu-item.menu-item-has-children > .ast-menu-toggle{right:-15px;}.ast-builder-menu-1 .menu-item-has-children > .menu-link:after{content:unset;}.ast-builder-menu-1 .main-header-menu > .menu-item > .sub-menu,.ast-builder-menu-1 .main-header-menu > .menu-item > .astra-full-megamenu-wrapper{margin-top:0;}.ast-builder-menu-1 .main-header-menu,.ast-builder-menu-1 .main-header-menu .sub-menu{background-color:#ffffff;;background-image:none;;}}@media (max-width:544px){.ast-header-break-point .ast-builder-menu-1 .menu-item.menu-item-has-children > .ast-menu-toggle{top:0;}.ast-builder-menu-1 .main-header-menu > .menu-item > .sub-menu,.ast-builder-menu-1 .main-header-menu > .menu-item > .astra-full-megamenu-wrapper{margin-top:0;}}.ast-builder-menu-1{display:flex;}@media (max-width:921px){.ast-header-break-point .ast-builder-menu-1{display:flex;}}@media (max-width:544px){.ast-header-break-point .ast-builder-menu-1{display:flex;}}.site-below-footer-wrap{padding-top:20px;padding-bottom:20px;}.site-below-footer-wrap[data-section="section-below-footer-builder"]{background-color:;;background-image:none;;min-height:80px;border-style:solid;border-width:0px;border-top-width:1px;border-top-color:rgba(255,255,255,0.2);}.site-below-footer-wrap[data-section="section-below-footer-builder"] .ast-builder-grid-row{max-width:1200px;min-height:80px;margin-left:auto;margin-right:auto;}.site-below-footer-wrap[data-section="section-below-footer-builder"] .ast-builder-grid-row,.site-below-footer-wrap[data-section="section-below-footer-builder"] .site-footer-section{align-items:center;}.site-below-footer-wrap[data-section="section-below-footer-builder"].ast-footer-row-inline .site-footer-section{display:flex;margin-bottom:0;}.ast-builder-grid-row-full .ast-builder-grid-row{grid-template-columns:1fr;}@media (max-width:921px){.site-below-footer-wrap[data-section="section-below-footer-builder"].ast-footer-row-tablet-inline .site-footer-section{display:flex;margin-bottom:0;}.site-below-footer-wrap[data-section="section-below-footer-builder"].ast-footer-row-tablet-stack .site-footer-section{display:block;margin-bottom:10px;}.ast-builder-grid-row-container.ast-builder-grid-row-tablet-full .ast-builder-grid-row{grid-template-columns:1fr;}}@media (max-width:544px){.site-below-footer-wrap[data-section="section-below-footer-builder"].ast-footer-row-mobile-inline .site-footer-section{display:flex;margin-bottom:0;}.site-below-footer-wrap[data-section="section-below-footer-builder"].ast-footer-row-mobile-stack .site-footer-section{display:block;margin-bottom:10px;}.ast-builder-grid-row-container.ast-builder-grid-row-mobile-full .ast-builder-grid-row{grid-template-columns:1fr;}}.site-below-footer-wrap[data-section="section-below-footer-builder"]{padding-top:30px;padding-bottom:30px;padding-left:30px;padding-right:30px;}@media (max-width:921px){.site-below-footer-wrap[data-section="section-below-footer-builder"]{padding-top:30px;padding-bottom:30px;padding-left:25px;padding-right:25px;}}@media (max-width:544px){.site-below-footer-wrap[data-section="section-below-footer-builder"]{padding-top:30px;padding-bottom:30px;padding-left:20px;padding-right:20px;}}.site-below-footer-wrap[data-section="section-below-footer-builder"]{display:grid;}@media (max-width:921px){.ast-header-break-point .site-below-footer-wrap[data-section="section-below-footer-builder"]{display:grid;}}@media (max-width:544px){.ast-header-break-point .site-below-footer-wrap[data-section="section-below-footer-builder"]{display:grid;}}.ast-footer-copyright{text-align:center;}.ast-footer-copyright {color:var(--ast-global-color-5);}@media (max-width:921px){.ast-footer-copyright{text-align:center;}}@media (max-width:544px){.ast-footer-copyright{text-align:center;}}.ast-footer-copyright {font-size:16px;font-size:1rem;}@media (max-width:921px){.ast-footer-copyright {font-size:15px;font-size:0.9375rem;}}@media (max-width:544px){.ast-footer-copyright {font-size:15px;font-size:0.9375rem;}}.ast-footer-copyright.ast-builder-layout-element{display:flex;}@media (max-width:921px){.ast-header-break-point .ast-footer-copyright.ast-builder-layout-element{display:flex;}}@media (max-width:544px){.ast-header-break-point .ast-footer-copyright.ast-builder-layout-element{display:flex;}}.site-footer{background-color:var(--ast-global-color-1);;background-image:none;;}.site-primary-footer-wrap{padding-top:45px;padding-bottom:45px;}.site-primary-footer-wrap[data-section="section-primary-footer-builder"]{background-color:;;background-image:none;;}.site-primary-footer-wrap[data-section="section-primary-footer-builder"] .ast-builder-grid-row{max-width:1200px;margin-left:auto;margin-right:auto;}.site-primary-footer-wrap[data-section="section-primary-footer-builder"] .ast-builder-grid-row,.site-primary-footer-wrap[data-section="section-primary-footer-builder"] .site-footer-section{align-items:center;}.site-primary-footer-wrap[data-section="section-primary-footer-builder"].ast-footer-row-inline .site-footer-section{display:flex;margin-bottom:0;}.ast-builder-grid-row-3-cwide .ast-builder-grid-row{grid-template-columns:1fr 3fr 1fr;}@media (max-width:921px){.site-primary-footer-wrap[data-section="section-primary-footer-builder"].ast-footer-row-tablet-inline .site-footer-section{display:flex;margin-bottom:0;}.site-primary-footer-wrap[data-section="section-primary-footer-builder"].ast-footer-row-tablet-stack .site-footer-section{display:block;margin-bottom:10px;}.ast-builder-grid-row-container.ast-builder-grid-row-tablet-full .ast-builder-grid-row{grid-template-columns:1fr;}}@media (max-width:544px){.site-primary-footer-wrap[data-section="section-primary-footer-builder"].ast-footer-row-mobile-inline .site-footer-section{display:flex;margin-bottom:0;}.site-primary-footer-wrap[data-section="section-primary-footer-builder"].ast-footer-row-mobile-stack .site-footer-section{display:block;margin-bottom:10px;}.ast-builder-grid-row-container.ast-builder-grid-row-mobile-full .ast-builder-grid-row{grid-template-columns:1fr;}}.site-primary-footer-wrap[data-section="section-primary-footer-builder"]{padding-top:100px;padding-bottom:75px;padding-left:30px;padding-right:30px;}@media (max-width:921px){.site-primary-footer-wrap[data-section="section-primary-footer-builder"]{padding-top:80px;padding-bottom:60px;padding-left:25px;padding-right:25px;}}@media (max-width:544px){.site-primary-footer-wrap[data-section="section-primary-footer-builder"]{padding-top:80px;padding-bottom:60px;padding-left:20px;padding-right:20px;}}.site-primary-footer-wrap[data-section="section-primary-footer-builder"]{display:grid;}@media (max-width:921px){.ast-header-break-point .site-primary-footer-wrap[data-section="section-primary-footer-builder"]{display:grid;}}@media (max-width:544px){.ast-header-break-point .site-primary-footer-wrap[data-section="section-primary-footer-builder"]{display:grid;}}.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"].footer-widget-area-inner{text-align:center;}@media (max-width:921px){.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"].footer-widget-area-inner{text-align:center;}}@media (max-width:544px){.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"].footer-widget-area-inner{text-align:center;}}.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"].footer-widget-area-inner{color:var(--ast-global-color-4);}.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"] .widget-title,.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"] h1,.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"] .widget-area h1,.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"] h2,.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"] .widget-area h2,.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"] h3,.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"] .widget-area h3,.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"] h4,.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"] .widget-area h4,.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"] h5,.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"] .widget-area h5,.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"] h6,.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"] .widget-area h6{color:var(--ast-global-color-4);font-size:35px;font-size:2.1875rem;}@media (max-width:544px){.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"] .widget-title,.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"] h1,.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"] .widget-area h1,.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"] h2,.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"] .widget-area h2,.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"] h3,.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"] .widget-area h3,.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"] h4,.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"] .widget-area h4,.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"] h5,.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"] .widget-area h5,.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"] h6,.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"] .widget-area h6{font-size:32px;font-size:2rem;}}.footer-widget-area[data-section="sidebar-widgets-footer-widget-1"]{display:block;}@media (max-width:921px){.ast-header-break-point .footer-widget-area[data-section="sidebar-widgets-footer-widget-1"]{display:block;}}@media (max-width:544px){.ast-header-break-point .footer-widget-area[data-section="sidebar-widgets-footer-widget-1"]{display:block;}}.elementor-widget-heading .elementor-heading-title{margin:0;}.elementor-page .ast-menu-toggle{color:unset !important;background:unset !important;}.elementor-post.elementor-grid-item.hentry{margin-bottom:0;}.woocommerce div.product .elementor-element.elementor-products-grid .related.products ul.products li.product,.elementor-element .elementor-wc-products .woocommerce[class*='columns-'] ul.products li.product{width:auto;margin:0;float:none;}body .elementor hr{background-color:#ccc;margin:0;}.ast-left-sidebar .elementor-section.elementor-section-stretched,.ast-right-sidebar .elementor-section.elementor-section-stretched{max-width:100%;left:0 !important;}.elementor-template-full-width .ast-container{display:block;}.elementor-screen-only,.screen-reader-text,.screen-reader-text span,.ui-helper-hidden-accessible{top:0 !important;}@media (max-width:544px){.elementor-element .elementor-wc-products .woocommerce[class*="columns-"] ul.products li.product{width:auto;margin:0;}.elementor-element .woocommerce .woocommerce-result-count{float:none;}}.ast-header-break-point .main-header-bar{border-bottom-width:1px;border-bottom-color:#dbdee0;}@media (min-width:922px){.main-header-bar{border-bottom-width:1px;border-bottom-color:#dbdee0;}}.main-header-menu .menu-item, #astra-footer-menu .menu-item, .main-header-bar .ast-masthead-custom-menu-items{-js-display:flex;display:flex;-webkit-box-pack:center;-webkit-justify-content:center;-moz-box-pack:center;-ms-flex-pack:center;justify-content:center;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-direction:column;-moz-box-orient:vertical;-moz-box-direction:normal;-ms-flex-direction:column;flex-direction:column;}.main-header-menu > .menu-item > .menu-link, #astra-footer-menu > .menu-item > .menu-link{height:100%;-webkit-box-align:center;-webkit-align-items:center;-moz-box-align:center;-ms-flex-align:center;align-items:center;-js-display:flex;display:flex;}.header-main-layout-1 .ast-flex.main-header-container, .header-main-layout-3 .ast-flex.main-header-container{-webkit-align-content:center;-ms-flex-line-pack:center;align-content:center;-webkit-box-align:center;-webkit-align-items:center;-moz-box-align:center;-ms-flex-align:center;align-items:center;}.ast-header-break-point .main-navigation ul .menu-item .menu-link .icon-arrow:first-of-type svg{top:.2em;margin-top:0px;margin-left:0px;width:.65em;transform:translate(0, -2px) rotateZ(270deg);}.ast-mobile-popup-content .ast-submenu-expanded > .ast-menu-toggle{transform:rotateX(180deg);overflow-y:auto;}@media (min-width:922px){.ast-builder-menu .main-navigation > ul > li:last-child a{margin-right:0;}}.ast-separate-container .ast-article-inner{background-color:transparent;background-image:none;}.ast-separate-container .ast-article-post{background-color:var(--ast-global-color-5);;background-image:none;;}@media (max-width:921px){.ast-separate-container .ast-article-post{background-color:var(--ast-global-color-5);;background-image:none;;}}@media (max-width:544px){.ast-separate-container .ast-article-post{background-color:var(--ast-global-color-5);;background-image:none;;}}.ast-separate-container .ast-article-single:not(.ast-related-post), .woocommerce.ast-separate-container .ast-woocommerce-container, .ast-separate-container .error-404, .ast-separate-container .no-results, .single.ast-separate-container  .ast-author-meta, .ast-separate-container .related-posts-title-wrapper,.ast-separate-container .comments-count-wrapper, .ast-box-layout.ast-plain-container .site-content,.ast-padded-layout.ast-plain-container .site-content, .ast-separate-container .ast-archive-description, .ast-separate-container .comments-area .comment-respond, .ast-separate-container .comments-area .ast-comment-list li, .ast-separate-container .comments-area .comments-title{background-color:var(--ast-global-color-5);;background-image:none;;}@media (max-width:921px){.ast-separate-container .ast-article-single:not(.ast-related-post), .woocommerce.ast-separate-container .ast-woocommerce-container, .ast-separate-container .error-404, .ast-separate-container .no-results, .single.ast-separate-container  .ast-author-meta, .ast-separate-container .related-posts-title-wrapper,.ast-separate-container .comments-count-wrapper, .ast-box-layout.ast-plain-container .site-content,.ast-padded-layout.ast-plain-container .site-content, .ast-separate-container .ast-archive-description{background-color:var(--ast-global-color-5);;background-image:none;;}}@media (max-width:544px){.ast-separate-container .ast-article-single:not(.ast-related-post), .woocommerce.ast-separate-container .ast-woocommerce-container, .ast-separate-container .error-404, .ast-separate-container .no-results, .single.ast-separate-container  .ast-author-meta, .ast-separate-container .related-posts-title-wrapper,.ast-separate-container .comments-count-wrapper, .ast-box-layout.ast-plain-container .site-content,.ast-padded-layout.ast-plain-container .site-content, .ast-separate-container .ast-archive-description{background-color:var(--ast-global-color-5);;background-image:none;;}}.ast-separate-container.ast-two-container #secondary .widget{background-color:var(--ast-global-color-5);;background-image:none;;}@media (max-width:921px){.ast-separate-container.ast-two-container #secondary .widget{background-color:var(--ast-global-color-5);;background-image:none;;}}@media (max-width:544px){.ast-separate-container.ast-two-container #secondary .widget{background-color:var(--ast-global-color-5);;background-image:none;;}}.ast-mobile-header-content > *,.ast-desktop-header-content > * {padding: 10px 0;height: auto;}.ast-mobile-header-content > *:first-child,.ast-desktop-header-content > *:first-child {padding-top: 10px;}.ast-mobile-header-content > .ast-builder-menu,.ast-desktop-header-content > .ast-builder-menu {padding-top: 0;}.ast-mobile-header-content > *:last-child,.ast-desktop-header-content > *:last-child {padding-bottom: 0;}.ast-mobile-header-content .ast-search-menu-icon.ast-inline-search label,.ast-desktop-header-content .ast-search-menu-icon.ast-inline-search label {width: 100%;}.ast-desktop-header-content .main-header-bar-navigation .ast-submenu-expanded > .ast-menu-toggle::before {transform: rotateX(180deg);}#ast-desktop-header .ast-desktop-header-content,.ast-mobile-header-content .ast-search-icon,.ast-desktop-header-content .ast-search-icon,.ast-mobile-header-wrap .ast-mobile-header-content,.ast-main-header-nav-open.ast-popup-nav-open .ast-mobile-header-wrap .ast-mobile-header-content,.ast-main-header-nav-open.ast-popup-nav-open .ast-desktop-header-content {display: none;}.ast-main-header-nav-open.ast-header-break-point #ast-desktop-header .ast-desktop-header-content,.ast-main-header-nav-open.ast-header-break-point .ast-mobile-header-wrap .ast-mobile-header-content {display: block;}.ast-desktop .ast-desktop-header-content .astra-menu-animation-slide-up > .menu-item > .sub-menu,.ast-desktop .ast-desktop-header-content .astra-menu-animation-slide-up > .menu-item .menu-item > .sub-menu,.ast-desktop .ast-desktop-header-content .astra-menu-animation-slide-down > .menu-item > .sub-menu,.ast-desktop .ast-desktop-header-content .astra-menu-animation-slide-down > .menu-item .menu-item > .sub-menu,.ast-desktop .ast-desktop-header-content .astra-menu-animation-fade > .menu-item > .sub-menu,.ast-desktop .ast-desktop-header-content .astra-menu-animation-fade > .menu-item .menu-item > .sub-menu {opacity: 1;visibility: visible;}.ast-hfb-header.ast-default-menu-enable.ast-header-break-point .ast-mobile-header-wrap .ast-mobile-header-content .main-header-bar-navigation {width: unset;margin: unset;}.ast-mobile-header-content.content-align-flex-end .main-header-bar-navigation .menu-item-has-children > .ast-menu-toggle,.ast-desktop-header-content.content-align-flex-end .main-header-bar-navigation .menu-item-has-children > .ast-menu-toggle {left: calc( 20px - 0.907em);right: auto;}.ast-mobile-header-content .ast-search-menu-icon,.ast-mobile-header-content .ast-search-menu-icon.slide-search,.ast-desktop-header-content .ast-search-menu-icon,.ast-desktop-header-content .ast-search-menu-icon.slide-search {width: 100%;position: relative;display: block;right: auto;transform: none;}.ast-mobile-header-content .ast-search-menu-icon.slide-search .search-form,.ast-mobile-header-content .ast-search-menu-icon .search-form,.ast-desktop-header-content .ast-search-menu-icon.slide-search .search-form,.ast-desktop-header-content .ast-search-menu-icon .search-form {right: 0;visibility: visible;opacity: 1;position: relative;top: auto;transform: none;padding: 0;display: block;overflow: hidden;}.ast-mobile-header-content .ast-search-menu-icon.ast-inline-search .search-field,.ast-mobile-header-content .ast-search-menu-icon .search-field,.ast-desktop-header-content .ast-search-menu-icon.ast-inline-search .search-field,.ast-desktop-header-content .ast-search-menu-icon .search-field {width: 100%;padding-right: 5.5em;}.ast-mobile-header-content .ast-search-menu-icon .search-submit,.ast-desktop-header-content .ast-search-menu-icon .search-submit {display: block;position: absolute;height: 100%;top: 0;right: 0;padding: 0 1em;border-radius: 0;}.ast-hfb-header.ast-default-menu-enable.ast-header-break-point .ast-mobile-header-wrap .ast-mobile-header-content .main-header-bar-navigation ul .sub-menu .menu-link {padding-left: 30px;}.ast-hfb-header.ast-default-menu-enable.ast-header-break-point .ast-mobile-header-wrap .ast-mobile-header-content .main-header-bar-navigation .sub-menu .menu-item .menu-item .menu-link {padding-left: 40px;}.ast-mobile-popup-drawer.active .ast-mobile-popup-inner{background-color:#ffffff;;}.ast-mobile-header-wrap .ast-mobile-header-content, .ast-desktop-header-content{background-color:#ffffff;;}.ast-mobile-popup-content > *, .ast-mobile-header-content > *, .ast-desktop-popup-content > *, .ast-desktop-header-content > *{padding-top:0;padding-bottom:0;}.content-align-flex-start .ast-builder-layout-element{justify-content:flex-start;}.content-align-flex-start .main-header-menu{text-align:left;}.ast-mobile-popup-drawer.active .menu-toggle-close{color:#3a3a3a;}.ast-mobile-header-wrap .ast-primary-header-bar,.ast-primary-header-bar .site-primary-header-wrap{min-height:70px;}.ast-desktop .ast-primary-header-bar .main-header-menu > .menu-item{line-height:70px;}.ast-header-break-point #masthead .ast-mobile-header-wrap .ast-primary-header-bar,.ast-header-break-point #masthead .ast-mobile-header-wrap .ast-below-header-bar,.ast-header-break-point #masthead .ast-mobile-header-wrap .ast-above-header-bar{padding-left:20px;padding-right:20px;}.ast-header-break-point .ast-primary-header-bar{border-bottom-width:0;border-bottom-color:#dbdee0;border-bottom-style:solid;}@media (min-width:922px){.ast-primary-header-bar{border-bottom-width:0;border-bottom-color:#dbdee0;border-bottom-style:solid;}}.ast-primary-header-bar{background-color:var(--ast-global-color-0);;background-image:none;;}@media (max-width:921px){.ast-primary-header-bar.ast-primary-header{background-color:#272c6c;;background-image:none;;}}.ast-desktop .ast-primary-header-bar.main-header-bar, .ast-header-break-point #masthead .ast-primary-header-bar.main-header-bar{padding-top:10px;padding-bottom:10px;}@media (max-width:921px){.ast-desktop .ast-primary-header-bar.main-header-bar, .ast-header-break-point #masthead .ast-primary-header-bar.main-header-bar{padding-top:1em;padding-bottom:1em;}}@media (max-width:544px){.ast-desktop .ast-primary-header-bar.main-header-bar, .ast-header-break-point #masthead .ast-primary-header-bar.main-header-bar{padding-top:0.5em;padding-bottom:1em;}}.ast-primary-header-bar{display:block;}@media (max-width:921px){.ast-header-break-point .ast-primary-header-bar{display:grid;}}@media (max-width:544px){.ast-header-break-point .ast-primary-header-bar{display:grid;}}[data-section="section-header-mobile-trigger"] .ast-button-wrap .ast-mobile-menu-trigger-fill{color:var(--ast-global-color-2);border:none;background:var(--ast-global-color-5);}[data-section="section-header-mobile-trigger"] .ast-button-wrap .mobile-menu-toggle-icon .ast-mobile-svg{width:20px;height:20px;fill:var(--ast-global-color-2);}[data-section="section-header-mobile-trigger"] .ast-button-wrap .mobile-menu-wrap .mobile-menu{color:var(--ast-global-color-2);}:root{--e-global-color-astglobalcolor0:#0274be;--e-global-color-astglobalcolor1:#0d68ae;--e-global-color-astglobalcolor2:#2f3f50;--e-global-color-astglobalcolor3:#3a3a3a;--e-global-color-astglobalcolor4:#fafafa;--e-global-color-astglobalcolor5:#ffffff;--e-global-color-astglobalcolor6:#fbfcff;--e-global-color-astglobalcolor7:#003bb1;--e-global-color-astglobalcolor8:#BFD1FF;}
</style>
<link rel="stylesheet" id="astra-learndash-css" href="https://websitedemos.net/learndash-academy-02/wp-content/themes/astra/assets/css/minified/compatibility/learndash.min.css?ver=4.6.4" media="all" />
<style id="astra-google-fonts-css" media="all">/* cyrillic-ext */
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400;
  font-display: fallback;
  src: url(/fonts.gstatic.com/s/inter/v13/UcC73FwrK3iLTeHuS_fvQtMwCp50KnMa2JL7SUc.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400;
  font-display: fallback;
  src: url(/fonts.gstatic.com/s/inter/v13/UcC73FwrK3iLTeHuS_fvQtMwCp50KnMa0ZL7SUc.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400;
  font-display: fallback;
  src: url(/fonts.gstatic.com/s/inter/v13/UcC73FwrK3iLTeHuS_fvQtMwCp50KnMa2ZL7SUc.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400;
  font-display: fallback;
  src: url(/fonts.gstatic.com/s/inter/v13/UcC73FwrK3iLTeHuS_fvQtMwCp50KnMa1pL7SUc.woff2) format('woff2');
  unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400;
  font-display: fallback;
  src: url(/fonts.gstatic.com/s/inter/v13/UcC73FwrK3iLTeHuS_fvQtMwCp50KnMa2pL7SUc.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400;
  font-display: fallback;
  src: url(/fonts.gstatic.com/s/inter/v13/UcC73FwrK3iLTeHuS_fvQtMwCp50KnMa25L7SUc.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400;
  font-display: fallback;
  src: url(/fonts.gstatic.com/s/inter/v13/UcC73FwrK3iLTeHuS_fvQtMwCp50KnMa1ZL7.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 500;
  font-display: fallback;
  src: url(/fonts.gstatic.com/s/inter/v13/UcC73FwrK3iLTeHuS_fvQtMwCp50KnMa2JL7SUc.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 500;
  font-display: fallback;
  src: url(/fonts.gstatic.com/s/inter/v13/UcC73FwrK3iLTeHuS_fvQtMwCp50KnMa0ZL7SUc.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 500;
  font-display: fallback;
  src: url(/fonts.gstatic.com/s/inter/v13/UcC73FwrK3iLTeHuS_fvQtMwCp50KnMa2ZL7SUc.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 500;
  font-display: fallback;
  src: url(/fonts.gstatic.com/s/inter/v13/UcC73FwrK3iLTeHuS_fvQtMwCp50KnMa1pL7SUc.woff2) format('woff2');
  unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 500;
  font-display: fallback;
  src: url(/fonts.gstatic.com/s/inter/v13/UcC73FwrK3iLTeHuS_fvQtMwCp50KnMa2pL7SUc.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 500;
  font-display: fallback;
  src: url(/fonts.gstatic.com/s/inter/v13/UcC73FwrK3iLTeHuS_fvQtMwCp50KnMa25L7SUc.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 500;
  font-display: fallback;
  src: url(/fonts.gstatic.com/s/inter/v13/UcC73FwrK3iLTeHuS_fvQtMwCp50KnMa1ZL7.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 700;
  font-display: fallback;
  src: url(/fonts.gstatic.com/s/inter/v13/UcC73FwrK3iLTeHuS_fvQtMwCp50KnMa2JL7SUc.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 700;
  font-display: fallback;
  src: url(/fonts.gstatic.com/s/inter/v13/UcC73FwrK3iLTeHuS_fvQtMwCp50KnMa0ZL7SUc.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 700;
  font-display: fallback;
  src: url(/fonts.gstatic.com/s/inter/v13/UcC73FwrK3iLTeHuS_fvQtMwCp50KnMa2ZL7SUc.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 700;
  font-display: fallback;
  src: url(/fonts.gstatic.com/s/inter/v13/UcC73FwrK3iLTeHuS_fvQtMwCp50KnMa1pL7SUc.woff2) format('woff2');
  unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 700;
  font-display: fallback;
  src: url(/fonts.gstatic.com/s/inter/v13/UcC73FwrK3iLTeHuS_fvQtMwCp50KnMa2pL7SUc.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 700;
  font-display: fallback;
  src: url(/fonts.gstatic.com/s/inter/v13/UcC73FwrK3iLTeHuS_fvQtMwCp50KnMa25L7SUc.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 700;
  font-display: fallback;
  src: url(/fonts.gstatic.com/s/inter/v13/UcC73FwrK3iLTeHuS_fvQtMwCp50KnMa1ZL7.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
</style>
<link rel="stylesheet" id="astra-menu-animation-css" href="https://websitedemos.net/learndash-academy-02/wp-content/themes/astra/assets/css/minified/menu-animation.min.css?ver=4.6.4" media="all" />
<style id="wp-emoji-styles-inline-css">

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<style id="global-styles-inline-css">
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--color--ast-global-color-0: var(--ast-global-color-0);--wp--preset--color--ast-global-color-1: var(--ast-global-color-1);--wp--preset--color--ast-global-color-2: var(--ast-global-color-2);--wp--preset--color--ast-global-color-3: var(--ast-global-color-3);--wp--preset--color--ast-global-color-4: var(--ast-global-color-4);--wp--preset--color--ast-global-color-5: var(--ast-global-color-5);--wp--preset--color--ast-global-color-6: var(--ast-global-color-6);--wp--preset--color--ast-global-color-7: var(--ast-global-color-7);--wp--preset--color--ast-global-color-8: var(--ast-global-color-8);--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}body { margin: 0;--wp--style--global--content-size: var(--wp--custom--ast-content-width-size);--wp--style--global--wide-size: var(--wp--custom--ast-wide-width-size); }.wp-site-blocks > .alignleft { float: left; margin-right: 2em; }.wp-site-blocks > .alignright { float: right; margin-left: 2em; }.wp-site-blocks > .aligncenter { justify-content: center; margin-left: auto; margin-right: auto; }:where(.wp-site-blocks) > * { margin-block-start: 24px; margin-block-end: 0; }:where(.wp-site-blocks) > :first-child:first-child { margin-block-start: 0; }:where(.wp-site-blocks) > :last-child:last-child { margin-block-end: 0; }body { --wp--style--block-gap: 24px; }:where(body .is-layout-flow)  > :first-child:first-child{margin-block-start: 0;}:where(body .is-layout-flow)  > :last-child:last-child{margin-block-end: 0;}:where(body .is-layout-flow)  > *{margin-block-start: 24px;margin-block-end: 0;}:where(body .is-layout-constrained)  > :first-child:first-child{margin-block-start: 0;}:where(body .is-layout-constrained)  > :last-child:last-child{margin-block-end: 0;}:where(body .is-layout-constrained)  > *{margin-block-start: 24px;margin-block-end: 0;}:where(body .is-layout-flex) {gap: 24px;}:where(body .is-layout-grid) {gap: 24px;}body .is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}body .is-layout-grid{display: grid;}body .is-layout-grid > *{margin: 0;}body{padding-top: 0px;padding-right: 0px;padding-bottom: 0px;padding-left: 0px;}a:where(:not(.wp-element-button)){text-decoration: none;}.wp-element-button, .wp-block-button__link{background-color: #32373c;border-width: 0;color: #fff;font-family: inherit;font-size: inherit;line-height: inherit;padding: calc(0.667em + 2px) calc(1.333em + 2px);text-decoration: none;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-ast-global-color-0-color{color: var(--wp--preset--color--ast-global-color-0) !important;}.has-ast-global-color-1-color{color: var(--wp--preset--color--ast-global-color-1) !important;}.has-ast-global-color-2-color{color: var(--wp--preset--color--ast-global-color-2) !important;}.has-ast-global-color-3-color{color: var(--wp--preset--color--ast-global-color-3) !important;}.has-ast-global-color-4-color{color: var(--wp--preset--color--ast-global-color-4) !important;}.has-ast-global-color-5-color{color: var(--wp--preset--color--ast-global-color-5) !important;}.has-ast-global-color-6-color{color: var(--wp--preset--color--ast-global-color-6) !important;}.has-ast-global-color-7-color{color: var(--wp--preset--color--ast-global-color-7) !important;}.has-ast-global-color-8-color{color: var(--wp--preset--color--ast-global-color-8) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-ast-global-color-0-background-color{background-color: var(--wp--preset--color--ast-global-color-0) !important;}.has-ast-global-color-1-background-color{background-color: var(--wp--preset--color--ast-global-color-1) !important;}.has-ast-global-color-2-background-color{background-color: var(--wp--preset--color--ast-global-color-2) !important;}.has-ast-global-color-3-background-color{background-color: var(--wp--preset--color--ast-global-color-3) !important;}.has-ast-global-color-4-background-color{background-color: var(--wp--preset--color--ast-global-color-4) !important;}.has-ast-global-color-5-background-color{background-color: var(--wp--preset--color--ast-global-color-5) !important;}.has-ast-global-color-6-background-color{background-color: var(--wp--preset--color--ast-global-color-6) !important;}.has-ast-global-color-7-background-color{background-color: var(--wp--preset--color--ast-global-color-7) !important;}.has-ast-global-color-8-background-color{background-color: var(--wp--preset--color--ast-global-color-8) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-ast-global-color-0-border-color{border-color: var(--wp--preset--color--ast-global-color-0) !important;}.has-ast-global-color-1-border-color{border-color: var(--wp--preset--color--ast-global-color-1) !important;}.has-ast-global-color-2-border-color{border-color: var(--wp--preset--color--ast-global-color-2) !important;}.has-ast-global-color-3-border-color{border-color: var(--wp--preset--color--ast-global-color-3) !important;}.has-ast-global-color-4-border-color{border-color: var(--wp--preset--color--ast-global-color-4) !important;}.has-ast-global-color-5-border-color{border-color: var(--wp--preset--color--ast-global-color-5) !important;}.has-ast-global-color-6-border-color{border-color: var(--wp--preset--color--ast-global-color-6) !important;}.has-ast-global-color-7-border-color{border-color: var(--wp--preset--color--ast-global-color-7) !important;}.has-ast-global-color-8-border-color{border-color: var(--wp--preset--color--ast-global-color-8) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel="stylesheet" id="learndash_quiz_front_css-css" href="//websitedemos.net/learndash-academy-02/wp-content/plugins/sfwd-lms/themes/legacy/templates/learndash_quiz_front.css?ver=3.2.3.3-1707647724" media="all" />
<link rel="stylesheet" id="jquery-dropdown-css-css" href="//websitedemos.net/learndash-academy-02/wp-content/plugins/sfwd-lms/assets/css/jquery.dropdown.min.css?ver=3.2.3.3-1707647724" media="all" />
<link rel="stylesheet" id="learndash_lesson_video-css" href="//websitedemos.net/learndash-academy-02/wp-content/plugins/sfwd-lms/themes/legacy/templates/learndash_lesson_video.css?ver=3.2.3.3-1707647724" media="all" />
<link rel="stylesheet" id="learndash-front-css" href="//websitedemos.net/learndash-academy-02/wp-content/plugins/sfwd-lms/themes/ld30/assets/css/learndash.css?ver=3.2.3.3-1707647724" media="all" />
<style id="learndash-front-inline-css">
		.learndash-wrapper .ld-item-list .ld-item-list-item.ld-is-next,
		.learndash-wrapper .wpProQuiz_content .wpProQuiz_questionListItem label:focus-within {
			border-color: #0984e3;
		}

		/*
		.learndash-wrapper a:not(.ld-button):not(#quiz_continue_link):not(.ld-focus-menu-link):not(.btn-blue):not(#quiz_continue_link):not(.ld-js-register-account):not(#ld-focus-mode-course-heading):not(#btn-join):not(.ld-item-name):not(.ld-table-list-item-preview):not(.ld-lesson-item-preview-heading),
		 */

		.learndash-wrapper .ld-breadcrumbs a,
		.learndash-wrapper .ld-lesson-item.ld-is-current-lesson .ld-lesson-item-preview-heading,
		.learndash-wrapper .ld-lesson-item.ld-is-current-lesson .ld-lesson-title,
		.learndash-wrapper .ld-primary-color-hover:hover,
		.learndash-wrapper .ld-primary-color,
		.learndash-wrapper .ld-primary-color-hover:hover,
		.learndash-wrapper .ld-primary-color,
		.learndash-wrapper .ld-tabs .ld-tabs-navigation .ld-tab.ld-active,
		.learndash-wrapper .ld-button.ld-button-transparent,
		.learndash-wrapper .ld-button.ld-button-reverse,
		.learndash-wrapper .ld-icon-certificate,
		.learndash-wrapper .ld-login-modal .ld-login-modal-login .ld-modal-heading,
		#wpProQuiz_user_content a,
		.learndash-wrapper .ld-item-list .ld-item-list-item a.ld-item-name:hover,
		.learndash-wrapper .ld-focus-comments__heading-actions .ld-expand-button,
		.learndash-wrapper .ld-focus-comments__heading a,
		.learndash-wrapper .ld-focus-comments .comment-respond a,
		.learndash-wrapper .ld-focus-comment .ld-comment-reply a.comment-reply-link:hover,
		.learndash-wrapper .ld-expand-button.ld-button-alternate {
			color: #0984e3 !important;
		}

		.learndash-wrapper .ld-focus-comment.bypostauthor>.ld-comment-wrapper,
		.learndash-wrapper .ld-focus-comment.role-group_leader>.ld-comment-wrapper,
		.learndash-wrapper .ld-focus-comment.role-administrator>.ld-comment-wrapper {
			background-color:rgba(9, 132, 227, 0.03) !important;
		}


		.learndash-wrapper .ld-primary-background,
		.learndash-wrapper .ld-tabs .ld-tabs-navigation .ld-tab.ld-active:after {
			background: #0984e3 !important;
		}



		.learndash-wrapper .ld-course-navigation .ld-lesson-item.ld-is-current-lesson .ld-status-incomplete,
		.learndash-wrapper .ld-focus-comment.bypostauthor:not(.ptype-sfwd-assignment) >.ld-comment-wrapper>.ld-comment-avatar img,
		.learndash-wrapper .ld-focus-comment.role-group_leader>.ld-comment-wrapper>.ld-comment-avatar img,
		.learndash-wrapper .ld-focus-comment.role-administrator>.ld-comment-wrapper>.ld-comment-avatar img {
			border-color: #0984e3 !important;
		}



		.learndash-wrapper .ld-loading::before {
			border-top:3px solid #0984e3 !important;
		}

		.learndash-wrapper .ld-button:hover:not(.learndash-link-previous-incomplete):not(.ld-button-transparent),
		#learndash-tooltips .ld-tooltip:after,
		#learndash-tooltips .ld-tooltip,
		.learndash-wrapper .ld-primary-background,
		.learndash-wrapper .btn-join,
		.learndash-wrapper #btn-join,
		.learndash-wrapper .ld-button:not(.ld-js-register-account):not(.learndash-link-previous-incomplete):not(.ld-button-transparent),
		.learndash-wrapper .ld-expand-button,
		.learndash-wrapper .wpProQuiz_content .wpProQuiz_button:not(.wpProQuiz_button_reShowQuestion):not(.wpProQuiz_button_restartQuiz),
		.learndash-wrapper .wpProQuiz_content .wpProQuiz_button2,
		.learndash-wrapper .ld-focus .ld-focus-sidebar .ld-course-navigation-heading,
		.learndash-wrapper .ld-focus .ld-focus-sidebar .ld-focus-sidebar-trigger,
		.learndash-wrapper .ld-focus-comments .form-submit #submit,
		.learndash-wrapper .ld-login-modal input[type='submit'],
		.learndash-wrapper .ld-login-modal .ld-login-modal-register,
		.learndash-wrapper .wpProQuiz_content .wpProQuiz_certificate a.btn-blue,
		.learndash-wrapper .ld-focus .ld-focus-header .ld-user-menu .ld-user-menu-items a,
		#wpProQuiz_user_content table.wp-list-table thead th,
		#wpProQuiz_overlay_close,
		.learndash-wrapper .ld-expand-button.ld-button-alternate .ld-icon {
			background-color: #0984e3 !important;
		}

		.learndash-wrapper .ld-focus .ld-focus-header .ld-user-menu .ld-user-menu-items:before {
			border-bottom-color: #0984e3 !important;
		}

		.learndash-wrapper .ld-button.ld-button-transparent:hover {
			background: transparent !important;
		}

		.learndash-wrapper .ld-focus .ld-focus-header .sfwd-mark-complete .learndash_mark_complete_button,
		.learndash-wrapper .ld-focus .ld-focus-header #sfwd-mark-complete #learndash_mark_complete_button,
		.learndash-wrapper .ld-button.ld-button-transparent,
		.learndash-wrapper .ld-button.ld-button-alternate,
		.learndash-wrapper .ld-expand-button.ld-button-alternate {
			background-color:transparent !important;
		}

		.learndash-wrapper .ld-focus-header .ld-user-menu .ld-user-menu-items a,
		.learndash-wrapper .ld-button.ld-button-reverse:hover,
		.learndash-wrapper .ld-alert-success .ld-alert-icon.ld-icon-certificate,
		.learndash-wrapper .ld-alert-warning .ld-button:not(.learndash-link-previous-incomplete),
		.learndash-wrapper .ld-primary-background.ld-status {
			color:white !important;
		}

		.learndash-wrapper .ld-status.ld-status-unlocked {
			background-color: rgba(9,132,227,0.2) !important;
			color: #0984e3 !important;
		}

		.learndash-wrapper .wpProQuiz_content .wpProQuiz_addToplist {
			background-color: rgba(9,132,227,0.1) !important;
			border: 1px solid #0984e3 !important;
		}

		.learndash-wrapper .wpProQuiz_content .wpProQuiz_toplistTable th {
			background: #0984e3 !important;
		}

		.learndash-wrapper .wpProQuiz_content .wpProQuiz_toplistTrOdd {
			background-color: rgba(9,132,227,0.1) !important;
		}

		.learndash-wrapper .wpProQuiz_content .wpProQuiz_reviewDiv li.wpProQuiz_reviewQuestionTarget {
			background-color: #0984e3 !important;
		}
		.learndash-wrapper .wpProQuiz_content .wpProQuiz_time_limit .wpProQuiz_progress {
			background-color: #0984e3 !important;
		}
		
		.learndash-wrapper #quiz_continue_link,
		.learndash-wrapper .ld-secondary-background,
		.learndash-wrapper .learndash_mark_complete_button,
		.learndash-wrapper #learndash_mark_complete_button,
		.learndash-wrapper .ld-status-complete,
		.learndash-wrapper .ld-alert-success .ld-button,
		.learndash-wrapper .ld-alert-success .ld-alert-icon {
			background-color: #0984e3 !important;
		}

		.learndash-wrapper .wpProQuiz_content a#quiz_continue_link {
			background-color: #0984e3 !important;
		}

		.learndash-wrapper .course_progress .sending_progress_bar {
			background: #0984e3 !important;
		}

		.learndash-wrapper .wpProQuiz_content .wpProQuiz_button_reShowQuestion:hover, .learndash-wrapper .wpProQuiz_content .wpProQuiz_button_restartQuiz:hover {
			background-color: #0984e3 !important;
			opacity: 0.75;
		}

		.learndash-wrapper .ld-secondary-color-hover:hover,
		.learndash-wrapper .ld-secondary-color,
		.learndash-wrapper .ld-focus .ld-focus-header .sfwd-mark-complete .learndash_mark_complete_button,
		.learndash-wrapper .ld-focus .ld-focus-header #sfwd-mark-complete #learndash_mark_complete_button,
		.learndash-wrapper .ld-focus .ld-focus-header .sfwd-mark-complete:after {
			color: #0984e3 !important;
		}

		.learndash-wrapper .ld-secondary-in-progress-icon {
			border-left-color: #0984e3 !important;
			border-top-color: #0984e3 !important;
		}

		.learndash-wrapper .ld-alert-success {
			border-color: #0984e3;
			background-color: transparent !important;
		}

		.learndash-wrapper .wpProQuiz_content .wpProQuiz_reviewQuestion li.wpProQuiz_reviewQuestionSolved,
		.learndash-wrapper .wpProQuiz_content .wpProQuiz_box li.wpProQuiz_reviewQuestionSolved {
			background-color: #0984e3 !important;
		}

		.learndash-wrapper .wpProQuiz_content  .wpProQuiz_reviewLegend span.wpProQuiz_reviewColor_Answer {
			background-color: #0984e3 !important;
		}

		
		.learndash-wrapper .ld-alert-warning {
			background-color:transparent;
		}

		.learndash-wrapper .ld-status-waiting,
		.learndash-wrapper .ld-alert-warning .ld-alert-icon {
			background-color: #003bb1 !important;
		}

		.learndash-wrapper .ld-tertiary-color-hover:hover,
		.learndash-wrapper .ld-tertiary-color,
		.learndash-wrapper .ld-alert-warning {
			color: #003bb1 !important;
		}

		.learndash-wrapper .ld-tertiary-background {
			background-color: #003bb1 !important;
		}

		.learndash-wrapper .ld-alert-warning {
			border-color: #003bb1 !important;
		}

		.learndash-wrapper .ld-tertiary-background,
		.learndash-wrapper .ld-alert-warning .ld-alert-icon {
			color:white !important;
		}

		.learndash-wrapper .wpProQuiz_content .wpProQuiz_reviewQuestion li.wpProQuiz_reviewQuestionReview,
		.learndash-wrapper .wpProQuiz_content .wpProQuiz_box li.wpProQuiz_reviewQuestionReview {
			background-color: #003bb1 !important;
		}

		.learndash-wrapper .wpProQuiz_content  .wpProQuiz_reviewLegend span.wpProQuiz_reviewColor_Review {
			background-color: #003bb1 !important;
		}

		
</style>
<link rel="stylesheet" id="woocommerce-layout-css" href="https://websitedemos.net/learndash-academy-02/wp-content/themes/astra/assets/css/minified/compatibility/woocommerce/woocommerce-layout-grid.min.css?ver=4.6.4" media="all" />
<link rel="stylesheet" id="woocommerce-smallscreen-css" href="https://websitedemos.net/learndash-academy-02/wp-content/themes/astra/assets/css/minified/compatibility/woocommerce/woocommerce-smallscreen-grid.min.css?ver=4.6.4" media="only screen and (max-width: 921px)" />
<link rel="stylesheet" id="woocommerce-general-css" href="https://websitedemos.net/learndash-academy-02/wp-content/themes/astra/assets/css/minified/compatibility/woocommerce/woocommerce-grid.min.css?ver=4.6.4" media="all" />
<style id="woocommerce-general-inline-css">

					.woocommerce .woocommerce-result-count, .woocommerce-page .woocommerce-result-count {
						float: left;
					}

					.woocommerce .woocommerce-ordering {
						float: right;
						margin-bottom: 2.5em;
					}
				#customer_details h3:not(.elementor-widget-woocommerce-checkout-page h3){font-size:1.2rem;padding:20px 0 14px;margin:0 0 20px;border-bottom:1px solid var(--ast-border-color);font-weight:700;}form #order_review_heading:not(.elementor-widget-woocommerce-checkout-page #order_review_heading){border-width:2px 2px 0 2px;border-style:solid;font-size:1.2rem;margin:0;padding:1.5em 1.5em 1em;border-color:var(--ast-border-color);font-weight:700;}.woocommerce-Address h3, .cart-collaterals h2{font-size:1.2rem;padding:.7em 1em;}.woocommerce-cart .cart-collaterals .cart_totals>h2{font-weight:700;}form #order_review:not(.elementor-widget-woocommerce-checkout-page #order_review){padding:0 2em;border-width:0 2px 2px;border-style:solid;border-color:var(--ast-border-color);}ul#shipping_method li:not(.elementor-widget-woocommerce-cart #shipping_method li){margin:0;padding:0.25em 0 0.25em 22px;text-indent:-22px;list-style:none outside;}.woocommerce span.onsale, .wc-block-grid__product .wc-block-grid__product-onsale{background-color:var(--ast-global-color-0);color:#ffffff;}.woocommerce-message, .woocommerce-info{border-top-color:var(--ast-global-color-0);}.woocommerce-message::before,.woocommerce-info::before{color:var(--ast-global-color-0);}.woocommerce ul.products li.product .price, .woocommerce div.product p.price, .woocommerce div.product span.price, .widget_layered_nav_filters ul li.chosen a, .woocommerce-page ul.products li.product .ast-woo-product-category, .wc-layered-nav-rating a{color:var(--ast-global-color-3);}.woocommerce nav.woocommerce-pagination ul,.woocommerce nav.woocommerce-pagination ul li{border-color:var(--ast-global-color-0);}.woocommerce nav.woocommerce-pagination ul li a:focus, .woocommerce nav.woocommerce-pagination ul li a:hover, .woocommerce nav.woocommerce-pagination ul li span.current{background:var(--ast-global-color-0);color:#ffffff;}.woocommerce-MyAccount-navigation-link.is-active a{color:var(--ast-global-color-1);}.woocommerce .widget_price_filter .ui-slider .ui-slider-range, .woocommerce .widget_price_filter .ui-slider .ui-slider-handle{background-color:var(--ast-global-color-0);}.woocommerce .star-rating, .woocommerce .comment-form-rating .stars a, .woocommerce .star-rating::before{color:var(--ast-global-color-3);}.woocommerce div.product .woocommerce-tabs ul.tabs li.active:before,  .woocommerce div.ast-product-tabs-layout-vertical .woocommerce-tabs ul.tabs li:hover::before{background:var(--ast-global-color-0);}.woocommerce[class*="rel-up-columns-"] .site-main div.product .related.products ul.products li.product, .woocommerce-page .site-main ul.products li.product{width:100%;}.woocommerce ul.product-categories > li ul li{position:relative;}.woocommerce ul.product-categories > li ul li:before{content:"";border-width:1px 1px 0 0;border-style:solid;display:inline-block;width:6px;height:6px;position:absolute;top:50%;margin-top:-2px;-webkit-transform:rotate(45deg);transform:rotate(45deg);}.woocommerce ul.product-categories > li ul li a{margin-left:15px;}.ast-icon-shopping-cart svg{height:.82em;}.ast-icon-shopping-bag svg{height:1em;width:1em;}.ast-icon-shopping-basket svg{height:1.15em;width:1.2em;}.ast-site-header-cart.ast-menu-cart-outline .ast-addon-cart-wrap, .ast-site-header-cart.ast-menu-cart-fill .ast-addon-cart-wrap {line-height:1;}.ast-site-header-cart.ast-menu-cart-fill i.astra-icon{ font-size:1.1em;}li.woocommerce-custom-menu-item .ast-site-header-cart i.astra-icon:after{ padding-left:2px;}.ast-hfb-header .ast-addon-cart-wrap{ padding:0.4em;}.ast-header-break-point.ast-header-custom-item-outside .ast-woo-header-cart-info-wrap{ display:none;}.ast-site-header-cart i.astra-icon:after{ background:var(--ast-global-color-0);}@media (min-width:545px) and (max-width:921px){.woocommerce.tablet-columns-3 ul.products li.product, .woocommerce-page.tablet-columns-3 ul.products:not(.elementor-grid){grid-template-columns:repeat(3, minmax(0, 1fr));}}@media (min-width:922px){.woocommerce form.checkout_coupon{width:50%;}}@media (max-width:921px){.ast-header-break-point.ast-woocommerce-cart-menu .header-main-layout-1.ast-mobile-header-stack.ast-no-menu-items .ast-site-header-cart, .ast-header-break-point.ast-woocommerce-cart-menu .header-main-layout-3.ast-mobile-header-stack.ast-no-menu-items .ast-site-header-cart{padding-right:0;padding-left:0;}.ast-header-break-point.ast-woocommerce-cart-menu .header-main-layout-1.ast-mobile-header-stack .main-header-bar{text-align:center;}.ast-header-break-point.ast-woocommerce-cart-menu .header-main-layout-1.ast-mobile-header-stack .ast-site-header-cart, .ast-header-break-point.ast-woocommerce-cart-menu .header-main-layout-1.ast-mobile-header-stack .ast-mobile-menu-buttons{display:inline-block;}.ast-header-break-point.ast-woocommerce-cart-menu .header-main-layout-2.ast-mobile-header-inline .site-branding{flex:auto;}.ast-header-break-point.ast-woocommerce-cart-menu .header-main-layout-3.ast-mobile-header-stack .site-branding{flex:0 0 100%;}.ast-header-break-point.ast-woocommerce-cart-menu .header-main-layout-3.ast-mobile-header-stack .main-header-container{display:flex;justify-content:center;}.woocommerce-cart .woocommerce-shipping-calculator .button{width:100%;}.woocommerce div.product div.images, .woocommerce div.product div.summary, .woocommerce #content div.product div.images, .woocommerce #content div.product div.summary, .woocommerce-page div.product div.images, .woocommerce-page div.product div.summary, .woocommerce-page #content div.product div.images, .woocommerce-page #content div.product div.summary{float:none;width:100%;}.woocommerce-cart table.cart td.actions .ast-return-to-shop{display:block;text-align:center;margin-top:1em;}.ast-container .woocommerce ul.products:not(.elementor-grid), .woocommerce-page ul.products:not(.elementor-grid), .woocommerce.tablet-columns-3 ul.products:not(.elementor-grid){grid-template-columns:repeat(3, minmax(0, 1fr));}}@media (max-width:544px){.ast-separate-container .ast-woocommerce-container{padding:.54em 1em 1.33333em;}.woocommerce-message, .woocommerce-error, .woocommerce-info{display:flex;flex-wrap:wrap;}.woocommerce-message a.button, .woocommerce-error a.button, .woocommerce-info a.button{order:1;margin-top:.5em;}.woocommerce .woocommerce-ordering, .woocommerce-page .woocommerce-ordering{float:none;margin-bottom:2em;}.woocommerce table.cart td.actions .button, .woocommerce #content table.cart td.actions .button, .woocommerce-page table.cart td.actions .button, .woocommerce-page #content table.cart td.actions .button{padding-left:1em;padding-right:1em;}.woocommerce #content table.cart .button, .woocommerce-page #content table.cart .button{width:100%;}.woocommerce #content table.cart td.actions .coupon, .woocommerce-page #content table.cart td.actions .coupon{float:none;}.woocommerce #content table.cart td.actions .coupon .button, .woocommerce-page #content table.cart td.actions .coupon .button{flex:1;}.woocommerce #content div.product .woocommerce-tabs ul.tabs li a, .woocommerce-page #content div.product .woocommerce-tabs ul.tabs li a{display:block;}.ast-container .woocommerce ul.products:not(.elementor-grid), .woocommerce-page ul.products:not(.elementor-grid), .woocommerce.mobile-columns-2 ul.products:not(.elementor-grid), .woocommerce-page.mobile-columns-2 ul.products:not(.elementor-grid){grid-template-columns:repeat(2, minmax(0, 1fr));}.woocommerce.mobile-rel-up-columns-2 ul.products::not(.elementor-grid){grid-template-columns:repeat(2, minmax(0, 1fr));}}@media (max-width:544px){.woocommerce ul.products a.button.loading::after, .woocommerce-page ul.products a.button.loading::after{display:inline-block;margin-left:5px;position:initial;}.woocommerce.mobile-columns-1 .site-main ul.products li.product:nth-child(n), .woocommerce-page.mobile-columns-1 .site-main ul.products li.product:nth-child(n){margin-right:0;}.woocommerce #content div.product .woocommerce-tabs ul.tabs li, .woocommerce-page #content div.product .woocommerce-tabs ul.tabs li{display:block;margin-right:0;}}@media (min-width:922px){.woocommerce #content .ast-woocommerce-container div.product div.images, .woocommerce .ast-woocommerce-container div.product div.images, .woocommerce-page #content .ast-woocommerce-container div.product div.images, .woocommerce-page .ast-woocommerce-container div.product div.images{width:50%;}.woocommerce #content .ast-woocommerce-container div.product div.summary, .woocommerce .ast-woocommerce-container div.product div.summary, .woocommerce-page #content .ast-woocommerce-container div.product div.summary, .woocommerce-page .ast-woocommerce-container div.product div.summary{width:46%;}.woocommerce.woocommerce-checkout form #customer_details.col2-set .col-1, .woocommerce.woocommerce-checkout form #customer_details.col2-set .col-2, .woocommerce-page.woocommerce-checkout form #customer_details.col2-set .col-1, .woocommerce-page.woocommerce-checkout form #customer_details.col2-set .col-2{float:none;width:auto;}}.widget_product_search button{flex:0 0 auto;padding:10px 20px;;}@media (min-width:922px){.woocommerce.woocommerce-checkout form #customer_details.col2-set, .woocommerce-page.woocommerce-checkout form #customer_details.col2-set{width:55%;float:left;margin-right:4.347826087%;}.woocommerce.woocommerce-checkout form #order_review, .woocommerce.woocommerce-checkout form #order_review_heading, .woocommerce-page.woocommerce-checkout form #order_review, .woocommerce-page.woocommerce-checkout form #order_review_heading{width:40%;float:right;margin-right:0;clear:right;}}select, .select2-container .select2-selection--single{background-image:url("data:image/svg+xml,%3Csvg class='ast-arrow-svg' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' version='1.1' x='0px' y='0px' width='26px' height='16.043px' fill='%233a3a3a' viewBox='57 35.171 26 16.043' enable-background='new 57 35.171 26 16.043' xml:space='preserve' %3E%3Cpath d='M57.5,38.193l12.5,12.5l12.5-12.5l-2.5-2.5l-10,10l-10-10L57.5,38.193z'%3E%3C/path%3E%3C/svg%3E");background-size:.8em;background-repeat:no-repeat;background-position-x:calc( 100% - 10px );background-position-y:center;-webkit-appearance:none;-moz-appearance:none;padding-right:2em;}
						.ast-onsale-card {
							position: absolute;
							top: 1.5em;
							left: 1.5em;
							color: var(--ast-global-color-3);
							background-color: var(--ast-global-color-5);
							width: fit-content;
							border-radius: 20px;
							padding: 0.4em 0.8em;
							font-size: .87em;
							font-weight: 500;
							line-height: normal;
							letter-spacing: normal;
							box-shadow: 0 4px 4px rgba(0,0,0,0.15);
							opacity: 1;
							visibility: visible;
							z-index: 4;
						}
						@media(max-width: 420px) {
							.mobile-columns-3 .ast-onsale-card {
								top: 1em;
								left: 1em;
							}
						}
					

					.ast-on-card-button {
						position: absolute;
						right: 1em;
						visibility: hidden;
						opacity: 0;
						transition: all 0.2s;
						z-index: 5;
						cursor: pointer;
					}

					.ast-on-card-button.ast-onsale-card {
						opacity: 1;
						visibility: visible;
					}

					.ast-on-card-button:hover .ast-card-action-tooltip {
						opacity: 1;
						visibility: visible;
					}

					.ast-on-card-button:hover .ahfb-svg-iconset {
						opacity: 1;
						color: var(--ast-global-color-2);
					}

					.ast-on-card-button .ahfb-svg-iconset {
						border-radius: 50%;
						color: var(--ast-global-color-2);
						background: var(--ast-global-color-5);
						opacity: 0.7;
						width: 2em;
						height: 2em;
						justify-content: center;
						box-shadow: 0 4px 4px rgba(0, 0, 0, 0.15);
					}

					.ast-on-card-button .ahfb-svg-iconset .ast-icon {
						-js-display: inline-flex;
						display: inline-flex;
						align-self: center;
					}

					.ast-on-card-button svg {
						fill: currentColor;
					}

					.ast-select-options-trigger {
						top: 1em;
					}

					.ast-select-options-trigger.loading:after {
						display: block;
						content: " ";
						position: absolute;
						top: 50%;
						right: 50%;
						left: auto;
						width: 16px;
						height: 16px;
						margin-top: -12px;
						margin-right: -8px;
						background-color: var(--ast-global-color-2);
						background-image: none;
						border-radius: 100%;
						-webkit-animation: dotPulse 0.65s 0s infinite cubic-bezier(0.21, 0.53, 0.56, 0.8);
						animation: dotPulse 0.65s 0s infinite cubic-bezier(0.21, 0.53, 0.56, 0.8);
					}

					.ast-select-options-trigger.loading .ast-icon {
						display: none;
					}

					.ast-card-action-tooltip {
						background-color: var(--ast-global-color-2);
						pointer-events: none;
						white-space: nowrap;
						padding: 8px 9px;
						padding: 0.7em 0.9em;
						color: var(--ast-global-color-5);
						margin-right: 10px;
						border-radius: 3px;
						font-size: 0.8em;
						line-height: 1;
						font-weight: normal;
						position: absolute;
						right: 100%;
						top: auto;
						visibility: hidden;
						opacity: 0;
						transition: all 0.2s;
					}

					.ast-card-action-tooltip:after {
						content: "";
						position: absolute;
						top: 50%;
						margin-top: -5px;
						right: -10px;
						width: 0;
						height: 0;
						border-style: solid;
						border-width: 5px;
						border-color: transparent transparent transparent var(--ast-global-color-2);
					}

					.astra-shop-thumbnail-wrap:hover .ast-on-card-button:not(.ast-onsale-card) {
						opacity: 1;
						visibility: visible;
					}

					@media (max-width: 420px) {

						.mobile-columns-3 .ast-select-options-trigger {
							top: 0.5em;
							right: 0.5em;
						}
					}
				
						.woocommerce ul.products li.product.desktop-align-left, .woocommerce-page ul.products li.product.desktop-align-left {
							text-align: left;
						}
						.woocommerce ul.products li.product.desktop-align-left .star-rating,
						.woocommerce ul.products li.product.desktop-align-left .button,
						.woocommerce-page ul.products li.product.desktop-align-left .star-rating,
						.woocommerce-page ul.products li.product.desktop-align-left .button {
							margin-left: 0;
							margin-right: 0;
						}
					@media(max-width: 921px){
						.woocommerce ul.products li.product.tablet-align-left, .woocommerce-page ul.products li.product.tablet-align-left {
							text-align: left;
						}
						.woocommerce ul.products li.product.tablet-align-left .star-rating,
						.woocommerce ul.products li.product.tablet-align-left .button,
						.woocommerce-page ul.products li.product.tablet-align-left .star-rating,
						.woocommerce-page ul.products li.product.tablet-align-left .button {
							margin-left: 0;
							margin-right: 0;
						}
					}@media(max-width: 544px){
						.woocommerce ul.products li.product.mobile-align-left, .woocommerce-page ul.products li.product.mobile-align-left {
							text-align: left;
						}
						.woocommerce ul.products li.product.mobile-align-left .star-rating,
						.woocommerce ul.products li.product.mobile-align-left .button,
						.woocommerce-page ul.products li.product.mobile-align-left .star-rating,
						.woocommerce-page ul.products li.product.mobile-align-left .button {
							margin-left: 0;
							margin-right: 0;
						}
					}.ast-woo-active-filter-widget .wc-block-active-filters{display:flex;align-items:self-start;justify-content:space-between;}.ast-woo-active-filter-widget .wc-block-active-filters__clear-all{flex:none;margin-top:2px;}
</style>
<style id="woocommerce-inline-inline-css">
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel="stylesheet" id="wc-gateway-ppec-frontend-css" href="https://websitedemos.net/learndash-academy-02/wp-content/plugins/woocommerce-gateway-paypal-express-checkout/assets/css/wc-gateway-ppec-frontend.css?ver=2.1.3" media="all" />
<link rel="stylesheet" id="elementor-icons-css" href="https://websitedemos.net/learndash-academy-02/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.css?ver=5.27.0" media="all" />
<link rel="stylesheet" id="elementor-frontend-css" href="https://websitedemos.net/learndash-academy-02/wp-content/plugins/elementor/assets/css/frontend.css?ver=3.19.1" media="all" />
<link rel="stylesheet" id="swiper-css" href="https://websitedemos.net/learndash-academy-02/wp-content/plugins/elementor/assets/lib/swiper/css/swiper.css?ver=5.3.6" media="all" />
<link rel="stylesheet" id="elementor-post-24888-css" href="https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/elementor/css/post-24888.css?ver=1694689418" media="all" />
<link rel="stylesheet" id="astra-sites-showcase-blocks-css" href="https://websitedemos.net/learndash-academy-02/wp-content/plugins/astra-sites-showcase/assets/css/blocks.css?ver=2.4.2" media="all" />
<link rel="stylesheet" id="font-awesome-5-all-css" href="https://websitedemos.net/learndash-academy-02/wp-content/plugins/elementor/assets/lib/font-awesome/css/all.css?ver=3.19.1" media="all" />
<link rel="stylesheet" id="font-awesome-4-shim-css" href="https://websitedemos.net/learndash-academy-02/wp-content/plugins/elementor/assets/lib/font-awesome/css/v4-shims.css?ver=3.19.1" media="all" />
<link rel="stylesheet" id="elementor-post-17-css" href="https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/elementor/css/post-17.css?ver=1705418355" media="all" />
<style id="google-fonts-1-css" media="all">/* cyrillic-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 100;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOiCnqEu92Fr1Mu51QrEz0dL_nz.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 100;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOiCnqEu92Fr1Mu51QrEzQdL_nz.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 100;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOiCnqEu92Fr1Mu51QrEzwdL_nz.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 100;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOiCnqEu92Fr1Mu51QrEzMdL_nz.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 100;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOiCnqEu92Fr1Mu51QrEz8dL_nz.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 100;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOiCnqEu92Fr1Mu51QrEz4dL_nz.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 100;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOiCnqEu92Fr1Mu51QrEzAdLw.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 300;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOjCnqEu92Fr1Mu51TjASc3CsTKlA.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 300;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOjCnqEu92Fr1Mu51TjASc-CsTKlA.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 300;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOjCnqEu92Fr1Mu51TjASc2CsTKlA.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 300;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOjCnqEu92Fr1Mu51TjASc5CsTKlA.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 300;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOjCnqEu92Fr1Mu51TjASc1CsTKlA.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 300;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOjCnqEu92Fr1Mu51TjASc0CsTKlA.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 300;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOjCnqEu92Fr1Mu51TjASc6CsQ.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 400;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOkCnqEu92Fr1Mu51xFIzIFKw.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 400;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOkCnqEu92Fr1Mu51xMIzIFKw.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 400;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOkCnqEu92Fr1Mu51xEIzIFKw.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 400;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOkCnqEu92Fr1Mu51xLIzIFKw.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 400;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOkCnqEu92Fr1Mu51xHIzIFKw.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 400;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOkCnqEu92Fr1Mu51xGIzIFKw.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 400;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOkCnqEu92Fr1Mu51xIIzI.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 500;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOjCnqEu92Fr1Mu51S7ACc3CsTKlA.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 500;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOjCnqEu92Fr1Mu51S7ACc-CsTKlA.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 500;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOjCnqEu92Fr1Mu51S7ACc2CsTKlA.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 500;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOjCnqEu92Fr1Mu51S7ACc5CsTKlA.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 500;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOjCnqEu92Fr1Mu51S7ACc1CsTKlA.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 500;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOjCnqEu92Fr1Mu51S7ACc0CsTKlA.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 500;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOjCnqEu92Fr1Mu51S7ACc6CsQ.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 700;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOjCnqEu92Fr1Mu51TzBic3CsTKlA.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 700;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOjCnqEu92Fr1Mu51TzBic-CsTKlA.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 700;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOjCnqEu92Fr1Mu51TzBic2CsTKlA.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 700;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOjCnqEu92Fr1Mu51TzBic5CsTKlA.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 700;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOjCnqEu92Fr1Mu51TzBic1CsTKlA.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 700;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOjCnqEu92Fr1Mu51TzBic0CsTKlA.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 700;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOjCnqEu92Fr1Mu51TzBic6CsQ.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 900;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOjCnqEu92Fr1Mu51TLBCc3CsTKlA.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 900;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOjCnqEu92Fr1Mu51TLBCc-CsTKlA.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 900;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOjCnqEu92Fr1Mu51TLBCc2CsTKlA.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 900;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOjCnqEu92Fr1Mu51TLBCc5CsTKlA.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 900;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOjCnqEu92Fr1Mu51TLBCc1CsTKlA.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 900;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOjCnqEu92Fr1Mu51TLBCc0CsTKlA.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 900;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOjCnqEu92Fr1Mu51TLBCc6CsQ.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 100;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOkCnqEu92Fr1MmgVxFIzIFKw.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 100;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOkCnqEu92Fr1MmgVxMIzIFKw.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 100;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOkCnqEu92Fr1MmgVxEIzIFKw.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 100;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOkCnqEu92Fr1MmgVxLIzIFKw.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 100;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOkCnqEu92Fr1MmgVxHIzIFKw.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 100;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOkCnqEu92Fr1MmgVxGIzIFKw.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 100;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOkCnqEu92Fr1MmgVxIIzI.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 300;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmSU5fCRc4EsA.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 300;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmSU5fABc4EsA.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 300;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmSU5fCBc4EsA.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 300;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmSU5fBxc4EsA.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 300;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmSU5fCxc4EsA.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 300;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmSU5fChc4EsA.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 300;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmSU5fBBc4.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOmCnqEu92Fr1Mu72xKOzY.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOmCnqEu92Fr1Mu5mxKOzY.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOmCnqEu92Fr1Mu7mxKOzY.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOmCnqEu92Fr1Mu4WxKOzY.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOmCnqEu92Fr1Mu7WxKOzY.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOmCnqEu92Fr1Mu7GxKOzY.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOmCnqEu92Fr1Mu4mxK.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 500;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmEU9fCRc4EsA.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 500;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmEU9fABc4EsA.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 500;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmEU9fCBc4EsA.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 500;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmEU9fBxc4EsA.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 500;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmEU9fCxc4EsA.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 500;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmEU9fChc4EsA.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 500;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmEU9fBBc4.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 700;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmWUlfCRc4EsA.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 700;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmWUlfABc4EsA.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 700;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmWUlfCBc4EsA.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 700;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmWUlfBxc4EsA.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 700;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmWUlfCxc4EsA.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 700;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmWUlfChc4EsA.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 700;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmWUlfBBc4.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 900;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmYUtfCRc4EsA.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 900;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmYUtfABc4EsA.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 900;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmYUtfCBc4EsA.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 900;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmYUtfBxc4EsA.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 900;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmYUtfCxc4EsA.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 900;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmYUtfChc4EsA.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 900;
  src: url(/fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmYUtfBBc4.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 100;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufA5qW54A.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 100;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufJ5qW54A.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 100;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufB5qW54A.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 100;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufO5qW54A.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 100;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufC5qW54A.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 100;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufD5qW54A.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 100;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufN5qU.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 200;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufA5qW54A.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 200;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufJ5qW54A.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 200;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufB5qW54A.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 200;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufO5qW54A.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 200;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufC5qW54A.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 200;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufD5qW54A.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 200;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufN5qU.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 300;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufA5qW54A.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 300;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufJ5qW54A.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 300;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufB5qW54A.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 300;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufO5qW54A.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 300;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufC5qW54A.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 300;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufD5qW54A.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 300;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufN5qU.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 400;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufA5qW54A.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 400;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufJ5qW54A.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 400;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufB5qW54A.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 400;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufO5qW54A.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 400;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufC5qW54A.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 400;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufD5qW54A.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 400;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufN5qU.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 500;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufA5qW54A.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 500;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufJ5qW54A.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 500;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufB5qW54A.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 500;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufO5qW54A.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 500;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufC5qW54A.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 500;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufD5qW54A.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 500;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufN5qU.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 600;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufA5qW54A.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 600;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufJ5qW54A.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 600;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufB5qW54A.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 600;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufO5qW54A.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 600;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufC5qW54A.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 600;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufD5qW54A.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 600;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufN5qU.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 700;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufA5qW54A.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 700;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufJ5qW54A.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 700;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufB5qW54A.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 700;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufO5qW54A.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 700;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufC5qW54A.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 700;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufD5qW54A.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 700;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufN5qU.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 800;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufA5qW54A.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 800;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufJ5qW54A.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 800;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufB5qW54A.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 800;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufO5qW54A.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 800;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufC5qW54A.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 800;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufD5qW54A.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 800;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufN5qU.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 900;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufA5qW54A.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 900;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufJ5qW54A.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 900;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufB5qW54A.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 900;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufO5qW54A.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 900;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufC5qW54A.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 900;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufD5qW54A.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto Slab';
  font-style: normal;
  font-weight: 900;
  src: url(/fonts.gstatic.com/s/robotoslab/v34/BngMUXZYTXPIvIBgJJSb6ufN5qU.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
</style>
<link rel="stylesheet" id="elementor-icons-shared-0-css" href="https://websitedemos.net/learndash-academy-02/wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.css?ver=5.15.3" media="all" />
<link rel="stylesheet" id="elementor-icons-fa-brands-css" href="https://websitedemos.net/learndash-academy-02/wp-content/plugins/elementor/assets/lib/font-awesome/css/brands.css?ver=5.15.3" media="all" />
<link rel="stylesheet" id="elementor-icons-fa-solid-css" href="https://websitedemos.net/learndash-academy-02/wp-content/plugins/elementor/assets/lib/font-awesome/css/solid.css?ver=5.15.3" media="all" />
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin><script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/dist/vendor/wp-polyfill-inert.js?ver=3.1.2" id="wp-polyfill-inert-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/dist/vendor/regenerator-runtime.js?ver=0.14.0" id="regenerator-runtime-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/dist/vendor/wp-polyfill.js?ver=3.15.0" id="wp-polyfill-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/dist/hooks.js?ver=c2825736a5a04b1ba4df" id="wp-hooks-js"></script>
<script src="https://stats.wp.com/w.js?ver=202406" id="woo-tracks-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/jquery/jquery.js?ver=3.7.1" id="jquery-core-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/jquery/jquery-migrate.js?ver=3.4.1" id="jquery-migrate-js"></script>
<!--[if IE]>
<script src="https://websitedemos.net/learndash-academy-02/wp-content/themes/astra/assets/js/unminified/flexibility.js?ver=4.6.4" id="astra-flexibility-js"></script>
<script id="astra-flexibility-js-after">
flexibility(document.documentElement);
</script>
<![endif]-->
<script src="https://websitedemos.net/learndash-academy-02/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.js?ver=2.7.0-wc.8.5.2" id="jquery-blockui-js" defer data-wp-strategy="defer"></script>
<script id="wc-add-to-cart-js-extra">
var wc_add_to_cart_params = {"ajax_url":"\/learndash-academy-02\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/learndash-academy-02\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https:\/\/websitedemos.net\/learndash-academy-02\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
</script>
<script src="https://websitedemos.net/learndash-academy-02/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.js?ver=8.5.2" id="wc-add-to-cart-js" defer data-wp-strategy="defer"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.js?ver=2.1.4-wc.8.5.2" id="js-cookie-js" defer data-wp-strategy="defer"></script>
<script id="woocommerce-js-extra">
var woocommerce_params = {"ajax_url":"\/learndash-academy-02\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/learndash-academy-02\/?wc-ajax=%%endpoint%%"};
</script>
<script src="https://websitedemos.net/learndash-academy-02/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.js?ver=8.5.2" id="woocommerce-js" defer data-wp-strategy="defer"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/dist/development/react-refresh-runtime.js?ver=79d08edf9bea9ade42e6" id="wp-react-refresh-runtime-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/dist/development/react-refresh-entry.js?ver=794dd7047e2302828128" id="wp-react-refresh-entry-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/dist/url.js?ver=2eb43eef60790a73edaf" id="wp-url-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/dist/dom-ready.js?ver=ae5bd6ca23f589f2dac7" id="wp-dom-ready-js"></script>
<script id="showcase-cta-preview-js-js-after">
( window.self !== window.top ) || document.write( '<script src="https://websitedemos.net/learndash-academy-02/wp-content/plugins/astra-sites-server/dist/template-preview/main.js?ver=ae2e87f495819b6e9f4f"></scr' + 'ipt>' );
</script>
<script id="starter-templates-preview-js-js-extra">
var starterTemplatesPreview = {"site_url":"https:\/\/websitedemos.net\/learndash-academy-02","AstColorPaletteVarPrefix":"--ast-global-color-","AstEleColorPaletteVarPrefix":["ast-global-color-0","ast-global-color-1","ast-global-color-2","ast-global-color-3","ast-global-color-4","ast-global-color-5","ast-global-color-6","ast-global-color-7","ast-global-color-8"],"templateTheme":"astra"};
</script>
<script id="starter-templates-preview-js-js-after">
( window.self === window.top ) || document.write( '<script src="https://websitedemos.net/learndash-academy-02/wp-content/plugins/astra-sites-server/dist/template-preview/main.js?ver=ae2e87f495819b6e9f4f"></scr' + 'ipt>' );
</script>
<script src="https://websitedemos.net/learndash-academy-02/wp-content/plugins/elementor/assets/lib/font-awesome/js/v4-shims.js?ver=3.19.1" id="font-awesome-4-shim-js"></script>
<link rel="https://api.w.org/" href="https://websitedemos.net/learndash-academy-02/wp-json/" /><link rel="alternate" type="application/json" href="https://websitedemos.net/learndash-academy-02/wp-json/wp/v2/pages/17" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://websitedemos.net/learndash-academy-02/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.4.3" />
<meta name="generator" content="WooCommerce 8.5.2" />
<link rel="shortlink" href="https://websitedemos.net/learndash-academy-02/" />
<link rel="alternate" type="application/json+oembed" href="https://websitedemos.net/learndash-academy-02/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fwebsitedemos.net%2Flearndash-academy-02%2F" />
<link rel="alternate" type="text/xml+oembed" href="https://websitedemos.net/learndash-academy-02/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fwebsitedemos.net%2Flearndash-academy-02%2F&#038;format=xml" />

<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-PW78FQ8');</script>

<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
<meta name="generator" content="Elementor 3.19.1; features: e_optimized_assets_loading, additional_custom_breakpoints, block_editor_assets_optimize, e_image_loading_optimization; settings: css_print_method-external, google_font-enabled, font_display-auto">
<link rel="icon" href="https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/06/learn-dash-favicaon2-150x150.png" sizes="32x32" />
<link rel="icon" href="https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/06/learn-dash-favicaon2.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/06/learn-dash-favicaon2.png" />
<meta name="msapplication-TileImage" content="https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/06/learn-dash-favicaon2.png" />
</head>
<body itemtype="https://schema.org/WebPage" itemscope="itemscope" class="home page-template-default page page-id-17 wp-custom-logo theme-astra woocommerce-no-js ast-desktop ast-page-builder-template ast-no-sidebar astra-4.6.4 ast-single-post ast-replace-site-logo-transparent ast-inherit-site-logo-transparent ast-theme-transparent-header ast-hfb-header elementor-default elementor-kit-24888 elementor-page elementor-page-17">

<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PW78FQ8"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>

<a class="skip-link screen-reader-text" href="#content" role="link" title="Skip to content">
Skip to content</a>
<div class="hfeed site" id="page">
<header class="site-header ast-primary-submenu-animation-slide-up header-main-layout-1 ast-primary-menu-enabled ast-hide-custom-menu-mobile ast-builder-menu-toggle-icon ast-mobile-header-inline" id="masthead" itemtype="https://schema.org/WPHeader" itemscope="itemscope" itemid="#masthead">
<div id="ast-desktop-header" data-toggle-type="dropdown">
<div class="ast-main-header-wrap main-header-bar-wrap ">
<div class="ast-primary-header-bar ast-primary-header main-header-bar site-header-focus-item" data-section="section-primary-header-builder">
<div class="site-primary-header-wrap ast-builder-grid-row-container site-header-focus-item ast-container" data-section="section-primary-header-builder">
<div class="ast-builder-grid-row ast-builder-grid-row-has-sides ast-builder-grid-row-no-center">
<div class="site-header-primary-section-left site-header-section ast-flex site-header-section-left">
<div class="ast-builder-layout-element ast-flex site-header-focus-item" data-section="title_tagline">
<div class="site-branding ast-site-identity" itemtype="https://schema.org/Organization" itemscope="itemscope">
<span class="site-logo-img"><a href="https://websitedemos.net/learndash-academy-02/" class="custom-logo-link transparent-custom-logo" rel="home" itemprop="url" aria-label="LearnDash Academy"><img width="147" height="43" src="https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/06/learn-dash-white-logo.svg" class="astra-logo-svg" alt decoding="async" /></a></span> </div>

</div>
</div>
<div class="site-header-primary-section-right site-header-section ast-flex ast-grid-right-section">
<div class="ast-builder-menu-1 ast-builder-menu ast-flex ast-builder-menu-1-focus-item ast-builder-layout-element site-header-focus-item" data-section="section-hb-menu-1">
<div class="ast-main-header-bar-alignment"><div class="main-header-bar-navigation"><nav class="site-navigation ast-flex-grow-1 navigation-accessibility site-header-focus-item" id="primary-site-navigation-desktop" aria-label="Site Navigation" itemtype="https://schema.org/SiteNavigationElement" itemscope="itemscope"><div class="main-navigation ast-inline-flex"><ul id="ast-hf-menu-1" class="main-header-menu ast-menu-shadow ast-nav-menu ast-flex  submenu-with-border astra-menu-animation-slide-up  stack-on-mobile"><li id="menu-item-1510" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-17 current_page_item menu-item-1510"><a href="https://websitedemos.net/learndash-academy-02/" aria-current="page" class="menu-link">Home</a></li>
<li id="menu-item-1508" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1508"><a href="https://websitedemos.net/learndash-academy-02/all-courses/" class="menu-link">All Courses</a></li>
<li id="menu-item-1509" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1509"><a href="https://websitedemos.net/learndash-academy-02/about/" class="menu-link">About</a></li>
<li id="menu-item-1506" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1506"><a href="https://websitedemos.net/learndash-academy-02/contact/" class="menu-link">Contact</a></li>
<li id="menu-item-1507" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1507"><a href="https://websitedemos.net/learndash-academy-02/my-account/" class="menu-link">My Account</a></li>
</ul></div></nav></div></div> </div>
</div>
</div>
</div>
</div>
</div>
<div class="ast-desktop-header-content content-align-flex-start ">
</div>
</div> 
<div id="ast-mobile-header" class="ast-mobile-header-wrap " data-type="dropdown">
<div class="ast-main-header-wrap main-header-bar-wrap">
<div class="ast-primary-header-bar ast-primary-header main-header-bar site-primary-header-wrap site-header-focus-item ast-builder-grid-row-layout-default ast-builder-grid-row-tablet-layout-default ast-builder-grid-row-mobile-layout-default" data-section="section-primary-header-builder">
<div class="ast-builder-grid-row ast-builder-grid-row-has-sides ast-builder-grid-row-no-center">
<div class="site-header-primary-section-left site-header-section ast-flex site-header-section-left">
<div class="ast-builder-layout-element ast-flex site-header-focus-item" data-section="title_tagline">
<div class="site-branding ast-site-identity" itemtype="https://schema.org/Organization" itemscope="itemscope">
<span class="site-logo-img"><a href="https://websitedemos.net/learndash-academy-02/" class="custom-logo-link transparent-custom-logo" rel="home" itemprop="url" aria-label="LearnDash Academy"><img width="147" height="43" src="https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/06/learn-dash-white-logo.svg" class="astra-logo-svg" alt decoding="async" /></a></span> </div>

</div>
</div>
<div class="site-header-primary-section-right site-header-section ast-flex ast-grid-right-section">
<div class="ast-builder-layout-element ast-flex site-header-focus-item" data-section="section-header-mobile-trigger">
<div class="ast-button-wrap">
<button type="button" class="menu-toggle main-header-menu-toggle ast-mobile-menu-trigger-fill" aria-expanded="false">
<span class="screen-reader-text">Main Menu</span>
<span class="mobile-menu-toggle-icon">
<span class="ahfb-svg-iconset ast-inline-flex svg-baseline"><svg class="ast-mobile-svg ast-menu-svg" fill="currentColor" version="1.1" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M3 13h18c0.552 0 1-0.448 1-1s-0.448-1-1-1h-18c-0.552 0-1 0.448-1 1s0.448 1 1 1zM3 7h18c0.552 0 1-0.448 1-1s-0.448-1-1-1h-18c-0.552 0-1 0.448-1 1s0.448 1 1 1zM3 19h18c0.552 0 1-0.448 1-1s-0.448-1-1-1h-18c-0.552 0-1 0.448-1 1s0.448 1 1 1z"></path></svg></span><span class="ahfb-svg-iconset ast-inline-flex svg-baseline"><svg class="ast-mobile-svg ast-close-svg" fill="currentColor" version="1.1" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M5.293 6.707l5.293 5.293-5.293 5.293c-0.391 0.391-0.391 1.024 0 1.414s1.024 0.391 1.414 0l5.293-5.293 5.293 5.293c0.391 0.391 1.024 0.391 1.414 0s0.391-1.024 0-1.414l-5.293-5.293 5.293-5.293c0.391-0.391 0.391-1.024 0-1.414s-1.024-0.391-1.414 0l-5.293 5.293-5.293-5.293c-0.391-0.391-1.024-0.391-1.414 0s-0.391 1.024 0 1.414z"></path></svg></span> </span>
</button>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="ast-mobile-header-content content-align-flex-start ">
<div class="ast-builder-menu-1 ast-builder-menu ast-flex ast-builder-menu-1-focus-item ast-builder-layout-element site-header-focus-item" data-section="section-hb-menu-1">
<div class="ast-main-header-bar-alignment"><div class="main-header-bar-navigation"><nav class="site-navigation ast-flex-grow-1 navigation-accessibility site-header-focus-item" id="primary-site-navigation-mobile" aria-label="Site Navigation" itemtype="https://schema.org/SiteNavigationElement" itemscope="itemscope"><div class="main-navigation ast-inline-flex"><ul id="ast-hf-menu-1" class="main-header-menu ast-menu-shadow ast-nav-menu ast-flex  submenu-with-border astra-menu-animation-slide-up  stack-on-mobile"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-17 current_page_item menu-item-1510"><a href="https://websitedemos.net/learndash-academy-02/" aria-current="page" class="menu-link">Home</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1508"><a href="https://websitedemos.net/learndash-academy-02/all-courses/" class="menu-link">All Courses</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1509"><a href="https://websitedemos.net/learndash-academy-02/about/" class="menu-link">About</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1506"><a href="https://websitedemos.net/learndash-academy-02/contact/" class="menu-link">Contact</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1507"><a href="https://websitedemos.net/learndash-academy-02/my-account/" class="menu-link">My Account</a></li>
</ul></div></nav></div></div> </div>
</div>
</div>
</header>
<div id="content" class="site-content">
<div class="ast-container">
<div id="primary" class="content-area primary">
<main id="main" class="site-main">
<article class="post-17 page type-page status-publish ast-article-single" id="post-17" itemtype="https://schema.org/CreativeWork" itemscope="itemscope">
<header class="entry-header ast-no-title ast-header-without-markup">
</header> 
<div class="entry-content clear" itemprop="text">
<div data-elementor-type="wp-post" data-elementor-id="17" class="elementor elementor-17">
<div class="elementor-element elementor-element-c258012 e-flex e-con-boxed e-con e-parent" data-id="c258012" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;content_width&quot;:&quot;boxed&quot;}" data-core-v316-plus="true">
<div class="e-con-inner">
<div class="elementor-element elementor-element-c7110a2 e-con-full e-flex e-con e-child" data-id="c7110a2" data-element_type="container" data-settings="{&quot;content_width&quot;:&quot;full&quot;}">
<div class="elementor-element elementor-element-06d06c0 elementor-widget elementor-widget-image-box" data-id="06d06c0" data-element_type="widget" data-widget_type="image-box.default">
<div class="elementor-widget-container">
<div class="elementor-image-box-wrapper"><div class="elementor-image-box-content"><h1 class="elementor-image-box-title">Learn from Industry Experts</h1><p class="elementor-image-box-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam maximus tortor at diam gravida posuere. Curabitur et malesuada mi. </p></div></div> </div>
</div>
<div class="elementor-element elementor-element-ec9c7a5 elementor-align-center elementor-mobile-align-center elementor-widget elementor-widget-button" data-id="ec9c7a5" data-element_type="widget" data-widget_type="button.default">
<div class="elementor-widget-container">
<div class="elementor-button-wrapper">
<a class="elementor-button elementor-button-link elementor-size-lg" href="#">
<span class="elementor-button-content-wrapper">
<span class="elementor-button-text">View All Courses</span>
</span>
</a>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="elementor-element elementor-element-c32b135 e-flex e-con-boxed e-con e-parent" data-id="c32b135" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;content_width&quot;:&quot;boxed&quot;}" data-core-v316-plus="true">
<div class="e-con-inner">
<div class="elementor-element elementor-element-1e80ded e-con-full e-flex e-con e-child" data-id="1e80ded" data-element_type="container" data-settings="{&quot;content_width&quot;:&quot;full&quot;}">
<div class="elementor-element elementor-element-ad7d1ce e-con-full e-flex e-con e-child" data-id="ad7d1ce" data-element_type="container" data-settings="{&quot;content_width&quot;:&quot;full&quot;}">
<div class="elementor-element elementor-element-ed8ee6b e-con-full e-flex e-con e-child" data-id="ed8ee6b" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;content_width&quot;:&quot;full&quot;}">
<div class="elementor-element elementor-element-af1303d elementor-view-default elementor-position-top elementor-mobile-position-top elementor-widget elementor-widget-icon-box" data-id="af1303d" data-element_type="widget" data-widget_type="icon-box.default">
<div class="elementor-widget-container">
<div class="elementor-icon-box-wrapper">
<div class="elementor-icon-box-icon">
<span class="elementor-icon elementor-animation-">
<i aria-hidden="true" class="fab fa-slideshare"></i> </span>
</div>
<div class="elementor-icon-box-content">
<h3 class="elementor-icon-box-title">
<span>
Actionable Training </span>
</h3>
<p class="elementor-icon-box-description">
Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
</div>
</div>
</div>
</div>
</div>
<div class="elementor-element elementor-element-e006f97 e-con-full e-flex e-con e-child" data-id="e006f97" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;content_width&quot;:&quot;full&quot;}">
<div class="elementor-element elementor-element-b7efb54 elementor-view-default elementor-position-top elementor-mobile-position-top elementor-widget elementor-widget-icon-box" data-id="b7efb54" data-element_type="widget" data-widget_type="icon-box.default">
<div class="elementor-widget-container">
<div class="elementor-icon-box-wrapper">
<div class="elementor-icon-box-icon">
<span class="elementor-icon elementor-animation-">
<i aria-hidden="true" class="fas fa-puzzle-piece"></i> </span>
</div>
<div class="elementor-icon-box-content">
<h3 class="elementor-icon-box-title">
<span>
Interesting Quizzes </span>
</h3>
<p class="elementor-icon-box-description">
Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
</div>
</div>
</div>
</div>
</div>
<div class="elementor-element elementor-element-28fdf1e e-con-full e-flex e-con e-child" data-id="28fdf1e" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;content_width&quot;:&quot;full&quot;}">
<div class="elementor-element elementor-element-a342a1c elementor-view-default elementor-position-top elementor-mobile-position-top elementor-widget elementor-widget-icon-box" data-id="a342a1c" data-element_type="widget" data-widget_type="icon-box.default">
<div class="elementor-widget-container">
<div class="elementor-icon-box-wrapper">
<div class="elementor-icon-box-icon">
<span class="elementor-icon elementor-animation-">
<i aria-hidden="true" class="fas fa-cube"></i> </span>
</div>
<div class="elementor-icon-box-content">
<h3 class="elementor-icon-box-title">
<span>
Premium Material </span>
</h3>
<p class="elementor-icon-box-description">
Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="elementor-element elementor-element-f77c2d9 e-flex e-con-boxed e-con e-parent" data-id="f77c2d9" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;shape_divider_bottom&quot;:&quot;waves&quot;,&quot;content_width&quot;:&quot;boxed&quot;}" data-core-v316-plus="true">
<div class="e-con-inner">
<div class="elementor-shape elementor-shape-bottom" data-negative="false">
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none">
<path class="elementor-shape-fill" d="M421.9,6.5c22.6-2.5,51.5,0.4,75.5,5.3c23.6,4.9,70.9,23.5,100.5,35.7c75.8,32.2,133.7,44.5,192.6,49.7
	c23.6,2.1,48.7,3.5,103.4-2.5c54.7-6,106.2-25.6,106.2-25.6V0H0v30.3c0,0,72,32.6,158.4,30.5c39.2-0.7,92.8-6.7,134-22.4
	c21.2-8.1,52.2-18.2,79.7-24.2C399.3,7.9,411.6,7.5,421.9,6.5z" />
</svg> </div>
<div class="elementor-element elementor-element-5b133d1 e-con-full e-flex e-con e-child" data-id="5b133d1" data-element_type="container" data-settings="{&quot;content_width&quot;:&quot;full&quot;}">
<div class="elementor-element elementor-element-ef27308 elementor-widget elementor-widget-image-box" data-id="ef27308" data-element_type="widget" data-widget_type="image-box.default">
<div class="elementor-widget-container">
<div class="elementor-image-box-wrapper"><div class="elementor-image-box-content"><h2 class="elementor-image-box-title">Our Most Popular Courses</h2><p class="elementor-image-box-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis ac eros ut dui bibendum ultricies. Maecenas egestas fringilla semper. </p></div></div> </div>
</div>
<div class="elementor-element elementor-element-5d8781d elementor-widget elementor-widget-shortcode" data-id="5d8781d" data-element_type="widget" data-widget_type="shortcode.default">
<div class="elementor-widget-container">
<div class="elementor-shortcode"><div id="ld_course_list"><div id="ld-course-list-content-b8d488cb0b8121dda83d79c33bf8585d" class="ld-course-list-content" data-shortcode-atts="{&quot;include_outer_wrapper&quot;:&quot;true&quot;,&quot;num&quot;:20,&quot;paged&quot;:1,&quot;post_type&quot;:&quot;sfwd-courses&quot;,&quot;post_status&quot;:&quot;publish&quot;,&quot;order&quot;:&quot;asc&quot;,&quot;orderby&quot;:&quot;ID&quot;,&quot;user_id&quot;:false,&quot;mycourses&quot;:null,&quot;mygroups&quot;:null,&quot;post__in&quot;:null,&quot;course_id&quot;:&quot;&quot;,&quot;meta_key&quot;:&quot;&quot;,&quot;meta_value&quot;:&quot;&quot;,&quot;meta_compare&quot;:&quot;&quot;,&quot;tag&quot;:&quot;&quot;,&quot;tag_id&quot;:0,&quot;tag__and&quot;:&quot;&quot;,&quot;tag__in&quot;:&quot;&quot;,&quot;tag__not_in&quot;:&quot;&quot;,&quot;tag_slug__and&quot;:&quot;&quot;,&quot;tag_slug__in&quot;:&quot;&quot;,&quot;cat&quot;:&quot;&quot;,&quot;category_name&quot;:0,&quot;category__and&quot;:&quot;&quot;,&quot;category__in&quot;:&quot;&quot;,&quot;category__not_in&quot;:&quot;&quot;,&quot;tax_compare&quot;:&quot;AND&quot;,&quot;categoryselector&quot;:&quot;true&quot;,&quot;show_thumbnail&quot;:&quot;true&quot;,&quot;show_content&quot;:&quot;true&quot;,&quot;author__in&quot;:&quot;&quot;,&quot;col&quot;:&quot;3&quot;,&quot;progress_bar&quot;:&quot;true&quot;,&quot;array&quot;:false,&quot;course_grid&quot;:&quot;true&quot;,&quot;thumb_size&quot;:&quot;course-thumb&quot;,&quot;course_categoryselector&quot;:&quot;&quot;,&quot;course_cat&quot;:&quot;&quot;,&quot;course_category_name&quot;:&quot;&quot;,&quot;course_category__and&quot;:&quot;&quot;,&quot;course_category__in&quot;:&quot;&quot;,&quot;course_category__not_in&quot;:&quot;&quot;,&quot;course_tag&quot;:&quot;&quot;,&quot;course_tag_id&quot;:&quot;&quot;,&quot;course_tag__and&quot;:&quot;&quot;,&quot;course_tag__in&quot;:&quot;&quot;,&quot;course_tag__not_in&quot;:&quot;&quot;,&quot;course_tag_slug__and&quot;:&quot;&quot;,&quot;course_tag_slug__in&quot;:&quot;&quot;,&quot;course_status&quot;:null}">
<div class="ld-course-list-items row">
<div class="ld_course_grid col-sm-8 col-md-4 ">
<article id="post-69" class=" learndash-not-available learndash-incomplete thumbnail course post-69 sfwd-courses type-sfwd-courses status-publish has-post-thumbnail hentry ld_course_category-free ast-article-single">
<div class="ld_course_grid_price free">
Free </div>
<a href="https://websitedemos.net/learndash-academy-02/courses/social-media-marketing/" rel="bookmark">
<img fetchpriority="high" decoding="async" width="400" height="223" src="https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/05/course-1-free-img-400x223.jpg" class="attachment-course-thumb size-course-thumb wp-post-image" alt srcset="https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/05/course-1-free-img-400x223.jpg 400w, https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/05/course-1-free-img-300x167.jpg 300w, https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/05/course-1-free-img-768x428.jpg 768w, https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/05/course-1-free-img.jpg 1024w" sizes="(max-width: 400px) 100vw, 400px" /> </a>
<div class="caption">
<h3 class="entry-title">Social Media Marketing</h3>
<p class="entry-content">Lorem ipsum dolor sit amet, consectetur adipiscing elit pellentesque porta.
</p>
<p class="ld_course_grid_button"><a class="btn btn-primary" role="button" href="https://websitedemos.net/learndash-academy-02/courses/social-media-marketing/" rel="bookmark">See more...</a></p>
<p>
<div class="learndash-wrapper learndash-widget">
<div class="ld-progress
			ld-progress-inline">
<div class="ld-progress-heading">
<div class="ld-progress-stats">
<div class="ld-progress-percentage ld-secondary-color">
0% Complete </div>
<div class="ld-progress-steps">
0/8 Steps </div>
</div> 
</div>
<div class="ld-progress-bar">
<div class="ld-progress-bar-percentage ld-secondary-background" style="width:0%"></div>
</div>
</div> 
</div>
</p>
</div>
</article>
</div>
<div class="ld_course_grid col-sm-8 col-md-4 ">
<article id="post-71" class=" learndash-not-available learndash-incomplete thumbnail course post-71 sfwd-courses type-sfwd-courses status-publish has-post-thumbnail hentry ld_course_category-free ast-article-single">
<div class="ld_course_grid_price free">
Free </div>
<a href="https://websitedemos.net/learndash-academy-02/courses/email-marketing-strategies/" rel="bookmark">
<img decoding="async" width="400" height="223" src="https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/05/course-2-free-img-400x223.jpg" class="attachment-course-thumb size-course-thumb wp-post-image" alt srcset="https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/05/course-2-free-img-400x223.jpg 400w, https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/05/course-2-free-img-300x167.jpg 300w, https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/05/course-2-free-img-768x428.jpg 768w, https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/05/course-2-free-img.jpg 1024w" sizes="(max-width: 400px) 100vw, 400px" /> </a>
<div class="caption">
<h3 class="entry-title">Email Marketing Strategies</h3>
<p class="entry-content">In porttitor ipsum eu justo condimentum euismod ullamcorper viverra. </p>
<p class="ld_course_grid_button"><a class="btn btn-primary" role="button" href="https://websitedemos.net/learndash-academy-02/courses/email-marketing-strategies/" rel="bookmark">See more...</a></p>
<p>
<div class="learndash-wrapper learndash-widget">
<div class="ld-progress
			ld-progress-inline">
<div class="ld-progress-heading">
<div class="ld-progress-stats">
<div class="ld-progress-percentage ld-secondary-color">
0% Complete </div>
<div class="ld-progress-steps">
0/2 Steps </div>
</div> 
</div>
<div class="ld-progress-bar">
<div class="ld-progress-bar-percentage ld-secondary-background" style="width:0%"></div>
</div>
</div> 
</div>
</p>
</div>
</article>
</div>
<div class="ld_course_grid col-sm-8 col-md-4 ">
<article id="post-24042" class=" learndash-not-available learndash-incomplete thumbnail course post-24042 sfwd-courses type-sfwd-courses status-publish has-post-thumbnail hentry ld_course_category-paid ast-article-single">
<div class="ld_course_grid_price price_$">
$ 1.00 </div>
<a href="https://websitedemos.net/learndash-academy-02/courses/content-marketing/" rel="bookmark">
<img decoding="async" width="400" height="223" src="https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2016/12/course-3-free-img-400x223.jpg" class="attachment-course-thumb size-course-thumb wp-post-image" alt srcset="https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2016/12/course-3-free-img-400x223.jpg 400w, https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2016/12/course-3-free-img-300x167.jpg 300w, https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2016/12/course-3-free-img-768x428.jpg 768w, https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2016/12/course-3-free-img-600x334.jpg 600w, https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2016/12/course-3-free-img.jpg 1024w" sizes="(max-width: 400px) 100vw, 400px" /> </a>
<div class="caption">
<h3 class="entry-title">Content Marketing</h3>
<p class="entry-content">Repellat perspiciatis cum! Doloremque ea viverra eu doloremque.</p>
<p class="ld_course_grid_button"><a class="btn btn-primary" role="button" href="https://websitedemos.net/learndash-academy-02/courses/content-marketing/" rel="bookmark">See more...</a></p>
<p>
<div class="learndash-wrapper learndash-widget">
<div class="ld-progress
			ld-progress-inline">
<div class="ld-progress-heading">
<div class="ld-progress-stats">
<div class="ld-progress-percentage ld-secondary-color">
0% Complete </div>
<div class="ld-progress-steps">
0/4 Steps </div>
</div> 
</div>
<div class="ld-progress-bar">
<div class="ld-progress-bar-percentage ld-secondary-background" style="width:0%"></div>
</div>
</div> 
</div>
</p>
</div>
</article>
</div>
</div>
</div>
<br style="clear:both"></div></div>
</div>
</div>
</div>
</div>
</div>
<div class="elementor-element elementor-element-6ffc418 e-flex e-con-boxed e-con e-parent" data-id="6ffc418" data-element_type="container" data-settings="{&quot;shape_divider_bottom&quot;:&quot;waves&quot;,&quot;content_width&quot;:&quot;boxed&quot;}" data-core-v316-plus="true">
<div class="e-con-inner">
<div class="elementor-shape elementor-shape-bottom" data-negative="false">
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none">
<path class="elementor-shape-fill" d="M421.9,6.5c22.6-2.5,51.5,0.4,75.5,5.3c23.6,4.9,70.9,23.5,100.5,35.7c75.8,32.2,133.7,44.5,192.6,49.7
	c23.6,2.1,48.7,3.5,103.4-2.5c54.7-6,106.2-25.6,106.2-25.6V0H0v30.3c0,0,72,32.6,158.4,30.5c39.2-0.7,92.8-6.7,134-22.4
	c21.2-8.1,52.2-18.2,79.7-24.2C399.3,7.9,411.6,7.5,421.9,6.5z" />
</svg> </div>
<div class="elementor-element elementor-element-408198d e-con-full e-flex e-con e-child" data-id="408198d" data-element_type="container" data-settings="{&quot;content_width&quot;:&quot;full&quot;}">
<div class="elementor-element elementor-element-547500f elementor-widget elementor-widget-image-box" data-id="547500f" data-element_type="widget" data-widget_type="image-box.default">
<div class="elementor-widget-container">
<div class="elementor-image-box-wrapper"><div class="elementor-image-box-content"><h2 class="elementor-image-box-title">Be in Demand with Our Professional Training</h2><p class="elementor-image-box-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis ac eros ut dui.</p></div></div> </div>
</div>
<div class="elementor-element elementor-element-76446ac e-con-full e-flex e-con e-child" data-id="76446ac" data-element_type="container" data-settings="{&quot;content_width&quot;:&quot;full&quot;}">
<div class="elementor-element elementor-element-99e60d7 e-con-full e-flex e-con e-child" data-id="99e60d7" data-element_type="container" data-settings="{&quot;content_width&quot;:&quot;full&quot;}">
<div class="elementor-element elementor-element-cfc1ce4 elementor-widget elementor-widget-image" data-id="cfc1ce4" data-element_type="widget" data-widget_type="image.default">
<div class="elementor-widget-container">
<figure class="wp-caption">
<img loading="lazy" decoding="async" width="700" height="700" src="https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/06/manager-free-img.png" class="attachment-large size-large wp-image-24379" alt srcset="https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/06/manager-free-img.png 700w, https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/06/manager-free-img-150x150.png 150w, https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/06/manager-free-img-300x300.png 300w" sizes="(max-width: 700px) 100vw, 700px" /> <figcaption class="widget-image-caption wp-caption-text">Dr. John Smith — Founder &amp; CEO.</figcaption>
</figure>
</div>
</div>
</div>
<div class="elementor-element elementor-element-767dbc4 e-con-full e-flex e-con e-child" data-id="767dbc4" data-element_type="container" data-settings="{&quot;content_width&quot;:&quot;full&quot;}">
<div class="elementor-element elementor-element-4a79e3e elementor-widget elementor-widget-accordion" data-id="4a79e3e" data-element_type="widget" data-widget_type="accordion.default">
<div class="elementor-widget-container">
<div class="elementor-accordion">
<div class="elementor-accordion-item">
<div id="elementor-tab-title-7801" class="elementor-tab-title" data-tab="1" role="button" aria-controls="elementor-tab-content-7801" aria-expanded="false">
<span class="elementor-accordion-icon elementor-accordion-icon-left" aria-hidden="true">
<span class="elementor-accordion-icon-closed"><i class="fas fa-caret-right"></i></span>
<span class="elementor-accordion-icon-opened"><i class="fas fa-caret-down"></i></span>
</span>
<a class="elementor-accordion-title" tabindex="0">Build Relevant Skills</a>
</div>
<div id="elementor-tab-content-7801" class="elementor-tab-content elementor-clearfix" data-tab="1" role="region" aria-labelledby="elementor-tab-title-7801"><p>Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.</p></div>
</div>
<div class="elementor-accordion-item">
<div id="elementor-tab-title-7802" class="elementor-tab-title" data-tab="2" role="button" aria-controls="elementor-tab-content-7802" aria-expanded="false">
<span class="elementor-accordion-icon elementor-accordion-icon-left" aria-hidden="true">
<span class="elementor-accordion-icon-closed"><i class="fas fa-caret-right"></i></span>
<span class="elementor-accordion-icon-opened"><i class="fas fa-caret-down"></i></span>
</span>
<a class="elementor-accordion-title" tabindex="0">Get The Right Path From The Best Learning Platform</a>
</div>
<div id="elementor-tab-content-7802" class="elementor-tab-content elementor-clearfix" data-tab="2" role="region" aria-labelledby="elementor-tab-title-7802"><p>Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.</p></div>
</div>
<div class="elementor-accordion-item">
<div id="elementor-tab-title-7803" class="elementor-tab-title" data-tab="3" role="button" aria-controls="elementor-tab-content-7803" aria-expanded="false">
<span class="elementor-accordion-icon elementor-accordion-icon-left" aria-hidden="true">
<span class="elementor-accordion-icon-closed"><i class="fas fa-caret-right"></i></span>
<span class="elementor-accordion-icon-opened"><i class="fas fa-caret-down"></i></span>
</span>
<a class="elementor-accordion-title" tabindex="0">Learn From The Professionals </a>
</div>
<div id="elementor-tab-content-7803" class="elementor-tab-content elementor-clearfix" data-tab="3" role="region" aria-labelledby="elementor-tab-title-7803"><p>Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.</p></div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="elementor-element elementor-element-783e0da e-con-full e-flex e-con e-child" data-id="783e0da" data-element_type="container" data-settings="{&quot;content_width&quot;:&quot;full&quot;}">
<div class="elementor-element elementor-element-99ff35b e-con-full e-flex e-con e-child" data-id="99ff35b" data-element_type="container" data-settings="{&quot;content_width&quot;:&quot;full&quot;}">
<div class="elementor-element elementor-element-05a113c elementor-widget elementor-widget-heading" data-id="05a113c" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h3 class="elementor-heading-title elementor-size-default">Industry Partners</h3> </div>
</div>
</div>
<div class="elementor-element elementor-element-4c226da e-con-full e-flex e-con e-child" data-id="4c226da" data-element_type="container" data-settings="{&quot;content_width&quot;:&quot;full&quot;}">
<div class="elementor-element elementor-element-ea04a74 elementor-widget elementor-widget-image-gallery" data-id="ea04a74" data-element_type="widget" data-widget_type="image-gallery.default">
<div class="elementor-widget-container">
<div class="elementor-image-gallery">
<div id="gallery-1" class="gallery galleryid-17 gallery-columns-5 gallery-size-full"><figure class="gallery-item">
<div class="gallery-icon landscape">
<img loading="lazy" decoding="async" width="179" height="100" src="https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2021/03/logo-1.svg" class="attachment-full size-full" alt />
</div></figure><figure class="gallery-item">
<div class="gallery-icon landscape">
<img loading="lazy" decoding="async" width="179" height="100" src="https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2021/03/logo-2.svg" class="attachment-full size-full" alt />
</div></figure><figure class="gallery-item">
<div class="gallery-icon landscape">
<img loading="lazy" decoding="async" width="179" height="100" src="https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2021/03/logo-3.svg" class="attachment-full size-full" alt />
</div></figure><figure class="gallery-item">
<div class="gallery-icon landscape">
<img loading="lazy" decoding="async" width="178" height="100" src="https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2021/03/logo-4.svg" class="attachment-full size-full" alt />
</div></figure><figure class="gallery-item">
<div class="gallery-icon landscape">
<img loading="lazy" decoding="async" width="178" height="100" src="https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2021/03/logo-5.svg" class="attachment-full size-full" alt />
</div></figure>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="elementor-element elementor-element-ce58a26 e-flex e-con-boxed e-con e-parent" data-id="ce58a26" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;content_width&quot;:&quot;boxed&quot;}" data-core-v316-plus="true">
<div class="e-con-inner">
<div class="elementor-element elementor-element-faf56f7 e-con-full e-flex e-con e-child" data-id="faf56f7" data-element_type="container" data-settings="{&quot;content_width&quot;:&quot;full&quot;}">
<div class="elementor-element elementor-element-57ef9ac elementor-widget elementor-widget-image-box" data-id="57ef9ac" data-element_type="widget" data-widget_type="image-box.default">
<div class="elementor-widget-container">
<div class="elementor-image-box-wrapper"><div class="elementor-image-box-content"><h2 class="elementor-image-box-title">What Our Students Have to Say</h2></div></div> </div>
</div>
<div class="elementor-element elementor-element-2e2ee70 e-con-full e-flex e-con e-child" data-id="2e2ee70" data-element_type="container" data-settings="{&quot;content_width&quot;:&quot;full&quot;}">
<div class="elementor-element elementor-element-2bcddea e-con-full e-flex e-con e-child" data-id="2bcddea" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;content_width&quot;:&quot;full&quot;}">
<div class="elementor-element elementor-element-b2788d6 elementor-widget elementor-widget-testimonial" data-id="b2788d6" data-element_type="widget" data-widget_type="testimonial.default">
<div class="elementor-widget-container">
<div class="elementor-testimonial-wrapper">
<div class="elementor-testimonial-content">Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.</div>
<div class="elementor-testimonial-meta elementor-has-image elementor-testimonial-image-position-aside">
<div class="elementor-testimonial-meta-inner">
<div class="elementor-testimonial-image">
<img loading="lazy" decoding="async" width="250" height="250" src="https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/05/testimonial4-free-img.jpg" class="attachment-full size-full wp-image-1523" alt srcset="https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/05/testimonial4-free-img.jpg 250w, https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/05/testimonial4-free-img-150x150.jpg 150w" sizes="(max-width: 250px) 100vw, 250px" /> </div>
<div class="elementor-testimonial-details">
<div class="elementor-testimonial-name">Kelvin Black</div>
<div class="elementor-testimonial-job">From Dallas, USA</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="elementor-element elementor-element-aadf686 e-con-full e-flex e-con e-child" data-id="aadf686" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;content_width&quot;:&quot;full&quot;}">
<div class="elementor-element elementor-element-8467593 elementor-widget elementor-widget-testimonial" data-id="8467593" data-element_type="widget" data-widget_type="testimonial.default">
<div class="elementor-widget-container">
<div class="elementor-testimonial-wrapper">
<div class="elementor-testimonial-content">Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.</div>
<div class="elementor-testimonial-meta elementor-has-image elementor-testimonial-image-position-aside">
<div class="elementor-testimonial-meta-inner">
<div class="elementor-testimonial-image">
<img loading="lazy" decoding="async" width="250" height="250" src="https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/05/testimonial1-free-img.jpg" class="attachment-full size-full wp-image-1522" alt srcset="https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/05/testimonial1-free-img.jpg 250w, https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/05/testimonial1-free-img-150x150.jpg 150w" sizes="(max-width: 250px) 100vw, 250px" /> </div>
<div class="elementor-testimonial-details">
<div class="elementor-testimonial-name">Zasha Swan</div>
<div class="elementor-testimonial-job">From Australia </div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="elementor-element elementor-element-6e83c28 e-con-full e-flex e-con e-child" data-id="6e83c28" data-element_type="container" data-settings="{&quot;content_width&quot;:&quot;full&quot;}">
<div class="elementor-element elementor-element-db51b66 e-con-full e-flex e-con e-child" data-id="db51b66" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;content_width&quot;:&quot;full&quot;}">
<div class="elementor-element elementor-element-5efb6bd elementor-widget elementor-widget-testimonial" data-id="5efb6bd" data-element_type="widget" data-widget_type="testimonial.default">
<div class="elementor-widget-container">
<div class="elementor-testimonial-wrapper">
<div class="elementor-testimonial-content">Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.</div>
<div class="elementor-testimonial-meta elementor-has-image elementor-testimonial-image-position-aside">
<div class="elementor-testimonial-meta-inner">
<div class="elementor-testimonial-image">
<img loading="lazy" decoding="async" width="250" height="250" src="https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/05/testimonial3-free-img.jpg" class="attachment-full size-full wp-image-1524" alt srcset="https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/05/testimonial3-free-img.jpg 250w, https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/05/testimonial3-free-img-150x150.jpg 150w" sizes="(max-width: 250px) 100vw, 250px" /> </div>
<div class="elementor-testimonial-details">
<div class="elementor-testimonial-name">Frank Jones</div>
<div class="elementor-testimonial-job">From Japan</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="elementor-element elementor-element-d6e3f2a e-con-full e-flex e-con e-child" data-id="d6e3f2a" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;content_width&quot;:&quot;full&quot;}">
<div class="elementor-element elementor-element-39d0596 elementor-widget elementor-widget-testimonial" data-id="39d0596" data-element_type="widget" data-widget_type="testimonial.default">
<div class="elementor-widget-container">
<div class="elementor-testimonial-wrapper">
<div class="elementor-testimonial-content">Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.</div>
<div class="elementor-testimonial-meta elementor-has-image elementor-testimonial-image-position-aside">
<div class="elementor-testimonial-meta-inner">
<div class="elementor-testimonial-image">
<img loading="lazy" decoding="async" width="250" height="250" src="https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/05/testimonial2-free-img.jpg" class="attachment-full size-full wp-image-1525" alt srcset="https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/05/testimonial2-free-img.jpg 250w, https://websitedemos.net/learndash-academy-02/wp-content/uploads/sites/457/2019/05/testimonial2-free-img-150x150.jpg 150w" sizes="(max-width: 250px) 100vw, 250px" /> </div>
<div class="elementor-testimonial-details">
<div class="elementor-testimonial-name">Jack Brownn</div>
<div class="elementor-testimonial-job">From London, UK</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</article>
</main>
</div>
</div> 
</div>
<footer class="site-footer" id="colophon" itemtype="https://schema.org/WPFooter" itemscope="itemscope" itemid="#colophon">
<div class="site-primary-footer-wrap ast-builder-grid-row-container site-footer-focus-item ast-builder-grid-row-3-cwide ast-builder-grid-row-tablet-full ast-builder-grid-row-mobile-full ast-footer-row-stack ast-footer-row-tablet-stack ast-footer-row-mobile-stack" data-section="section-primary-footer-builder">
<div class="ast-builder-grid-row-container-inner">
<div class="ast-builder-footer-grid-columns site-primary-footer-inner-wrap ast-builder-grid-row">
<div class="site-footer-primary-section-1 site-footer-section site-footer-section-1">
</div>
<div class="site-footer-primary-section-2 site-footer-section site-footer-section-2">
<aside class="footer-widget-area widget-area site-footer-focus-item footer-widget-area-inner" data-section="sidebar-widgets-footer-widget-1" aria-label="Footer Widget 1">
<section id="block-6" class="widget widget_block">
<h2 class="has-text-align-center has-ast-global-color-5-color has-text-color wp-block-heading">Join Our 7452 Happy Students​ Today!</h2>
</section><section id="block-7" class="widget widget_block widget_text">
<p>Enter description text here. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.​</p>
</section><section id="block-4" class="widget widget_block">
<div class="wp-block-buttons is-content-justification-center is-layout-flex wp-block-buttons-is-layout-flex">
<div class="wp-block-button"><a class="wp-block-button__link has-ast-global-color-0-color has-ast-global-color-5-background-color has-text-color has-background">Start Learning</a></div>
</div>
</section> </aside>
</div>
<div class="site-footer-primary-section-3 site-footer-section site-footer-section-3">
</div>
</div>
</div>
</div>
<div class="site-below-footer-wrap ast-builder-grid-row-container site-footer-focus-item ast-builder-grid-row-full ast-builder-grid-row-tablet-full ast-builder-grid-row-mobile-full ast-footer-row-stack ast-footer-row-tablet-stack ast-footer-row-mobile-stack" data-section="section-below-footer-builder">
<div class="ast-builder-grid-row-container-inner">
<div class="ast-builder-footer-grid-columns site-below-footer-inner-wrap ast-builder-grid-row">
<div class="site-footer-below-section-1 site-footer-section site-footer-section-1">
<div class="ast-builder-layout-element ast-flex site-footer-focus-item ast-footer-copyright" data-section="section-footer-builder">
<div class="ast-footer-copyright"><p>Copyright © 2024 LearnDash Academy</p>
</div> </div>
</div>
</div>
</div>
</div>
</footer>
</div>
<div id="showcase-cta-entry-root" class="st-customizer-cta"></div> <script>
		(function () {
			var c = document.body.className;
			c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
			document.body.className = c;
		})();
	</script>
<link rel="stylesheet" id="wc-blocks-style-css" href="https://websitedemos.net/learndash-academy-02/wp-content/plugins/woocommerce/assets/client/blocks/wc-blocks.css?ver=1706766794" media="all" />
<link rel="stylesheet" id="astra-galleries-css-css" href="https://websitedemos.net/learndash-academy-02/wp-content/themes/astra/assets/css/minified/galleries.min.css?ver=4.6.4" media="all" />
<style id="core-block-supports-inline-css">
/**
 * Core styles: block-supports
 */

</style>
<script src="https://websitedemos.net/learndash-academy-02/wp-content/plugins/learndash-course-grid/assets/js/script.js?ver=1.6.0" id="learndash_course_grid_js-js"></script>
<script id="astra-theme-js-js-extra">
var astra = {"break_point":"921","isRtl":"","is_scroll_to_id":"","is_scroll_to_top":"","is_header_footer_builder_active":"1"};
</script>
<script src="https://websitedemos.net/learndash-academy-02/wp-content/themes/astra/assets/js/unminified/frontend.js?ver=4.6.4" id="astra-theme-js-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/dist/i18n.js?ver=bbbb3a5d0e355b0e5159" id="wp-i18n-js"></script>
<script id="wp-i18n-js-after">
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
</script>
<script id="presto-components-js-extra">
var prestoComponents = {"url":"https:\/\/websitedemos.net\/learndash-academy-02\/wp-content\/plugins\/presto-player\/dist\/components\/web-components\/web-components.esm.js?ver=1706766785"};
var prestoPlayer = {"plugin_url":"https:\/\/websitedemos.net\/learndash-academy-02\/wp-content\/plugins\/presto-player\/","logged_in":"","root":"https:\/\/websitedemos.net\/learndash-academy-02\/wp-json\/","nonce":"16040d55ee","ajaxurl":"https:\/\/websitedemos.net\/learndash-academy-02\/wp-admin\/admin-ajax.php","isAdmin":"","isSetup":{"bunny":false},"proVersion":"","isPremium":"","wpVersionString":"wp\/v2\/","prestoVersionString":"presto-player\/v1\/","debug":"1","debug_navigator":"","i18n":{"skip":"Skip","rewatch":"Rewatch","emailPlaceholder":"Email address","emailDefaultHeadline":"Enter your email to play this episode.","chapters":"Chapters","show_chapters":"Show Chapters","hide_chapters":"Hide Chapters","restart":"Restart","rewind":"Rewind {seektime}s","play":"Play","pause":"Pause","fastForward":"Forward {seektime}s","seek":"Seek","seekLabel":"{currentTime} of {duration}","played":"Played","buffered":"Buffered","currentTime":"Current time","duration":"Duration","volume":"Volume","mute":"Mute","unmute":"Unmute","enableCaptions":"Enable captions","disableCaptions":"Disable captions","download":"Download","enterFullscreen":"Enter fullscreen","exitFullscreen":"Exit fullscreen","frameTitle":"Player for {title}","captions":"Captions","settings":"Settings","pip":"PIP","menuBack":"Go back to previous menu","speed":"Speed","normal":"Normal","quality":"Quality","loop":"Loop","start":"Start","end":"End","all":"All","reset":"Reset","disabled":"Disabled","enabled":"Enabled","advertisement":"Ad","qualityBadge":{"2160":"4K","1440":"HD","1080":"HD","720":"HD","576":"SD","480":"SD"},"auto":"AUTO","upNext":"Up Next","startOver":"Start Over"},"learndash":[]};
var prestoComponents = {"url":"https:\/\/websitedemos.net\/learndash-academy-02\/wp-content\/plugins\/presto-player\/dist\/components\/web-components\/web-components.esm.js?ver=1706766785"};
var prestoPlayer = {"plugin_url":"https:\/\/websitedemos.net\/learndash-academy-02\/wp-content\/plugins\/presto-player\/","logged_in":"","root":"https:\/\/websitedemos.net\/learndash-academy-02\/wp-json\/","nonce":"16040d55ee","ajaxurl":"https:\/\/websitedemos.net\/learndash-academy-02\/wp-admin\/admin-ajax.php","isAdmin":"","isSetup":{"bunny":false},"proVersion":"","isPremium":"","wpVersionString":"wp\/v2\/","prestoVersionString":"presto-player\/v1\/","debug":"1","debug_navigator":"","i18n":{"skip":"Skip","rewatch":"Rewatch","emailPlaceholder":"Email address","emailDefaultHeadline":"Enter your email to play this episode.","chapters":"Chapters","show_chapters":"Show Chapters","hide_chapters":"Hide Chapters","restart":"Restart","rewind":"Rewind {seektime}s","play":"Play","pause":"Pause","fastForward":"Forward {seektime}s","seek":"Seek","seekLabel":"{currentTime} of {duration}","played":"Played","buffered":"Buffered","currentTime":"Current time","duration":"Duration","volume":"Volume","mute":"Mute","unmute":"Unmute","enableCaptions":"Enable captions","disableCaptions":"Disable captions","download":"Download","enterFullscreen":"Enter fullscreen","exitFullscreen":"Exit fullscreen","frameTitle":"Player for {title}","captions":"Captions","settings":"Settings","pip":"PIP","menuBack":"Go back to previous menu","speed":"Speed","normal":"Normal","quality":"Quality","loop":"Loop","start":"Start","end":"End","all":"All","reset":"Reset","disabled":"Disabled","enabled":"Enabled","advertisement":"Ad","qualityBadge":{"2160":"4K","1440":"HD","1080":"HD","720":"HD","576":"SD","480":"SD"},"auto":"AUTO","upNext":"Up Next","startOver":"Start Over"},"learndash":[]};
</script>
<script src="https://websitedemos.net/learndash-academy-02/wp-content/plugins/presto-player/src/player/player-static.js?ver=1706766785" type="module" defer></script><script src="//websitedemos.net/learndash-academy-02/wp-content/plugins/sfwd-lms/themes/legacy/templates/learndash_pager.js?ver=3.2.3.3-1707647724" id="learndash_pager_js-js"></script>
<script id="learndash_template_script_js-js-extra">
var sfwd_data = {"json":"{\"ajaxurl\":\"https:\\\/\\\/websitedemos.net\\\/learndash-academy-02\\\/wp-admin\\\/admin-ajax.php\"}"};
</script>
<script src="//websitedemos.net/learndash-academy-02/wp-content/plugins/sfwd-lms/themes/legacy/templates/learndash_template_script.js?ver=3.2.3.3-1707647724" id="learndash_template_script_js-js"></script>
<script id="learndash-front-js-extra">
var ajaxurl = "https:\/\/websitedemos.net\/learndash-academy-02\/wp-admin\/admin-ajax.php";
var ldVars = {"postID":"17","videoReqMsg":"You must watch the video before accessing this content"};
</script>
<script src="//websitedemos.net/learndash-academy-02/wp-content/plugins/sfwd-lms/themes/ld30/assets/js/learndash.js?ver=3.2.3.3-1707647724" id="learndash-front-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-content/plugins/woocommerce/assets/js/sourcebuster/sourcebuster.js?ver=8.5.2" id="sourcebuster-js-js"></script>
<script id="wc-order-attribution-js-extra">
var wc_order_attribution = {"params":{"lifetime":1.0e-5,"session":30,"ajaxurl":"https:\/\/websitedemos.net\/learndash-academy-02\/wp-admin\/admin-ajax.php","prefix":"wc_order_attribution_","allowTracking":"yes"}};
</script>
<script src="https://websitedemos.net/learndash-academy-02/wp-content/plugins/woocommerce/assets/js/frontend/order-attribution.js?ver=8.5.2" id="wc-order-attribution-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/dist/vendor/react.js?ver=18.2.0" id="react-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/dist/deprecated.js?ver=191d7f3a805131fb5530" id="wp-deprecated-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/dist/dom.js?ver=94b90b103ee0a85674c5" id="wp-dom-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/dist/vendor/react-dom.js?ver=18.2.0" id="react-dom-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/dist/escape-html.js?ver=53958a11eeadd4731b85" id="wp-escape-html-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/dist/element.js?ver=10b6413a3a6da33b2264" id="wp-element-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/dist/is-shallow-equal.js?ver=33c5f8741df506b8861c" id="wp-is-shallow-equal-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/dist/keycodes.js?ver=063e98669c67a1b84b0a" id="wp-keycodes-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/dist/priority-queue.js?ver=3b99a501866912a283bc" id="wp-priority-queue-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/dist/compose.js?ver=228e7d7fccaae67c220c" id="wp-compose-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/dist/private-apis.js?ver=58cbfa9c985f4fae85c8" id="wp-private-apis-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/dist/redux-routine.js?ver=154d0b98be93c015ec5a" id="wp-redux-routine-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/dist/data.js?ver=2b5bb06caaeb5048ed96" id="wp-data-js"></script>
<script id="wp-data-js-after">
( function() {
	var userId = 0;
	var storageKey = "WP_DATA_USER_" + userId;
	wp.data
		.use( wp.data.plugins.persistence, { storageKey: storageKey } );
} )();
</script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/dist/vendor/lodash.js?ver=4.17.19" id="lodash-js"></script>
<script id="lodash-js-after">
window.lodash = _.noConflict();
</script>
<script src="https://websitedemos.net/learndash-academy-02/wp-content/plugins/woocommerce/assets/client/blocks/wc-blocks-registry.js?ver=1c879273bd5c193cad0a" id="wc-blocks-registry-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/dist/api-fetch.js?ver=064121ed1abb9ed32a10" id="wp-api-fetch-js"></script>
<script id="wp-api-fetch-js-after">
wp.apiFetch.use( wp.apiFetch.createRootURLMiddleware( "https://websitedemos.net/learndash-academy-02/wp-json/" ) );
wp.apiFetch.nonceMiddleware = wp.apiFetch.createNonceMiddleware( "16040d55ee" );
wp.apiFetch.use( wp.apiFetch.nonceMiddleware );
wp.apiFetch.use( wp.apiFetch.mediaUploadMiddleware );
wp.apiFetch.nonceEndpoint = "https://websitedemos.net/learndash-academy-02/wp-admin/admin-ajax.php?action=rest-nonce";
</script>
<script id="wc-settings-js-before">
var wcSettings = wcSettings || JSON.parse( decodeURIComponent( '%7B%22shippingCostRequiresAddress%22%3Afalse%2C%22adminUrl%22%3A%22https%3A%5C%2F%5C%2Fwebsitedemos.net%5C%2Flearndash-academy-02%5C%2Fwp-admin%5C%2F%22%2C%22countries%22%3A%7B%22AF%22%3A%22Afghanistan%22%2C%22AX%22%3A%22%5Cu00c5land%20Islands%22%2C%22AL%22%3A%22Albania%22%2C%22DZ%22%3A%22Algeria%22%2C%22AS%22%3A%22American%20Samoa%22%2C%22AD%22%3A%22Andorra%22%2C%22AO%22%3A%22Angola%22%2C%22AI%22%3A%22Anguilla%22%2C%22AQ%22%3A%22Antarctica%22%2C%22AG%22%3A%22Antigua%20and%20Barbuda%22%2C%22AR%22%3A%22Argentina%22%2C%22AM%22%3A%22Armenia%22%2C%22AW%22%3A%22Aruba%22%2C%22AU%22%3A%22Australia%22%2C%22AT%22%3A%22Austria%22%2C%22AZ%22%3A%22Azerbaijan%22%2C%22BS%22%3A%22Bahamas%22%2C%22BH%22%3A%22Bahrain%22%2C%22BD%22%3A%22Bangladesh%22%2C%22BB%22%3A%22Barbados%22%2C%22BY%22%3A%22Belarus%22%2C%22PW%22%3A%22Belau%22%2C%22BE%22%3A%22Belgium%22%2C%22BZ%22%3A%22Belize%22%2C%22BJ%22%3A%22Benin%22%2C%22BM%22%3A%22Bermuda%22%2C%22BT%22%3A%22Bhutan%22%2C%22BO%22%3A%22Bolivia%22%2C%22BQ%22%3A%22Bonaire%2C%20Saint%20Eustatius%20and%20Saba%22%2C%22BA%22%3A%22Bosnia%20and%20Herzegovina%22%2C%22BW%22%3A%22Botswana%22%2C%22BV%22%3A%22Bouvet%20Island%22%2C%22BR%22%3A%22Brazil%22%2C%22IO%22%3A%22British%20Indian%20Ocean%20Territory%22%2C%22BN%22%3A%22Brunei%22%2C%22BG%22%3A%22Bulgaria%22%2C%22BF%22%3A%22Burkina%20Faso%22%2C%22BI%22%3A%22Burundi%22%2C%22KH%22%3A%22Cambodia%22%2C%22CM%22%3A%22Cameroon%22%2C%22CA%22%3A%22Canada%22%2C%22CV%22%3A%22Cape%20Verde%22%2C%22KY%22%3A%22Cayman%20Islands%22%2C%22CF%22%3A%22Central%20African%20Republic%22%2C%22TD%22%3A%22Chad%22%2C%22CL%22%3A%22Chile%22%2C%22CN%22%3A%22China%22%2C%22CX%22%3A%22Christmas%20Island%22%2C%22CC%22%3A%22Cocos%20%28Keeling%29%20Islands%22%2C%22CO%22%3A%22Colombia%22%2C%22KM%22%3A%22Comoros%22%2C%22CG%22%3A%22Congo%20%28Brazzaville%29%22%2C%22CD%22%3A%22Congo%20%28Kinshasa%29%22%2C%22CK%22%3A%22Cook%20Islands%22%2C%22CR%22%3A%22Costa%20Rica%22%2C%22HR%22%3A%22Croatia%22%2C%22CU%22%3A%22Cuba%22%2C%22CW%22%3A%22Cura%26ccedil%3Bao%22%2C%22CY%22%3A%22Cyprus%22%2C%22CZ%22%3A%22Czech%20Republic%22%2C%22DK%22%3A%22Denmark%22%2C%22DJ%22%3A%22Djibouti%22%2C%22DM%22%3A%22Dominica%22%2C%22DO%22%3A%22Dominican%20Republic%22%2C%22EC%22%3A%22Ecuador%22%2C%22EG%22%3A%22Egypt%22%2C%22SV%22%3A%22El%20Salvador%22%2C%22GQ%22%3A%22Equatorial%20Guinea%22%2C%22ER%22%3A%22Eritrea%22%2C%22EE%22%3A%22Estonia%22%2C%22SZ%22%3A%22Eswatini%22%2C%22ET%22%3A%22Ethiopia%22%2C%22FK%22%3A%22Falkland%20Islands%22%2C%22FO%22%3A%22Faroe%20Islands%22%2C%22FJ%22%3A%22Fiji%22%2C%22FI%22%3A%22Finland%22%2C%22FR%22%3A%22France%22%2C%22GF%22%3A%22French%20Guiana%22%2C%22PF%22%3A%22French%20Polynesia%22%2C%22TF%22%3A%22French%20Southern%20Territories%22%2C%22GA%22%3A%22Gabon%22%2C%22GM%22%3A%22Gambia%22%2C%22GE%22%3A%22Georgia%22%2C%22DE%22%3A%22Germany%22%2C%22GH%22%3A%22Ghana%22%2C%22GI%22%3A%22Gibraltar%22%2C%22GR%22%3A%22Greece%22%2C%22GL%22%3A%22Greenland%22%2C%22GD%22%3A%22Grenada%22%2C%22GP%22%3A%22Guadeloupe%22%2C%22GU%22%3A%22Guam%22%2C%22GT%22%3A%22Guatemala%22%2C%22GG%22%3A%22Guernsey%22%2C%22GN%22%3A%22Guinea%22%2C%22GW%22%3A%22Guinea-Bissau%22%2C%22GY%22%3A%22Guyana%22%2C%22HT%22%3A%22Haiti%22%2C%22HM%22%3A%22Heard%20Island%20and%20McDonald%20Islands%22%2C%22HN%22%3A%22Honduras%22%2C%22HK%22%3A%22Hong%20Kong%22%2C%22HU%22%3A%22Hungary%22%2C%22IS%22%3A%22Iceland%22%2C%22IN%22%3A%22India%22%2C%22ID%22%3A%22Indonesia%22%2C%22IR%22%3A%22Iran%22%2C%22IQ%22%3A%22Iraq%22%2C%22IE%22%3A%22Ireland%22%2C%22IM%22%3A%22Isle%20of%20Man%22%2C%22IL%22%3A%22Israel%22%2C%22IT%22%3A%22Italy%22%2C%22CI%22%3A%22Ivory%20Coast%22%2C%22JM%22%3A%22Jamaica%22%2C%22JP%22%3A%22Japan%22%2C%22JE%22%3A%22Jersey%22%2C%22JO%22%3A%22Jordan%22%2C%22KZ%22%3A%22Kazakhstan%22%2C%22KE%22%3A%22Kenya%22%2C%22KI%22%3A%22Kiribati%22%2C%22KW%22%3A%22Kuwait%22%2C%22KG%22%3A%22Kyrgyzstan%22%2C%22LA%22%3A%22Laos%22%2C%22LV%22%3A%22Latvia%22%2C%22LB%22%3A%22Lebanon%22%2C%22LS%22%3A%22Lesotho%22%2C%22LR%22%3A%22Liberia%22%2C%22LY%22%3A%22Libya%22%2C%22LI%22%3A%22Liechtenstein%22%2C%22LT%22%3A%22Lithuania%22%2C%22LU%22%3A%22Luxembourg%22%2C%22MO%22%3A%22Macao%22%2C%22MG%22%3A%22Madagascar%22%2C%22MW%22%3A%22Malawi%22%2C%22MY%22%3A%22Malaysia%22%2C%22MV%22%3A%22Maldives%22%2C%22ML%22%3A%22Mali%22%2C%22MT%22%3A%22Malta%22%2C%22MH%22%3A%22Marshall%20Islands%22%2C%22MQ%22%3A%22Martinique%22%2C%22MR%22%3A%22Mauritania%22%2C%22MU%22%3A%22Mauritius%22%2C%22YT%22%3A%22Mayotte%22%2C%22MX%22%3A%22Mexico%22%2C%22FM%22%3A%22Micronesia%22%2C%22MD%22%3A%22Moldova%22%2C%22MC%22%3A%22Monaco%22%2C%22MN%22%3A%22Mongolia%22%2C%22ME%22%3A%22Montenegro%22%2C%22MS%22%3A%22Montserrat%22%2C%22MA%22%3A%22Morocco%22%2C%22MZ%22%3A%22Mozambique%22%2C%22MM%22%3A%22Myanmar%22%2C%22NA%22%3A%22Namibia%22%2C%22NR%22%3A%22Nauru%22%2C%22NP%22%3A%22Nepal%22%2C%22NL%22%3A%22Netherlands%22%2C%22NC%22%3A%22New%20Caledonia%22%2C%22NZ%22%3A%22New%20Zealand%22%2C%22NI%22%3A%22Nicaragua%22%2C%22NE%22%3A%22Niger%22%2C%22NG%22%3A%22Nigeria%22%2C%22NU%22%3A%22Niue%22%2C%22NF%22%3A%22Norfolk%20Island%22%2C%22KP%22%3A%22North%20Korea%22%2C%22MK%22%3A%22North%20Macedonia%22%2C%22MP%22%3A%22Northern%20Mariana%20Islands%22%2C%22NO%22%3A%22Norway%22%2C%22OM%22%3A%22Oman%22%2C%22PK%22%3A%22Pakistan%22%2C%22PS%22%3A%22Palestinian%20Territory%22%2C%22PA%22%3A%22Panama%22%2C%22PG%22%3A%22Papua%20New%20Guinea%22%2C%22PY%22%3A%22Paraguay%22%2C%22PE%22%3A%22Peru%22%2C%22PH%22%3A%22Philippines%22%2C%22PN%22%3A%22Pitcairn%22%2C%22PL%22%3A%22Poland%22%2C%22PT%22%3A%22Portugal%22%2C%22PR%22%3A%22Puerto%20Rico%22%2C%22QA%22%3A%22Qatar%22%2C%22RE%22%3A%22Reunion%22%2C%22RO%22%3A%22Romania%22%2C%22RU%22%3A%22Russia%22%2C%22RW%22%3A%22Rwanda%22%2C%22ST%22%3A%22S%26atilde%3Bo%20Tom%26eacute%3B%20and%20Pr%26iacute%3Bncipe%22%2C%22BL%22%3A%22Saint%20Barth%26eacute%3Blemy%22%2C%22SH%22%3A%22Saint%20Helena%22%2C%22KN%22%3A%22Saint%20Kitts%20and%20Nevis%22%2C%22LC%22%3A%22Saint%20Lucia%22%2C%22SX%22%3A%22Saint%20Martin%20%28Dutch%20part%29%22%2C%22MF%22%3A%22Saint%20Martin%20%28French%20part%29%22%2C%22PM%22%3A%22Saint%20Pierre%20and%20Miquelon%22%2C%22VC%22%3A%22Saint%20Vincent%20and%20the%20Grenadines%22%2C%22WS%22%3A%22Samoa%22%2C%22SM%22%3A%22San%20Marino%22%2C%22SA%22%3A%22Saudi%20Arabia%22%2C%22SN%22%3A%22Senegal%22%2C%22RS%22%3A%22Serbia%22%2C%22SC%22%3A%22Seychelles%22%2C%22SL%22%3A%22Sierra%20Leone%22%2C%22SG%22%3A%22Singapore%22%2C%22SK%22%3A%22Slovakia%22%2C%22SI%22%3A%22Slovenia%22%2C%22SB%22%3A%22Solomon%20Islands%22%2C%22SO%22%3A%22Somalia%22%2C%22ZA%22%3A%22South%20Africa%22%2C%22GS%22%3A%22South%20Georgia%5C%2FSandwich%20Islands%22%2C%22KR%22%3A%22South%20Korea%22%2C%22SS%22%3A%22South%20Sudan%22%2C%22ES%22%3A%22Spain%22%2C%22LK%22%3A%22Sri%20Lanka%22%2C%22SD%22%3A%22Sudan%22%2C%22SR%22%3A%22Suriname%22%2C%22SJ%22%3A%22Svalbard%20and%20Jan%20Mayen%22%2C%22SE%22%3A%22Sweden%22%2C%22CH%22%3A%22Switzerland%22%2C%22SY%22%3A%22Syria%22%2C%22TW%22%3A%22Taiwan%22%2C%22TJ%22%3A%22Tajikistan%22%2C%22TZ%22%3A%22Tanzania%22%2C%22TH%22%3A%22Thailand%22%2C%22TL%22%3A%22Timor-Leste%22%2C%22TG%22%3A%22Togo%22%2C%22TK%22%3A%22Tokelau%22%2C%22TO%22%3A%22Tonga%22%2C%22TT%22%3A%22Trinidad%20and%20Tobago%22%2C%22TN%22%3A%22Tunisia%22%2C%22TR%22%3A%22Turkey%22%2C%22TM%22%3A%22Turkmenistan%22%2C%22TC%22%3A%22Turks%20and%20Caicos%20Islands%22%2C%22TV%22%3A%22Tuvalu%22%2C%22UG%22%3A%22Uganda%22%2C%22UA%22%3A%22Ukraine%22%2C%22AE%22%3A%22United%20Arab%20Emirates%22%2C%22GB%22%3A%22United%20Kingdom%20%28UK%29%22%2C%22US%22%3A%22United%20States%20%28US%29%22%2C%22UM%22%3A%22United%20States%20%28US%29%20Minor%20Outlying%20Islands%22%2C%22UY%22%3A%22Uruguay%22%2C%22UZ%22%3A%22Uzbekistan%22%2C%22VU%22%3A%22Vanuatu%22%2C%22VA%22%3A%22Vatican%22%2C%22VE%22%3A%22Venezuela%22%2C%22VN%22%3A%22Vietnam%22%2C%22VG%22%3A%22Virgin%20Islands%20%28British%29%22%2C%22VI%22%3A%22Virgin%20Islands%20%28US%29%22%2C%22WF%22%3A%22Wallis%20and%20Futuna%22%2C%22EH%22%3A%22Western%20Sahara%22%2C%22YE%22%3A%22Yemen%22%2C%22ZM%22%3A%22Zambia%22%2C%22ZW%22%3A%22Zimbabwe%22%7D%2C%22currency%22%3A%7B%22code%22%3A%22USD%22%2C%22precision%22%3A2%2C%22symbol%22%3A%22%24%22%2C%22symbolPosition%22%3A%22left%22%2C%22decimalSeparator%22%3A%22.%22%2C%22thousandSeparator%22%3A%22%2C%22%2C%22priceFormat%22%3A%22%251%24s%252%24s%22%7D%2C%22currentUserId%22%3A0%2C%22currentUserIsAdmin%22%3Afalse%2C%22dateFormat%22%3A%22F%20j%2C%20Y%22%2C%22homeUrl%22%3A%22https%3A%5C%2F%5C%2Fwebsitedemos.net%5C%2Flearndash-academy-02%5C%2F%22%2C%22locale%22%3A%7B%22siteLocale%22%3A%22en_US%22%2C%22userLocale%22%3A%22en_US%22%2C%22weekdaysShort%22%3A%5B%22Sun%22%2C%22Mon%22%2C%22Tue%22%2C%22Wed%22%2C%22Thu%22%2C%22Fri%22%2C%22Sat%22%5D%7D%2C%22dashboardUrl%22%3A%22https%3A%5C%2F%5C%2Fwebsitedemos.net%5C%2Flearndash-academy-02%5C%2Fmy-account-2%5C%2F%22%2C%22orderStatuses%22%3A%7B%22pending%22%3A%22Pending%20payment%22%2C%22processing%22%3A%22Processing%22%2C%22on-hold%22%3A%22On%20hold%22%2C%22completed%22%3A%22Completed%22%2C%22cancelled%22%3A%22Cancelled%22%2C%22refunded%22%3A%22Refunded%22%2C%22failed%22%3A%22Failed%22%2C%22checkout-draft%22%3A%22Draft%22%7D%2C%22placeholderImgSrc%22%3A%22https%3A%5C%2F%5C%2Fwebsitedemos.net%5C%2Flearndash-academy-02%5C%2Fwp-content%5C%2Fuploads%5C%2Fsites%5C%2F457%5C%2Fwoocommerce-placeholder.png%22%2C%22productsSettings%22%3A%7B%22cartRedirectAfterAdd%22%3Afalse%7D%2C%22siteTitle%22%3A%22LearnDash%20Academy%22%2C%22storePages%22%3A%7B%22myaccount%22%3A%7B%22id%22%3A25169%2C%22title%22%3A%22My%20account%22%2C%22permalink%22%3A%22https%3A%5C%2F%5C%2Fwebsitedemos.net%5C%2Flearndash-academy-02%5C%2Fmy-account-2%5C%2F%22%7D%2C%22shop%22%3A%7B%22id%22%3A25166%2C%22title%22%3A%22Shop%22%2C%22permalink%22%3A%22https%3A%5C%2F%5C%2Fwebsitedemos.net%5C%2Flearndash-academy-02%5C%2Fshop%5C%2F%22%7D%2C%22cart%22%3A%7B%22id%22%3A25167%2C%22title%22%3A%22Cart%22%2C%22permalink%22%3A%22https%3A%5C%2F%5C%2Fwebsitedemos.net%5C%2Flearndash-academy-02%5C%2Fcart%5C%2F%22%7D%2C%22checkout%22%3A%7B%22id%22%3A25168%2C%22title%22%3A%22Checkout%22%2C%22permalink%22%3A%22https%3A%5C%2F%5C%2Fwebsitedemos.net%5C%2Flearndash-academy-02%5C%2Fcheckout%5C%2F%22%7D%2C%22privacy%22%3A%7B%22id%22%3A0%2C%22title%22%3A%22%22%2C%22permalink%22%3Afalse%7D%2C%22terms%22%3A%7B%22id%22%3A0%2C%22title%22%3A%22%22%2C%22permalink%22%3Afalse%7D%7D%2C%22wcAssetUrl%22%3A%22https%3A%5C%2F%5C%2Fwebsitedemos.net%5C%2Flearndash-academy-02%5C%2Fwp-content%5C%2Fplugins%5C%2Fwoocommerce%5C%2Fassets%5C%2F%22%2C%22wcVersion%22%3A%228.5.2%22%2C%22wpLoginUrl%22%3A%22https%3A%5C%2F%5C%2Fwebsitedemos.net%5C%2Flearndash-academy-02%5C%2Fwp-login.php%22%2C%22wpVersion%22%3A%226.4.3%22%2C%22collectableMethodIds%22%3A%5B%5D%2C%22admin%22%3A%7B%22wccomHelper%22%3A%7B%22isConnected%22%3Afalse%2C%22connectURL%22%3A%22https%3A%5C%2F%5C%2Fwebsitedemos.net%5C%2Flearndash-academy-02%5C%2Fwp-admin%5C%2Fadmin.php%3Fpage%3Dwc-addons%26section%3Dhelper%26wc-helper-connect%3D1%26wc-helper-nonce%3D48994e4b18%22%2C%22userEmail%22%3A%22%22%2C%22userAvatar%22%3A%22https%3A%5C%2F%5C%2Fsecure.gravatar.com%5C%2Favatar%5C%2F%3Fs%3D48%26d%3Dmm%26r%3Dg%22%2C%22storeCountry%22%3A%22GB%22%2C%22inAppPurchaseURLParams%22%3A%7B%22wccom-site%22%3A%22https%3A%5C%2F%5C%2Fwebsitedemos.net%5C%2Flearndash-academy-02%22%2C%22wccom-back%22%3A%22%252Flearndash-academy-02%252F%22%2C%22wccom-woo-version%22%3A%228.5.2%22%2C%22wccom-connect-nonce%22%3A%2248994e4b18%22%7D%7D%2C%22_feature_nonce%22%3A%2237faff269b%22%2C%22alertCount%22%3A%222%22%2C%22visibleTaskListIds%22%3A%5B%22extended%22%5D%7D%7D' ) );
</script>
<script src="https://websitedemos.net/learndash-academy-02/wp-content/plugins/woocommerce/assets/client/blocks/wc-settings.js?ver=07c2f0675ddd247d2325" id="wc-settings-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/dist/data-controls.js?ver=d584f6eaf9075247c7ea" id="wp-data-controls-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/dist/html-entities.js?ver=5faec882ff4c2ba82326" id="wp-html-entities-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/dist/notices.js?ver=6a0c7a42a2154f8fc833" id="wp-notices-js"></script>
<script id="wc-blocks-middleware-js-before">
			var wcBlocksMiddlewareConfig = {
				storeApiNonce: 'bb6952e282',
				wcStoreApiNonceTimestamp: '1707647725'
			};
			
</script>
<script src="https://websitedemos.net/learndash-academy-02/wp-content/plugins/woocommerce/assets/client/blocks/wc-blocks-middleware.js?ver=ca04183222edaf8a26be" id="wc-blocks-middleware-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-content/plugins/woocommerce/assets/client/blocks/wc-blocks-data.js?ver=c96aba0171b12e03b8a6" id="wc-blocks-data-store-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/dist/a11y.js?ver=b5ff61edc2245a1950cb" id="wp-a11y-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/dist/primitives.js?ver=54acc2bc0957cc0c5eec" id="wp-primitives-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/dist/warning.js?ver=076655dc9e35a2390851" id="wp-warning-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-content/plugins/woocommerce/assets/client/blocks/blocks-components.js?ver=b165bb2bd213326d7f31" id="wc-blocks-components-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-content/plugins/woocommerce/assets/client/blocks/blocks-checkout.js?ver=9f469ef17beaf7c51576" id="wc-blocks-checkout-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-content/plugins/woocommerce/assets/js/frontend/order-attribution-blocks.js?ver=8.5.2" id="wc-order-attribution-blocks-js"></script>
<script id="showcase-cta-js-js-extra">
var showcaseCTA = {"adminUrl":"https:\/\/websitedemos.net\/learndash-academy-02\/wp-admin\/","networkSiteURL":"https:\/\/websitedemos.net\/","templateName":"LearnDash Academy","isMainSite":"","templateColorScheme":"light","path":"\/learndash-academy-02\/","pageBuilder":["elementor"],"customizerData":{"astra-settings":{"blog-single-width":"default","blog-single-max-width":768,"single-content-images-shadow":false,"single-post-ast-content-layout":"default","single-post-sidebar-style":"default","ast-dynamic-single-post-elements-gap":10,"ast-dynamic-single-post-meta-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"ast-dynamic-single-post-meta-font-weight":"","ast-dynamic-single-post-metadata":["comments","ast-dynamic-single-post-taxonomy","author"],"section-search-page-title-structure":["section-search-page-title-title"],"section-search-page-title-custom-title":"Search Results for:","section-search-page-title-found-custom-description":"Here are the search results for your search.","section-search-page-title-not-found-custom-description":"Sorry, but we could not find anything related to your search terms. Please try again.","section-search-page-title-title-font-weight":"","section-search-page-title-title-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"ast-search-results-per-page":10,"section-search-page-title-horizontal-alignment":{"desktop":"","tablet":"","mobile":""},"ast-search-live-search":false,"ast-search-live-search-post-types":{"post":1,"page":1},"blog-post-structure":["image","title","title-meta","excerpt","read-more"],"blog-post-per-page":10,"blog-hover-effect":"none","blog-layout":"blog-layout-classic","blog-width":"default","blog-meta-date-type":"published","blog-meta-date-format":"","blog-max-width":1200,"blog-post-content":"excerpt","blog-meta":["comments","category","author"],"post-card-border-radius":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"post-card-featured-overlay":"","blog-category-style":"default","blog-tag-style":"default","blog-post-meta-divider-type":"\/","blog-meta-category-style":"default","blog-meta-tag-style":"default","blog-image-ratio-type":"","blog-image-ratio-pre-scale":"16\/9","blog-image-custom-scale-width":16,"blog-image-custom-scale-height":9,"text-color":"var(--ast-global-color-3)","link-color":"var(--ast-global-color-0)","theme-color":"var(--ast-global-color-0)","link-h-color":"var(--ast-global-color-1)","heading-base-color":"var(--ast-global-color-2)","border-color":"","footer-bg-obj":{"background-color":"#0984e3","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"none","overlay-color":"","overlay-gradient":""},"footer-color":"#ffffff","footer-link-color":"","footer-link-h-color":"","footer-adv-bg-obj":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"none","overlay-color":"","overlay-gradient":""},"footer-adv-text-color":"","footer-adv-link-color":"","footer-adv-link-h-color":"","footer-adv-wgt-title-color":"","button-color":"","button-h-color":"","button-bg-color":"var(--ast-global-color-0)","button-bg-h-color":"var(--ast-global-color-1)","secondary-button-bg-h-color":"var(--ast-global-color-1)","secondary-button-bg-color":"var(--ast-global-color-0)","secondary-button-color":"","secondary-button-h-color":"","theme-button-padding":{"desktop":{"top":"15","right":"40","bottom":"16","left":"40"},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"secondary-theme-button-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"button-radius-fields":{"desktop":{"top":50,"right":50,"bottom":50,"left":50},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"secondary-button-radius-fields":{"desktop":{"top":50,"right":50,"bottom":50,"left":50},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"theme-button-border-group-border-size":{"top":"","right":"","bottom":"","left":""},"secondary-theme-button-border-group-border-size":{"top":"","right":"","bottom":"","left":""},"footer-sml-layout":"footer-sml-layout-2","footer-sml-section-1":"custom","footer-sml-section-1-credit":"Copyright \u00a9 [current_year] [site_title] ","footer-sml-section-2":"custom","footer-sml-section-2-credit":"Powered by Astra & LearnDash","footer-sml-dist-equal-align":true,"footer-sml-divider":1,"footer-sml-divider-color":"rgba(9,132,227,0.62)","footer-layout-width":"content","ast-header-retina-logo":"","ast-header-logo-width":"","ast-header-responsive-logo-width":{"desktop":"165","tablet":"","mobile":"90"},"header-color-site-title":"#ffffff","header-color-h-site-title":"","header-color-site-tagline":"","display-site-title-responsive":{"desktop":false,"tablet":false,"mobile":false},"display-site-tagline-responsive":{"desktop":0,"tablet":0,"mobile":0},"logo-title-inline":0,"disable-primary-nav":false,"header-layouts":"header-main-layout-1","header-main-rt-section":"none","header-display-outside-menu":false,"header-main-rt-section-html":"[astra_learndash_profile_link link=\"\/profile\/\"]","header-main-rt-section-button-text":"Button","header-main-rt-section-button-link":"https:\/\/www.wpastra.com","header-main-rt-section-button-link-option":{"url":"https:\/\/www.wpastra.com","new_tab":false,"link_rel":""},"header-main-rt-section-button-style":"theme-button","header-main-rt-section-button-text-color":"","header-main-rt-section-button-back-color":"","header-main-rt-section-button-text-h-color":"","header-main-rt-section-button-back-h-color":"","header-main-rt-section-button-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""}},"header-main-rt-section-button-border-size":{"top":"","right":"","bottom":"","left":""},"header-main-sep":1,"header-main-sep-color":"#dbdee0","header-main-layout-width":"content","primary-submenu-border":{"top":"0","right":"0","bottom":"0","left":"0"},"primary-submenu-item-border":true,"primary-submenu-b-color":"#adadad","primary-submenu-item-b-color":"rgba(39,44,108,0.15)","primary-header-button-font-family":"inherit","primary-header-button-font-weight":"inherit","primary-header-button-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"primary-header-button-text-transform":"","primary-header-button-line-height":1,"primary-header-button-letter-spacing":"","header-main-menu-label":"","header-main-menu-align":"inline","header-main-submenu-container-animation":"slide-up","mobile-header-breakpoint":"768","mobile-header-logo":"","mobile-header-logo-width":"","site-layout":"ast-full-width-layout","site-content-width":1200,"narrow-container-max-width":750,"site-layout-outside-bg-obj-responsive":{"desktop":{"background-color":"var(--ast-global-color-4)","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"color","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"tablet":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""}},"content-bg-obj-responsive":{"desktop":{"background-color":"var(--ast-global-color-5)","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"color","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"tablet":{"background-color":"var(--ast-global-color-5)","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"color","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"mobile":{"background-color":"var(--ast-global-color-5)","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"color","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""}},"wp-blocks-ui":"comfort","wp-blocks-global-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"em","tablet-unit":"em","mobile-unit":"em"},"enable-comments-area":true,"comments-box-placement":"","comment-form-position":"below","comments-box-container-width":"","ast-sub-section-comments-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"em","tablet-unit":"em","mobile-unit":"em"},"ast-sub-section-comments-padding":{"desktop":{"top":"","right":"","bottom":3,"left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"em","tablet-unit":"em","mobile-unit":"em"},"single-page-ast-content-layout":"default","single-page-content-style":"default","single-post-content-style":"default","archive-post-ast-content-layout":"default","ast-site-content-layout":"normal-width-container","site-content-style":"boxed","body-font-family":"'Inter', sans-serif","body-font-variant":"400,500","body-font-weight":"400","font-size-body":{"desktop":"16","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"body-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"headings-font-height-settings":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"para-margin-bottom":"","underline-content-links":false,"site-accessibility-toggle":true,"site-accessibility-highlight-type":"dotted","site-accessibility-highlight-input-type":"disable","body-text-transform":"","headings-font-family":"'Inter', sans-serif","headings-font-weight":"700","font-size-site-title":{"desktop":35,"tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"font-size-site-tagline":{"desktop":15,"tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"single-post-outside-spacing":{"desktop":{"top":"","right":"40","bottom":"","left":"40"},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"font-size-page-title":{"desktop":"30","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"font-size-post-tax":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"font-size-post-meta":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"font-size-h1":{"desktop":"48","tablet":"","mobile":"22","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"font-size-h2":{"desktop":"35","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"font-size-h3":{"desktop":"20","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"font-size-h4":{"desktop":"18","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"font-size-h5":{"desktop":"16","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"font-size-h6":{"desktop":"14","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"site-sidebar-layout":"no-sidebar","site-sidebar-width":25,"single-page-sidebar-layout":"default","single-post-sidebar-layout":"default","archive-post-sidebar-layout":"default","site-sticky-sidebar":false,"site-sidebar-style":"boxed","single-page-sidebar-style":"default","archive-post-sidebar-style":"default","footer-adv":"disabled","footer-adv-border-width":"","footer-adv-border-color":"#7a7a7a","mobile-header-toggle-btn-style":"fill","hide-custom-menu-mobile":1,"mobile-header-toggle-target":"icon","enable-scroll-to-id":false,"enable-related-posts":false,"related-posts-title":"Related Posts","releted-posts-title-alignment":"left","related-posts-total-count":2,"enable-related-posts-excerpt":false,"related-posts-box-placement":"default","related-posts-outside-location":"above","related-posts-container-width":"fallback","related-posts-excerpt-count":25,"related-posts-based-on":"categories","related-posts-order-by":"date","related-posts-order":"asc","related-posts-grid-responsive":{"desktop":"2-equal","tablet":"2-equal","mobile":"full"},"related-posts-structure":["featured-image","title-meta"],"related-posts-tag-style":"none","related-posts-category-style":"none","related-posts-date-format":"","related-posts-meta-date-type":"published","related-posts-author-avatar-size":"","related-posts-author-avatar":false,"related-posts-author-prefix-label":"By ","related-posts-image-size":"","related-posts-image-custom-scale-width":16,"related-posts-image-custom-scale-height":9,"related-posts-image-ratio-pre-scale":"16\/9","related-posts-image-ratio-type":"","related-posts-meta-structure":["comments","category","author"],"related-posts-text-color":"","related-posts-link-color":"","related-posts-title-color":"","related-posts-background-color":"","related-posts-meta-color":"","related-posts-link-hover-color":"","related-posts-meta-link-hover-color":"","related-posts-section-title-font-family":"inherit","related-posts-section-title-font-weight":"inherit","related-posts-section-title-text-transform":"","related-posts-section-title-line-height":"","related-posts-section-title-font-extras":{"line-height":"1.6","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"related-posts-section-title-font-size":{"desktop":"30","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"related-posts-title-font-family":"inherit","related-posts-title-font-weight":"inherit","related-posts-title-text-transform":"","related-posts-title-line-height":"1","related-posts-title-font-size":{"desktop":"20","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"related-posts-title-font-extras":{"line-height":"1","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"related-posts-meta-font-family":"inherit","related-posts-meta-font-weight":"inherit","related-posts-meta-text-transform":"","related-posts-meta-line-height":"","related-posts-meta-font-size":{"desktop":"14","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"related-posts-meta-font-extras":{"line-height":"1.6","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"related-posts-content-font-family":"inherit","related-posts-content-font-weight":"inherit","related-posts-content-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"related-posts-content-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"ast-sub-section-related-posts-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"ast-sub-section-related-posts-margin":{"desktop":{"top":2,"right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"em","tablet-unit":"em","mobile-unit":"em"},"astra-woocommerce-cart-icons-flag":false,"woocommerce-ast-content-layout":"normal-width-container","archive-product-content-layout":"default","single-product-content-layout":"default","woocommerce-content-style":"unboxed","woocommerce-sidebar-style":"unboxed","woocommerce-sidebar-layout":"default","archive-product-sidebar-layout":"default","single-product-sidebar-layout":"default","shop-grids":{"desktop":4,"tablet":3,"mobile":2},"shop-no-of-products":"12","shop-product-structure":["category","title","ratings","price","add_cart"],"shop-hover-style":"","single-product-breadcrumb-disable":false,"single-product-cart-button-width":{"desktop":"","tablet":"","mobile":""},"enable-cart-upsells":true,"store-notice-text-color":"","store-notice-background-color":"","store-notice-position":"top","shop-archive-width":"default","shop-archive-max-width":1200,"shop-add-to-cart-action":"default","single-product-tabs-display":false,"single-product-shipping-text":"& Free Shipping","single-product-variation-tabs-layout":"vertical","woo-enable-cart-button-text":false,"woo-cart-button-text":"Proceed to checkout","single-product-structure":["category","title","ratings","price","short_desc","add_cart","meta"],"single-product-sticky-add-to-cart":false,"single-product-sticky-add-to-cart-position":"top","shop-product-align-responsive":{"desktop":"align-left","tablet":"align-left","mobile":"align-left"},"woo-header-cart-total-label":false,"shop-style":"shop-page-modern-style","woo-header-cart-product-count-color":"","woo-header-cart-product-count-h-color":"","single-product-plus-minus-button":false,"cart-plus-minus-button-type":"normal","single-product-payment-icon-color":"inherit","single-product-payment-text":"Guaranteed Safe Checkout","single-product-payment-list":{"items":[{"id":"item-100","enabled":true,"source":"icon","icon":"cc-visa","image":"","label":"Visa"},{"id":"item-101","enabled":true,"source":"icon","icon":"cc-mastercard","image":"","label":"Mastercard"},{"id":"item-102","enabled":true,"source":"icon","icon":"cc-amex","image":"","label":"Amex"},{"id":"item-103","enabled":true,"source":"icon","icon":"cc-discover","image":"","label":"Discover"}]},"learndash-lesson-serial-number":true,"learndash-differentiate-rows":true,"learndash-ast-content-layout":"default","learndash-sidebar-layout":"default","transparent-header-logo":"https:\/\/websitedemos.net\/learndash-academy-02\/wp-content\/uploads\/sites\/457\/2019\/06\/learn-dash-white-logo.svg","transparent-header-retina-logo":"","different-transparent-logo":true,"different-transparent-retina-logo":0,"transparent-header-logo-width":{"desktop":"165","tablet":"","mobile":""},"transparent-header-enable":0,"transparent-header-disable-archive":1,"transparent-header-disable-latest-posts-index":1,"transparent-header-on-devices":"both","transparent-header-main-sep":0,"transparent-header-main-sep-color":"","transparent-header-bg-color":"","transparent-header-color-site-title":"","transparent-header-color-h-site-title":"","transparent-menu-bg-color":"","transparent-menu-color":"","transparent-menu-h-color":"","transparent-submenu-bg-color":"","transparent-submenu-color":"","transparent-submenu-h-color":"","transparent-header-logo-color":"","transparent-header-bg-color-responsive":{"desktop":"","tablet":"","mobile":""},"transparent-header-color-site-title-responsive":{"desktop":"var(--ast-global-color-4)","tablet":"","mobile":""},"transparent-header-color-h-site-title-responsive":{"desktop":"","tablet":"","mobile":""},"transparent-menu-bg-color-responsive":{"desktop":"","tablet":"#ffffff","mobile":"#ffffff"},"transparent-menu-color-responsive":{"desktop":"var(--ast-global-color-4)","tablet":"#2f3f50","mobile":"#2f3f50"},"transparent-menu-h-color-responsive":{"desktop":"var(--ast-global-color-4)","tablet":"#0984e3","mobile":"#4a80ec"},"transparent-submenu-bg-color-responsive":{"desktop":"","tablet":"#ffffff","mobile":""},"transparent-submenu-color-responsive":{"desktop":"","tablet":"","mobile":""},"transparent-submenu-h-color-responsive":{"desktop":"","tablet":"","mobile":""},"transparent-content-section-text-color-responsive":{"desktop":"","tablet":"","mobile":""},"transparent-content-section-link-color-responsive":{"desktop":"","tablet":"","mobile":""},"transparent-content-section-link-h-color-responsive":{"desktop":"","tablet":"","mobile":""},"breadcrumb-font-family":"inherit","breadcrumb-font-weight":"inherit","breadcrumb-text-color-responsive":{"desktop":"","tablet":"","mobile":""},"breadcrumb-active-color-responsive":{"desktop":"","tablet":"","mobile":""},"breadcrumb-hover-color-responsive":{"desktop":"","tablet":"","mobile":""},"breadcrumb-separator-color":{"desktop":"","tablet":"","mobile":""},"breadcrumb-bg-color":{"desktop":"","tablet":"","mobile":""},"breadcrumb-spacing":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"breadcrumb-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"breadcrumb-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"breadcrumb-separator-selector":"unicode","breadcrumb-separator":"\u00000bb","scroll-to-top-enable":false,"scroll-to-top-icon-size":15,"scroll-to-top-icon-position":"right","scroll-to-top-on-devices":"both","scroll-to-top-icon-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"scroll-to-top-icon-color":"","scroll-to-top-icon-h-color":"","scroll-to-top-icon-bg-color":"","scroll-to-top-icon-h-bg-color":"","h1-color":"#272c6c","h2-color":"#272c6c","h3-color":"#272c6c","h4-color":"","h5-color":"","h6-color":"","font-family-h1":"inherit","font-weight-h1":"normal","font-extras-h1":{"line-height":"1.2","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"font-family-h2":"inherit","font-weight-h2":"normal","font-extras-h2":{"line-height":"1.2","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"font-family-h3":"inherit","font-weight-h3":"normal","font-extras-h3":{"line-height":"1.3","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"font-family-h4":"inherit","font-weight-h4":"500","font-extras-h4":{"line-height":"1.2","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"font-family-h5":"inherit","font-weight-h5":"inherit","font-extras-h5":{"line-height":"1.2","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"font-family-h6":"inherit","font-weight-h6":"inherit","font-extras-h6":{"line-height":"1.25","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"font-weight-button":"500","secondary-font-weight-button":"500","font-family-button":"inherit","secondary-font-family-button":"inherit","font-size-button":{"desktop":"15","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"secondary-font-size-button":{"desktop":"15","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"font-extras-button":{"line-height":1,"line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"secondary-font-extras-button":{"line-height":1,"line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"header-desktop-items":{"above":{"above_left":[],"above_left_center":[],"above_center":[],"above_right_center":[],"above_right":[]},"below":{"below_left":[],"below_left_center":[],"below_center":[],"below_right_center":[],"below_right":[]},"primary":{"primary_left":["logo"],"primary_left_center":[],"primary_center":[],"primary_right_center":[],"primary_right":["menu-1"]},"flag":true},"header-mobile-items":{"above":{"above_left":[],"above_center":[],"above_right":[]},"below":{"below_left":[],"below_center":[],"below_right":[]},"popup":{"popup_content":["menu-1"]},"primary":{"primary_left":["logo"],"primary_center":[],"primary_right":["mobile-trigger"]},"flag":false},"hb-header-main-layout-width":"content","hb-header-height":{"desktop":70,"tablet":"","mobile":""},"hb-stack":{"desktop":"stack","tablet":"stack","mobile":"stack"},"hb-header-main-sep":0,"hb-header-main-sep-color":"#dbdee0","hb-header-main-menu-align":"inline","hb-header-bg-obj-responsive":{"desktop":{"background-color":"var(--ast-global-color-0)","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"color","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"tablet":{"background-color":"#272c6c","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"color","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""}},"hb-header-spacing":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"1.5","right":"","bottom":"1.5","left":""},"mobile":{"top":"1","right":"","bottom":"1","left":""},"desktop-unit":"px","tablet-unit":"em","mobile-unit":"em"},"hba-header-layout":"above-header-layout-1","hba-header-height":{"desktop":50,"tablet":"","mobile":""},"hba-stack":{"desktop":"stack","tablet":"stack","mobile":"stack"},"hba-header-separator":1,"hba-header-bottom-border-color":"rgba(255,255,255,0.19)","hba-header-bg-obj-responsive":{"desktop":{"background-color":"#272c6c","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"tablet":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""}},"hba-header-text-color-responsive":{"desktop":"","tablet":"","mobile":""},"hba-header-link-color-responsive":{"desktop":"","tablet":"","mobile":""},"hba-header-link-h-color-responsive":{"desktop":"","tablet":"","mobile":""},"hba-header-spacing":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"0","right":"","bottom":"0","left":""},"mobile":{"top":"0.5","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"em"},"hbb-header-layout":"below-header-layout-1","hbb-header-height":{"desktop":60,"tablet":"","mobile":""},"hbb-stack":{"desktop":"stack","tablet":"stack","mobile":"stack"},"hbb-header-separator":1,"hbb-header-bottom-border-color":"#eaeaea","hbb-header-bg-obj-responsive":{"desktop":{"background-color":"#eeeeee","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""},"tablet":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""}},"hbb-header-spacing":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"1","right":"","bottom":"1","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"em","mobile-unit":"px"},"section-footer-builder-layout-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-footer-builder-layout-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-above-header-builder-padding":{"desktop":{"top":"5","right":"","bottom":"5","left":""},"tablet":{"top":"0","right":"","bottom":"0","left":""},"mobile":{"top":"0.5","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"em"},"section-above-header-builder-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-below-header-builder-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-below-header-builder-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-header-mobile-trigger-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-primary-header-builder-padding":{"desktop":{"top":"10","right":"","bottom":"10","left":""},"tablet":{"top":"1","right":"","bottom":"1","left":""},"mobile":{"top":"0.5","right":"","bottom":"1","left":""},"desktop-unit":"px","tablet-unit":"em","mobile-unit":"em"},"section-primary-header-builder-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"title_tagline-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-header-search-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-account-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-mobile-menu-menu-spacing":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-header-mobile-menu-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-above-footer-builder-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-above-footer-builder-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-below-footer-builder-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-footer-copyright-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-footer-menu-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-primary-footer-builder-padding":{"desktop":{"top":"100","right":"30","bottom":"75","left":"30"},"tablet":{"top":"80","right":"25","bottom":"60","left":"25"},"mobile":{"top":"80","right":"20","bottom":"60","left":"20"},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-primary-footer-builder-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-header-woo-cart-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-header-woo-cart-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button1-text":"Button","header-button1-link-option":{"url":"https:\/\/www.wpastra.com","new_tab":false,"link_rel":""},"header-button1-font-family":"inherit","header-button1-font-weight":"inherit","header-button1-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"header-button1-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button1-text-color":{"desktop":"","tablet":"","mobile":""},"header-button1-back-color":{"desktop":"","tablet":"","mobile":""},"header-button1-text-h-color":{"desktop":"","tablet":"","mobile":""},"header-button1-back-h-color":{"desktop":"","tablet":"","mobile":""},"header-button1-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button1-border-size":{"top":"","right":"","bottom":"","left":""},"header-button1-border-color":{"desktop":"","tablet":"","mobile":""},"header-button1-border-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button1-border-radius":"","section-hb-button-1-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-hb-button-1-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"sticky-header-button1-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button1-text":"Button","footer-button1-link-option":{"url":"https:\/\/www.wpastra.com","new_tab":false,"link_rel":""},"footer-button1-font-family":"inherit","footer-button1-font-weight":"inherit","footer-button1-text-transform":"","footer-button1-line-height":"","footer-button1-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button1-text-color":{"desktop":"","tablet":"","mobile":""},"footer-button1-back-color":{"desktop":"","tablet":"","mobile":""},"footer-button1-text-h-color":{"desktop":"","tablet":"","mobile":""},"footer-button1-back-h-color":{"desktop":"","tablet":"","mobile":""},"footer-button1-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button1-border-size":{"top":"","right":"","bottom":"","left":""},"footer-button1-border-color":{"desktop":"","tablet":"","mobile":""},"footer-button1-border-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button-1-alignment":{"desktop":"center","tablet":"center","mobile":"center"},"section-fb-button-1-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-fb-button-1-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-html-1":"Insert HTML text here.","header-html-1color":{"desktop":"","tablet":"","mobile":""},"header-html-1link-color":{"desktop":"","tablet":"","mobile":""},"header-html-1link-h-color":{"desktop":"","tablet":"","mobile":""},"font-size-section-hb-html-1":{"desktop":15,"tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"font-weight-section-hb-html-1":"inherit","font-family-section-hb-html-1":"inherit","font-extras-section-hb-html-1":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"section-hb-html-1-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-html-1":"Powered by Astra &amp; LearnDash","footer-html-1color":{"desktop":"#ffffff","tablet":"","mobile":""},"footer-html-1link-color":{"desktop":"","tablet":"","mobile":""},"footer-html-1link-h-color":{"desktop":"","tablet":"","mobile":""},"font-size-section-fb-html-1":{"desktop":"16","tablet":"15","mobile":"15","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-html-1-alignment":{"desktop":"right","tablet":"right","mobile":"center"},"font-weight-section-fb-html-1":"inherit","font-family-section-fb-html-1":"inherit","font-extras-section-fb-html-1":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"section-fb-html-1-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-social-1-space":{"desktop":"","tablet":"","mobile":""},"header-social-1-bg-space":"","header-social-1-size":{"desktop":18,"tablet":"","mobile":""},"header-social-1-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-social-1-color":"","header-social-1-h-color":"","header-social-1-bg-color":"","header-social-1-bg-h-color":"","header-social-1-label-toggle":false,"header-social-1-color-type":"custom","header-social-1-brand-hover-toggle":false,"font-size-section-hb-social-icons-1":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-social-icons-1":{"items":[{"id":"facebook","enabled":true,"source":"icon","url":"","color":"#557dbc","background":"transparent","icon":"facebook","label":"Facebook"},{"id":"twitter","enabled":true,"source":"icon","url":"","color":"#7acdee","background":"transparent","icon":"twitter","label":"Twitter"},{"id":"instagram","enabled":true,"source":"icon","url":"","color":"#8a3ab9","background":"transparent","icon":"instagram","label":"Instagram"}]},"section-hb-social-icons-1-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-social-1-space":{"desktop":"","tablet":"","mobile":""},"footer-social-1-bg-space":"","footer-social-1-size":{"desktop":18,"tablet":"","mobile":""},"footer-social-1-radius":"","footer-social-1-color":"","footer-social-1-h-color":"","footer-social-1-bg-color":"","footer-social-1-bg-h-color":"","footer-social-1-label-toggle":false,"footer-social-1-color-type":"custom","footer-social-1-brand-color":"","footer-social-1-brand-label-color":"","footer-social-1-brand-hover-toggle":false,"font-size-section-fb-social-icons-1":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-social-icons-1":{"items":[{"id":"facebook","enabled":true,"source":"icon","url":"","color":"#557dbc","background":"transparent","icon":"facebook","label":"Facebook"},{"id":"twitter","enabled":true,"source":"icon","url":"","color":"#7acdee","background":"transparent","icon":"twitter","label":"Twitter"},{"id":"instagram","enabled":true,"source":"icon","url":"","color":"#8a3ab9","background":"transparent","icon":"instagram","label":"Instagram"}]},"footer-social-1-alignment":{"desktop":"center","tablet":"center","mobile":"center"},"section-fb-social-icons-1-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-widget-1-title-color":{"desktop":"","tablet":"","mobile":""},"header-widget-1-color":{"desktop":"","tablet":"","mobile":""},"header-widget-1-link-color":{"desktop":"","tablet":"","mobile":""},"header-widget-1-link-h-color":{"desktop":"","tablet":"","mobile":""},"header-widget-1-font-family":"inherit","header-widget-1-font-weight":"inherit","header-widget-1-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-widget-1-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"header-widget-1-content-font-family":"inherit","header-widget-1-content-font-weight":"inherit","header-widget-1-content-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-widget-1-content-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"sidebar-widgets-header-widget-1-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-widget-1-title-color":{"desktop":"var(--ast-global-color-4)","tablet":"","mobile":""},"footer-widget-1-color":{"desktop":"var(--ast-global-color-4)","tablet":"","mobile":""},"footer-widget-1-link-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-1-link-h-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-1-font-family":"inherit","footer-widget-1-font-weight":"inherit","footer-widget-1-text-transform":"","footer-widget-1-line-height":"","footer-widget-1-font-size":{"desktop":"35","tablet":"","mobile":"32","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-widget-1-content-font-family":"inherit","footer-widget-1-content-font-weight":"inherit","footer-widget-1-content-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"footer-widget-1-content-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-widget-alignment-1":{"desktop":"center","tablet":"center","mobile":"center"},"sidebar-widgets-footer-widget-1-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu1-bg-color":"","header-menu1-color":"","header-menu1-h-bg-color":"","header-menu1-h-color":"","header-menu1-a-bg-color":"","header-menu1-a-color":"","header-menu1-bg-obj-responsive":{"desktop":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"tablet":{"background-color":"#ffffff","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"color","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""}},"header-menu1-color-responsive":{"desktop":"var(--ast-global-color-3)","tablet":"#191a19","mobile":""},"header-menu1-h-bg-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu1-h-color-responsive":{"desktop":"var(--ast-global-color-1)","tablet":"#4a80ec","mobile":""},"header-menu1-a-bg-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu1-a-color-responsive":{"desktop":"var(--ast-global-color-1)","tablet":"#4a80ec","mobile":""},"header-menu1-menu-hover-animation":"","header-menu1-submenu-container-animation":"slide-up","section-hb-menu-1-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu1-menu-spacing":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"0","right":"20","bottom":"0","left":"20"},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu1-submenu-item-border":true,"header-menu1-submenu-item-b-size":"1","header-menu1-submenu-item-b-color":"rgba(39,44,108,0.15)","header-menu1-submenu-border-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu1-submenu-top-offset":"","header-menu1-submenu-width":"","header-menu1-submenu-border":{"top":"0","right":"0","bottom":"0","left":"0"},"header-menu1-menu-stack-on-mobile":true,"header-menu1-font-size":{"desktop":"15","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu1-font-weight":"500","header-menu1-font-family":"inherit","header-menu1-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"section-hb-divider-1-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-fb-divider-1-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button2-text":"Button","header-button2-link-option":{"url":"https:\/\/www.wpastra.com","new_tab":false,"link_rel":""},"header-button2-font-family":"inherit","header-button2-font-weight":"inherit","header-button2-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"header-button2-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button2-text-color":{"desktop":"","tablet":"","mobile":""},"header-button2-back-color":{"desktop":"","tablet":"","mobile":""},"header-button2-text-h-color":{"desktop":"","tablet":"","mobile":""},"header-button2-back-h-color":{"desktop":"","tablet":"","mobile":""},"header-button2-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button2-border-size":{"top":"","right":"","bottom":"","left":""},"header-button2-border-color":{"desktop":"","tablet":"","mobile":""},"header-button2-border-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button2-border-radius":"","section-hb-button-2-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-hb-button-2-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"sticky-header-button2-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button2-text":"Button","footer-button2-link-option":{"url":"https:\/\/www.wpastra.com","new_tab":false,"link_rel":""},"footer-button2-font-family":"inherit","footer-button2-font-weight":"inherit","footer-button2-text-transform":"","footer-button2-line-height":"","footer-button2-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button2-text-color":{"desktop":"","tablet":"","mobile":""},"footer-button2-back-color":{"desktop":"","tablet":"","mobile":""},"footer-button2-text-h-color":{"desktop":"","tablet":"","mobile":""},"footer-button2-back-h-color":{"desktop":"","tablet":"","mobile":""},"footer-button2-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button2-border-size":{"top":"","right":"","bottom":"","left":""},"footer-button2-border-color":{"desktop":"","tablet":"","mobile":""},"footer-button2-border-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button-2-alignment":{"desktop":"center","tablet":"center","mobile":"center"},"section-fb-button-2-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-fb-button-2-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-html-2":"Insert HTML text here.","header-html-2color":{"desktop":"","tablet":"","mobile":""},"header-html-2link-color":{"desktop":"","tablet":"","mobile":""},"header-html-2link-h-color":{"desktop":"","tablet":"","mobile":""},"font-size-section-hb-html-2":{"desktop":15,"tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"font-weight-section-hb-html-2":"inherit","font-family-section-hb-html-2":"inherit","font-extras-section-hb-html-2":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"section-hb-html-2-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-html-2":"","footer-html-2color":{"desktop":"","tablet":"","mobile":""},"footer-html-2link-color":{"desktop":"","tablet":"","mobile":""},"footer-html-2link-h-color":{"desktop":"","tablet":"","mobile":""},"font-size-section-fb-html-2":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-html-2-alignment":{"desktop":"center","tablet":"center","mobile":"center"},"font-weight-section-fb-html-2":"inherit","font-family-section-fb-html-2":"inherit","font-extras-section-fb-html-2":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"section-fb-html-2-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-social-2-space":{"desktop":"","tablet":"","mobile":""},"header-social-2-bg-space":"","header-social-2-size":{"desktop":18,"tablet":"","mobile":""},"header-social-2-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-social-2-color":"","header-social-2-h-color":"","header-social-2-bg-color":"","header-social-2-bg-h-color":"","header-social-2-label-toggle":false,"header-social-2-color-type":"custom","header-social-2-brand-hover-toggle":false,"font-size-section-hb-social-icons-2":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-social-icons-2":{"items":[{"id":"facebook","enabled":true,"source":"icon","url":"","color":"#557dbc","background":"transparent","icon":"facebook","label":"Facebook"},{"id":"twitter","enabled":true,"source":"icon","url":"","color":"#7acdee","background":"transparent","icon":"twitter","label":"Twitter"},{"id":"instagram","enabled":true,"source":"icon","url":"","color":"#8a3ab9","background":"transparent","icon":"instagram","label":"Instagram"}]},"section-hb-social-icons-2-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-social-2-space":{"desktop":"","tablet":"","mobile":""},"footer-social-2-bg-space":"","footer-social-2-size":{"desktop":18,"tablet":"","mobile":""},"footer-social-2-radius":"","footer-social-2-color":"","footer-social-2-h-color":"","footer-social-2-bg-color":"","footer-social-2-bg-h-color":"","footer-social-2-label-toggle":false,"footer-social-2-color-type":"custom","footer-social-2-brand-color":"","footer-social-2-brand-label-color":"","footer-social-2-brand-hover-toggle":false,"font-size-section-fb-social-icons-2":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-social-icons-2":{"items":[{"id":"facebook","enabled":true,"source":"icon","url":"","color":"#557dbc","background":"transparent","icon":"facebook","label":"Facebook"},{"id":"twitter","enabled":true,"source":"icon","url":"","color":"#7acdee","background":"transparent","icon":"twitter","label":"Twitter"},{"id":"instagram","enabled":true,"source":"icon","url":"","color":"#8a3ab9","background":"transparent","icon":"instagram","label":"Instagram"}]},"footer-social-2-alignment":{"desktop":"center","tablet":"center","mobile":"center"},"section-fb-social-icons-2-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-widget-2-title-color":{"desktop":"","tablet":"","mobile":""},"header-widget-2-color":{"desktop":"","tablet":"","mobile":""},"header-widget-2-link-color":{"desktop":"","tablet":"","mobile":""},"header-widget-2-link-h-color":{"desktop":"","tablet":"","mobile":""},"header-widget-2-font-family":"inherit","header-widget-2-font-weight":"inherit","header-widget-2-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-widget-2-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"header-widget-2-content-font-family":"inherit","header-widget-2-content-font-weight":"inherit","header-widget-2-content-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-widget-2-content-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"sidebar-widgets-header-widget-2-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-widget-2-title-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-2-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-2-link-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-2-link-h-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-2-font-family":"inherit","footer-widget-2-font-weight":"inherit","footer-widget-2-text-transform":"","footer-widget-2-line-height":"","footer-widget-2-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-widget-2-content-font-family":"inherit","footer-widget-2-content-font-weight":"inherit","footer-widget-2-content-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"footer-widget-2-content-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-widget-alignment-2":{"desktop":"left","tablet":"center","mobile":"center"},"sidebar-widgets-footer-widget-2-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu2-bg-color":"","header-menu2-color":"","header-menu2-h-bg-color":"","header-menu2-h-color":"","header-menu2-a-bg-color":"","header-menu2-a-color":"","header-menu2-bg-obj-responsive":{"desktop":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""},"tablet":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""}},"header-menu2-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu2-h-bg-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu2-h-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu2-a-bg-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu2-a-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu2-menu-hover-animation":"","header-menu2-submenu-container-animation":"","section-hb-menu-2-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu2-menu-spacing":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu2-submenu-item-border":false,"header-menu2-submenu-item-b-size":"1","header-menu2-submenu-item-b-color":"#eaeaea","header-menu2-submenu-border-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu2-submenu-top-offset":"","header-menu2-submenu-width":"","header-menu2-submenu-border":{"top":2,"bottom":0,"left":0,"right":0},"header-menu2-menu-stack-on-mobile":true,"header-menu2-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu2-font-weight":"inherit","header-menu2-font-family":"inherit","header-menu2-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"section-hb-divider-2-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-fb-divider-2-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button3-text":"Button","header-button3-link-option":{"url":"https:\/\/www.wpastra.com","new_tab":false,"link_rel":""},"header-button3-font-family":"inherit","header-button3-font-weight":"inherit","header-button3-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"header-button3-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button3-text-color":{"desktop":"","tablet":"","mobile":""},"header-button3-back-color":{"desktop":"","tablet":"","mobile":""},"header-button3-text-h-color":{"desktop":"","tablet":"","mobile":""},"header-button3-back-h-color":{"desktop":"","tablet":"","mobile":""},"header-button3-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button3-border-size":{"top":"","right":"","bottom":"","left":""},"header-button3-border-color":{"desktop":"","tablet":"","mobile":""},"header-button3-border-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button3-border-radius":"","section-hb-button-3-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-hb-button-3-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"sticky-header-button3-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button3-text":"Button","footer-button3-link-option":{"url":"https:\/\/www.wpastra.com","new_tab":false,"link_rel":""},"footer-button3-font-family":"inherit","footer-button3-font-weight":"inherit","footer-button3-text-transform":"","footer-button3-line-height":"","footer-button3-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button3-text-color":{"desktop":"","tablet":"","mobile":""},"footer-button3-back-color":{"desktop":"","tablet":"","mobile":""},"footer-button3-text-h-color":{"desktop":"","tablet":"","mobile":""},"footer-button3-back-h-color":{"desktop":"","tablet":"","mobile":""},"footer-button3-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button3-border-size":{"top":"","right":"","bottom":"","left":""},"footer-button3-border-color":{"desktop":"","tablet":"","mobile":""},"footer-button3-border-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button-3-alignment":{"desktop":"center","tablet":"center","mobile":"center"},"section-fb-button-3-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-fb-button-3-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-html-3":"Insert HTML text here.","header-html-3color":{"desktop":"","tablet":"","mobile":""},"header-html-3link-color":{"desktop":"","tablet":"","mobile":""},"header-html-3link-h-color":{"desktop":"","tablet":"","mobile":""},"font-size-section-hb-html-3":{"desktop":15,"tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"font-weight-section-hb-html-3":"inherit","font-family-section-hb-html-3":"inherit","font-extras-section-hb-html-3":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"section-hb-html-3-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-html-3":"Insert HTML text here.","footer-html-3color":{"desktop":"","tablet":"","mobile":""},"footer-html-3link-color":{"desktop":"","tablet":"","mobile":""},"footer-html-3link-h-color":{"desktop":"","tablet":"","mobile":""},"font-size-section-fb-html-3":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-html-3-alignment":{"desktop":"center","tablet":"center","mobile":"center"},"font-weight-section-fb-html-3":"inherit","font-family-section-fb-html-3":"inherit","font-extras-section-fb-html-3":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"section-fb-html-3-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-social-3-space":{"desktop":"","tablet":"","mobile":""},"header-social-3-bg-space":"","header-social-3-size":{"desktop":18,"tablet":"","mobile":""},"header-social-3-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-social-3-color":"","header-social-3-h-color":"","header-social-3-bg-color":"","header-social-3-bg-h-color":"","header-social-3-label-toggle":false,"header-social-3-color-type":"custom","header-social-3-brand-hover-toggle":false,"font-size-section-hb-social-icons-3":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-social-icons-3":{"items":[{"id":"facebook","enabled":true,"source":"icon","url":"","color":"#557dbc","background":"transparent","icon":"facebook","label":"Facebook"},{"id":"twitter","enabled":true,"source":"icon","url":"","color":"#7acdee","background":"transparent","icon":"twitter","label":"Twitter"},{"id":"instagram","enabled":true,"source":"icon","url":"","color":"#8a3ab9","background":"transparent","icon":"instagram","label":"Instagram"}]},"section-hb-social-icons-3-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-social-3-space":{"desktop":"","tablet":"","mobile":""},"footer-social-3-bg-space":"","footer-social-3-size":{"desktop":18,"tablet":"","mobile":""},"footer-social-3-radius":"","footer-social-3-color":"","footer-social-3-h-color":"","footer-social-3-bg-color":"","footer-social-3-bg-h-color":"","footer-social-3-label-toggle":false,"footer-social-3-color-type":"custom","footer-social-3-brand-color":"","footer-social-3-brand-label-color":"","footer-social-3-brand-hover-toggle":false,"font-size-section-fb-social-icons-3":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-social-icons-3":{"items":[{"id":"facebook","enabled":true,"source":"icon","url":"","color":"#557dbc","background":"transparent","icon":"facebook","label":"Facebook"},{"id":"twitter","enabled":true,"source":"icon","url":"","color":"#7acdee","background":"transparent","icon":"twitter","label":"Twitter"},{"id":"instagram","enabled":true,"source":"icon","url":"","color":"#8a3ab9","background":"transparent","icon":"instagram","label":"Instagram"}]},"footer-social-3-alignment":{"desktop":"center","tablet":"center","mobile":"center"},"section-fb-social-icons-3-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-widget-3-title-color":{"desktop":"","tablet":"","mobile":""},"header-widget-3-color":{"desktop":"","tablet":"","mobile":""},"header-widget-3-link-color":{"desktop":"","tablet":"","mobile":""},"header-widget-3-link-h-color":{"desktop":"","tablet":"","mobile":""},"header-widget-3-font-family":"inherit","header-widget-3-font-weight":"inherit","header-widget-3-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-widget-3-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"header-widget-3-content-font-family":"inherit","header-widget-3-content-font-weight":"inherit","header-widget-3-content-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-widget-3-content-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"sidebar-widgets-header-widget-3-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-widget-3-title-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-3-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-3-link-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-3-link-h-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-3-font-family":"inherit","footer-widget-3-font-weight":"inherit","footer-widget-3-text-transform":"","footer-widget-3-line-height":"","footer-widget-3-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-widget-3-content-font-family":"inherit","footer-widget-3-content-font-weight":"inherit","footer-widget-3-content-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"footer-widget-3-content-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-widget-alignment-3":{"desktop":"left","tablet":"center","mobile":"center"},"sidebar-widgets-footer-widget-3-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu3-bg-color":"","header-menu3-color":"","header-menu3-h-bg-color":"","header-menu3-h-color":"","header-menu3-a-bg-color":"","header-menu3-a-color":"","header-menu3-bg-obj-responsive":{"desktop":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""},"tablet":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""}},"header-menu3-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu3-h-bg-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu3-h-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu3-a-bg-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu3-a-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu3-menu-hover-animation":"","header-menu3-submenu-container-animation":"","section-hb-menu-3-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu3-menu-spacing":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu3-submenu-item-border":false,"header-menu3-submenu-item-b-size":"1","header-menu3-submenu-item-b-color":"#eaeaea","header-menu3-submenu-border-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu3-submenu-top-offset":"","header-menu3-submenu-width":"","header-menu3-submenu-border":{"top":2,"bottom":0,"left":0,"right":0},"header-menu3-menu-stack-on-mobile":true,"header-menu3-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu3-font-weight":"inherit","header-menu3-font-family":"inherit","header-menu3-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"section-hb-divider-3-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-fb-divider-3-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button4-text":"Button","header-button4-link-option":{"url":"https:\/\/www.wpastra.com","new_tab":false,"link_rel":""},"header-button4-font-family":"inherit","header-button4-font-weight":"inherit","header-button4-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"header-button4-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button4-text-color":{"desktop":"","tablet":"","mobile":""},"header-button4-back-color":{"desktop":"","tablet":"","mobile":""},"header-button4-text-h-color":{"desktop":"","tablet":"","mobile":""},"header-button4-back-h-color":{"desktop":"","tablet":"","mobile":""},"header-button4-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button4-border-size":{"top":"","right":"","bottom":"","left":""},"header-button4-border-color":{"desktop":"","tablet":"","mobile":""},"header-button4-border-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button4-border-radius":"","section-hb-button-4-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-hb-button-4-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"sticky-header-button4-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button4-text":"Button","footer-button4-link-option":{"url":"https:\/\/www.wpastra.com","new_tab":false,"link_rel":""},"footer-button4-font-family":"inherit","footer-button4-font-weight":"inherit","footer-button4-text-transform":"","footer-button4-line-height":"","footer-button4-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button4-text-color":{"desktop":"","tablet":"","mobile":""},"footer-button4-back-color":{"desktop":"","tablet":"","mobile":""},"footer-button4-text-h-color":{"desktop":"","tablet":"","mobile":""},"footer-button4-back-h-color":{"desktop":"","tablet":"","mobile":""},"footer-button4-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button4-border-size":{"top":"","right":"","bottom":"","left":""},"footer-button4-border-color":{"desktop":"","tablet":"","mobile":""},"footer-button4-border-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button-4-alignment":{"desktop":"center","tablet":"center","mobile":"center"},"section-fb-button-4-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-fb-button-4-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-html-4":"Insert HTML text here.","header-html-4color":{"desktop":"","tablet":"","mobile":""},"header-html-4link-color":{"desktop":"","tablet":"","mobile":""},"header-html-4link-h-color":{"desktop":"","tablet":"","mobile":""},"font-size-section-hb-html-4":{"desktop":15,"tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"font-weight-section-hb-html-4":"inherit","font-family-section-hb-html-4":"inherit","font-extras-section-hb-html-4":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"section-hb-html-4-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-html-4":"Insert HTML text here.","footer-html-4color":{"desktop":"","tablet":"","mobile":""},"footer-html-4link-color":{"desktop":"","tablet":"","mobile":""},"footer-html-4link-h-color":{"desktop":"","tablet":"","mobile":""},"font-size-section-fb-html-4":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-html-4-alignment":{"desktop":"center","tablet":"center","mobile":"center"},"font-weight-section-fb-html-4":"inherit","font-family-section-fb-html-4":"inherit","font-extras-section-fb-html-4":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"section-fb-html-4-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-social-4-space":{"desktop":"","tablet":"","mobile":""},"header-social-4-bg-space":"","header-social-4-size":{"desktop":18,"tablet":"","mobile":""},"header-social-4-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-social-4-color":"","header-social-4-h-color":"","header-social-4-bg-color":"","header-social-4-bg-h-color":"","header-social-4-label-toggle":false,"header-social-4-color-type":"custom","header-social-4-brand-hover-toggle":false,"font-size-section-hb-social-icons-4":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-social-icons-4":{"items":[{"id":"facebook","enabled":true,"source":"icon","url":"","color":"#557dbc","background":"transparent","icon":"facebook","label":"Facebook"},{"id":"twitter","enabled":true,"source":"icon","url":"","color":"#7acdee","background":"transparent","icon":"twitter","label":"Twitter"},{"id":"instagram","enabled":true,"source":"icon","url":"","color":"#8a3ab9","background":"transparent","icon":"instagram","label":"Instagram"}]},"section-hb-social-icons-4-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-social-4-space":{"desktop":"","tablet":"","mobile":""},"footer-social-4-bg-space":"","footer-social-4-size":{"desktop":18,"tablet":"","mobile":""},"footer-social-4-radius":"","footer-social-4-color":"","footer-social-4-h-color":"","footer-social-4-bg-color":"","footer-social-4-bg-h-color":"","footer-social-4-label-toggle":false,"footer-social-4-color-type":"custom","footer-social-4-brand-color":"","footer-social-4-brand-label-color":"","footer-social-4-brand-hover-toggle":false,"font-size-section-fb-social-icons-4":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-social-icons-4":{"items":[{"id":"facebook","enabled":true,"source":"icon","url":"","color":"#557dbc","background":"transparent","icon":"facebook","label":"Facebook"},{"id":"twitter","enabled":true,"source":"icon","url":"","color":"#7acdee","background":"transparent","icon":"twitter","label":"Twitter"},{"id":"instagram","enabled":true,"source":"icon","url":"","color":"#8a3ab9","background":"transparent","icon":"instagram","label":"Instagram"}]},"footer-social-4-alignment":{"desktop":"center","tablet":"center","mobile":"center"},"section-fb-social-icons-4-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-widget-4-title-color":{"desktop":"","tablet":"","mobile":""},"header-widget-4-color":{"desktop":"","tablet":"","mobile":""},"header-widget-4-link-color":{"desktop":"","tablet":"","mobile":""},"header-widget-4-link-h-color":{"desktop":"","tablet":"","mobile":""},"header-widget-4-font-family":"inherit","header-widget-4-font-weight":"inherit","header-widget-4-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-widget-4-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"header-widget-4-content-font-family":"inherit","header-widget-4-content-font-weight":"inherit","header-widget-4-content-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-widget-4-content-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"sidebar-widgets-header-widget-4-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-widget-4-title-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-4-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-4-link-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-4-link-h-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-4-font-family":"inherit","footer-widget-4-font-weight":"inherit","footer-widget-4-text-transform":"","footer-widget-4-line-height":"","footer-widget-4-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-widget-4-content-font-family":"inherit","footer-widget-4-content-font-weight":"inherit","footer-widget-4-content-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"footer-widget-4-content-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-widget-alignment-4":{"desktop":"left","tablet":"center","mobile":"center"},"sidebar-widgets-footer-widget-4-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu4-bg-color":"","header-menu4-color":"","header-menu4-h-bg-color":"","header-menu4-h-color":"","header-menu4-a-bg-color":"","header-menu4-a-color":"","header-menu4-bg-obj-responsive":{"desktop":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""},"tablet":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""}},"header-menu4-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu4-h-bg-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu4-h-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu4-a-bg-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu4-a-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu4-menu-hover-animation":"","header-menu4-submenu-container-animation":"","section-hb-menu-4-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu4-menu-spacing":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu4-submenu-item-border":false,"header-menu4-submenu-item-b-size":"1","header-menu4-submenu-item-b-color":"#eaeaea","header-menu4-submenu-border-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu4-submenu-top-offset":"","header-menu4-submenu-width":"","header-menu4-submenu-border":{"top":2,"bottom":0,"left":0,"right":0},"header-menu4-menu-stack-on-mobile":true,"header-menu4-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu4-font-weight":"inherit","header-menu4-font-family":"inherit","header-menu4-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"section-hb-divider-4-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-fb-divider-4-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button5-text":"Button","header-button5-link-option":{"url":"https:\/\/www.wpastra.com","new_tab":false,"link_rel":""},"header-button5-font-family":"inherit","header-button5-font-weight":"inherit","header-button5-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"header-button5-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button5-text-color":{"desktop":"","tablet":"","mobile":""},"header-button5-back-color":{"desktop":"","tablet":"","mobile":""},"header-button5-text-h-color":{"desktop":"","tablet":"","mobile":""},"header-button5-back-h-color":{"desktop":"","tablet":"","mobile":""},"header-button5-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button5-border-size":{"top":"","right":"","bottom":"","left":""},"header-button5-border-color":{"desktop":"","tablet":"","mobile":""},"header-button5-border-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button5-border-radius":"","section-hb-button-5-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-hb-button-5-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"sticky-header-button5-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button5-text":"Button","footer-button5-link-option":{"url":"https:\/\/www.wpastra.com","new_tab":false,"link_rel":""},"footer-button5-font-family":"inherit","footer-button5-font-weight":"inherit","footer-button5-text-transform":"","footer-button5-line-height":"","footer-button5-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button5-text-color":{"desktop":"","tablet":"","mobile":""},"footer-button5-back-color":{"desktop":"","tablet":"","mobile":""},"footer-button5-text-h-color":{"desktop":"","tablet":"","mobile":""},"footer-button5-back-h-color":{"desktop":"","tablet":"","mobile":""},"footer-button5-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button5-border-size":{"top":"","right":"","bottom":"","left":""},"footer-button5-border-color":{"desktop":"","tablet":"","mobile":""},"footer-button5-border-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button-5-alignment":{"desktop":"center","tablet":"center","mobile":"center"},"section-fb-button-5-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-fb-button-5-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-html-5":"Insert HTML text here.","header-html-5color":{"desktop":"","tablet":"","mobile":""},"header-html-5link-color":{"desktop":"","tablet":"","mobile":""},"header-html-5link-h-color":{"desktop":"","tablet":"","mobile":""},"font-size-section-hb-html-5":{"desktop":15,"tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"font-weight-section-hb-html-5":"inherit","font-family-section-hb-html-5":"inherit","font-extras-section-hb-html-5":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"section-hb-html-5-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-html-5":"Insert HTML text here.","footer-html-5color":{"desktop":"","tablet":"","mobile":""},"footer-html-5link-color":{"desktop":"","tablet":"","mobile":""},"footer-html-5link-h-color":{"desktop":"","tablet":"","mobile":""},"font-size-section-fb-html-5":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-html-5-alignment":{"desktop":"center","tablet":"center","mobile":"center"},"font-weight-section-fb-html-5":"inherit","font-family-section-fb-html-5":"inherit","font-extras-section-fb-html-5":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"section-fb-html-5-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-social-5-space":{"desktop":"","tablet":"","mobile":""},"header-social-5-bg-space":"","header-social-5-size":{"desktop":18,"tablet":"","mobile":""},"header-social-5-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-social-5-color":"","header-social-5-h-color":"","header-social-5-bg-color":"","header-social-5-bg-h-color":"","header-social-5-label-toggle":false,"header-social-5-color-type":"custom","header-social-5-brand-hover-toggle":false,"font-size-section-hb-social-icons-5":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-social-icons-5":{"items":[{"id":"facebook","enabled":true,"source":"icon","url":"","color":"#557dbc","background":"transparent","icon":"facebook","label":"Facebook"},{"id":"twitter","enabled":true,"source":"icon","url":"","color":"#7acdee","background":"transparent","icon":"twitter","label":"Twitter"},{"id":"instagram","enabled":true,"source":"icon","url":"","color":"#8a3ab9","background":"transparent","icon":"instagram","label":"Instagram"}]},"section-hb-social-icons-5-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-social-5-space":{"desktop":"","tablet":"","mobile":""},"footer-social-5-bg-space":"","footer-social-5-size":{"desktop":18,"tablet":"","mobile":""},"footer-social-5-radius":"","footer-social-5-color":"","footer-social-5-h-color":"","footer-social-5-bg-color":"","footer-social-5-bg-h-color":"","footer-social-5-label-toggle":false,"footer-social-5-color-type":"custom","footer-social-5-brand-color":"","footer-social-5-brand-label-color":"","footer-social-5-brand-hover-toggle":false,"font-size-section-fb-social-icons-5":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-social-icons-5":{"items":[{"id":"facebook","enabled":true,"source":"icon","url":"","color":"#557dbc","background":"transparent","icon":"facebook","label":"Facebook"},{"id":"twitter","enabled":true,"source":"icon","url":"","color":"#7acdee","background":"transparent","icon":"twitter","label":"Twitter"},{"id":"instagram","enabled":true,"source":"icon","url":"","color":"#8a3ab9","background":"transparent","icon":"instagram","label":"Instagram"}]},"footer-social-5-alignment":{"desktop":"center","tablet":"center","mobile":"center"},"section-fb-social-icons-5-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-widget-5-title-color":{"desktop":"","tablet":"","mobile":""},"header-widget-5-color":{"desktop":"","tablet":"","mobile":""},"header-widget-5-link-color":{"desktop":"","tablet":"","mobile":""},"header-widget-5-link-h-color":{"desktop":"","tablet":"","mobile":""},"header-widget-5-font-family":"inherit","header-widget-5-font-weight":"inherit","header-widget-5-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-widget-5-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"header-widget-5-content-font-family":"inherit","header-widget-5-content-font-weight":"inherit","header-widget-5-content-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-widget-5-content-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"sidebar-widgets-header-widget-5-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-widget-5-title-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-5-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-5-link-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-5-link-h-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-5-font-family":"inherit","footer-widget-5-font-weight":"inherit","footer-widget-5-text-transform":"","footer-widget-5-line-height":"","footer-widget-5-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-widget-5-content-font-family":"inherit","footer-widget-5-content-font-weight":"inherit","footer-widget-5-content-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"footer-widget-5-content-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-widget-alignment-5":{"desktop":"left","tablet":"center","mobile":"center"},"sidebar-widgets-footer-widget-5-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu5-bg-color":"","header-menu5-color":"","header-menu5-h-bg-color":"","header-menu5-h-color":"","header-menu5-a-bg-color":"","header-menu5-a-color":"","header-menu5-bg-obj-responsive":{"desktop":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""},"tablet":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""}},"header-menu5-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu5-h-bg-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu5-h-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu5-a-bg-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu5-a-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu5-menu-hover-animation":"","header-menu5-submenu-container-animation":"","section-hb-menu-5-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu5-menu-spacing":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu5-submenu-item-border":false,"header-menu5-submenu-item-b-size":"1","header-menu5-submenu-item-b-color":"#eaeaea","header-menu5-submenu-border-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu5-submenu-top-offset":"","header-menu5-submenu-width":"","header-menu5-submenu-border":{"top":2,"bottom":0,"left":0,"right":0},"header-menu5-menu-stack-on-mobile":true,"header-menu5-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu5-font-weight":"inherit","header-menu5-font-family":"inherit","header-menu5-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"section-hb-divider-5-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-fb-divider-5-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button6-text":"Button","header-button6-link-option":{"url":"https:\/\/www.wpastra.com","new_tab":false,"link_rel":""},"header-button6-font-family":"inherit","header-button6-font-weight":"inherit","header-button6-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"header-button6-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button6-text-color":{"desktop":"","tablet":"","mobile":""},"header-button6-back-color":{"desktop":"","tablet":"","mobile":""},"header-button6-text-h-color":{"desktop":"","tablet":"","mobile":""},"header-button6-back-h-color":{"desktop":"","tablet":"","mobile":""},"header-button6-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button6-border-size":{"top":"","right":"","bottom":"","left":""},"header-button6-border-color":{"desktop":"","tablet":"","mobile":""},"header-button6-border-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button6-border-radius":"","section-hb-button-6-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-hb-button-6-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"sticky-header-button6-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button6-text":"Button","footer-button6-link-option":{"url":"https:\/\/www.wpastra.com","new_tab":false,"link_rel":""},"footer-button6-font-family":"inherit","footer-button6-font-weight":"inherit","footer-button6-text-transform":"","footer-button6-line-height":"","footer-button6-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button6-text-color":{"desktop":"","tablet":"","mobile":""},"footer-button6-back-color":{"desktop":"","tablet":"","mobile":""},"footer-button6-text-h-color":{"desktop":"","tablet":"","mobile":""},"footer-button6-back-h-color":{"desktop":"","tablet":"","mobile":""},"footer-button6-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button6-border-size":{"top":"","right":"","bottom":"","left":""},"footer-button6-border-color":{"desktop":"","tablet":"","mobile":""},"footer-button6-border-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button-6-alignment":{"desktop":"center","tablet":"center","mobile":"center"},"section-fb-button-6-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-fb-button-6-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-html-6":"Insert HTML text here.","header-html-6color":{"desktop":"","tablet":"","mobile":""},"header-html-6link-color":{"desktop":"","tablet":"","mobile":""},"header-html-6link-h-color":{"desktop":"","tablet":"","mobile":""},"font-size-section-hb-html-6":{"desktop":15,"tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"font-weight-section-hb-html-6":"inherit","font-family-section-hb-html-6":"inherit","font-extras-section-hb-html-6":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"section-hb-html-6-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-html-6":"Insert HTML text here.","footer-html-6color":{"desktop":"","tablet":"","mobile":""},"footer-html-6link-color":{"desktop":"","tablet":"","mobile":""},"footer-html-6link-h-color":{"desktop":"","tablet":"","mobile":""},"font-size-section-fb-html-6":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-html-6-alignment":{"desktop":"center","tablet":"center","mobile":"center"},"font-weight-section-fb-html-6":"inherit","font-family-section-fb-html-6":"inherit","font-extras-section-fb-html-6":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"section-fb-html-6-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-social-6-space":{"desktop":"","tablet":"","mobile":""},"header-social-6-bg-space":"","header-social-6-size":{"desktop":18,"tablet":"","mobile":""},"header-social-6-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-social-6-color":"","header-social-6-h-color":"","header-social-6-bg-color":"","header-social-6-bg-h-color":"","header-social-6-label-toggle":false,"header-social-6-color-type":"custom","header-social-6-brand-hover-toggle":false,"font-size-section-hb-social-icons-6":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-social-icons-6":{"items":[{"id":"facebook","enabled":true,"source":"icon","url":"","color":"#557dbc","background":"transparent","icon":"facebook","label":"Facebook"},{"id":"twitter","enabled":true,"source":"icon","url":"","color":"#7acdee","background":"transparent","icon":"twitter","label":"Twitter"},{"id":"instagram","enabled":true,"source":"icon","url":"","color":"#8a3ab9","background":"transparent","icon":"instagram","label":"Instagram"}]},"section-hb-social-icons-6-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-social-6-space":{"desktop":"","tablet":"","mobile":""},"footer-social-6-bg-space":"","footer-social-6-size":{"desktop":18,"tablet":"","mobile":""},"footer-social-6-radius":"","footer-social-6-color":"","footer-social-6-h-color":"","footer-social-6-bg-color":"","footer-social-6-bg-h-color":"","footer-social-6-label-toggle":false,"footer-social-6-color-type":"custom","footer-social-6-brand-color":"","footer-social-6-brand-label-color":"","footer-social-6-brand-hover-toggle":false,"font-size-section-fb-social-icons-6":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-social-icons-6":{"items":[{"id":"facebook","enabled":true,"source":"icon","url":"","color":"#557dbc","background":"transparent","icon":"facebook","label":"Facebook"},{"id":"twitter","enabled":true,"source":"icon","url":"","color":"#7acdee","background":"transparent","icon":"twitter","label":"Twitter"},{"id":"instagram","enabled":true,"source":"icon","url":"","color":"#8a3ab9","background":"transparent","icon":"instagram","label":"Instagram"}]},"footer-social-6-alignment":{"desktop":"center","tablet":"center","mobile":"center"},"section-fb-social-icons-6-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-widget-6-title-color":{"desktop":"","tablet":"","mobile":""},"header-widget-6-color":{"desktop":"","tablet":"","mobile":""},"header-widget-6-link-color":{"desktop":"","tablet":"","mobile":""},"header-widget-6-link-h-color":{"desktop":"","tablet":"","mobile":""},"header-widget-6-font-family":"inherit","header-widget-6-font-weight":"inherit","header-widget-6-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-widget-6-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"header-widget-6-content-font-family":"inherit","header-widget-6-content-font-weight":"inherit","header-widget-6-content-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-widget-6-content-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"sidebar-widgets-header-widget-6-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-widget-6-title-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-6-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-6-link-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-6-link-h-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-6-font-family":"inherit","footer-widget-6-font-weight":"inherit","footer-widget-6-text-transform":"","footer-widget-6-line-height":"","footer-widget-6-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-widget-6-content-font-family":"inherit","footer-widget-6-content-font-weight":"inherit","footer-widget-6-content-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"footer-widget-6-content-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-widget-alignment-6":{"desktop":"left","tablet":"center","mobile":"center"},"sidebar-widgets-footer-widget-6-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu6-bg-color":"","header-menu6-color":"","header-menu6-h-bg-color":"","header-menu6-h-color":"","header-menu6-a-bg-color":"","header-menu6-a-color":"","header-menu6-bg-obj-responsive":{"desktop":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""},"tablet":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""}},"header-menu6-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu6-h-bg-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu6-h-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu6-a-bg-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu6-a-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu6-menu-hover-animation":"","header-menu6-submenu-container-animation":"","section-hb-menu-6-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu6-menu-spacing":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu6-submenu-item-border":false,"header-menu6-submenu-item-b-size":"1","header-menu6-submenu-item-b-color":"#eaeaea","header-menu6-submenu-border-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu6-submenu-top-offset":"","header-menu6-submenu-width":"","header-menu6-submenu-border":{"top":2,"bottom":0,"left":0,"right":0},"header-menu6-menu-stack-on-mobile":true,"header-menu6-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu6-font-weight":"inherit","header-menu6-font-family":"inherit","header-menu6-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"section-hb-divider-6-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-fb-divider-6-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button7-text":"Button","header-button7-link-option":{"url":"https:\/\/www.wpastra.com","new_tab":false,"link_rel":""},"header-button7-font-family":"inherit","header-button7-font-weight":"inherit","header-button7-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"header-button7-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button7-text-color":{"desktop":"","tablet":"","mobile":""},"header-button7-back-color":{"desktop":"","tablet":"","mobile":""},"header-button7-text-h-color":{"desktop":"","tablet":"","mobile":""},"header-button7-back-h-color":{"desktop":"","tablet":"","mobile":""},"header-button7-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button7-border-size":{"top":"","right":"","bottom":"","left":""},"header-button7-border-color":{"desktop":"","tablet":"","mobile":""},"header-button7-border-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button7-border-radius":"","section-hb-button-7-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-hb-button-7-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"sticky-header-button7-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button7-text":"Button","footer-button7-link-option":{"url":"https:\/\/www.wpastra.com","new_tab":false,"link_rel":""},"footer-button7-font-family":"inherit","footer-button7-font-weight":"inherit","footer-button7-text-transform":"","footer-button7-line-height":"","footer-button7-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button7-text-color":{"desktop":"","tablet":"","mobile":""},"footer-button7-back-color":{"desktop":"","tablet":"","mobile":""},"footer-button7-text-h-color":{"desktop":"","tablet":"","mobile":""},"footer-button7-back-h-color":{"desktop":"","tablet":"","mobile":""},"footer-button7-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button7-border-size":{"top":"","right":"","bottom":"","left":""},"footer-button7-border-color":{"desktop":"","tablet":"","mobile":""},"footer-button7-border-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button-7-alignment":{"desktop":"center","tablet":"center","mobile":"center"},"section-fb-button-7-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-fb-button-7-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-html-7":"Insert HTML text here.","header-html-7color":{"desktop":"","tablet":"","mobile":""},"header-html-7link-color":{"desktop":"","tablet":"","mobile":""},"header-html-7link-h-color":{"desktop":"","tablet":"","mobile":""},"font-size-section-hb-html-7":{"desktop":15,"tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"font-weight-section-hb-html-7":"inherit","font-family-section-hb-html-7":"inherit","font-extras-section-hb-html-7":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"section-hb-html-7-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-html-7":"Insert HTML text here.","footer-html-7color":{"desktop":"","tablet":"","mobile":""},"footer-html-7link-color":{"desktop":"","tablet":"","mobile":""},"footer-html-7link-h-color":{"desktop":"","tablet":"","mobile":""},"font-size-section-fb-html-7":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-html-7-alignment":{"desktop":"center","tablet":"center","mobile":"center"},"font-weight-section-fb-html-7":"inherit","font-family-section-fb-html-7":"inherit","font-extras-section-fb-html-7":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"section-fb-html-7-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-social-7-space":{"desktop":"","tablet":"","mobile":""},"header-social-7-bg-space":"","header-social-7-size":{"desktop":18,"tablet":"","mobile":""},"header-social-7-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-social-7-color":"","header-social-7-h-color":"","header-social-7-bg-color":"","header-social-7-bg-h-color":"","header-social-7-label-toggle":false,"header-social-7-color-type":"custom","header-social-7-brand-hover-toggle":false,"font-size-section-hb-social-icons-7":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-social-icons-7":{"items":[{"id":"facebook","enabled":true,"source":"icon","url":"","color":"#557dbc","background":"transparent","icon":"facebook","label":"Facebook"},{"id":"twitter","enabled":true,"source":"icon","url":"","color":"#7acdee","background":"transparent","icon":"twitter","label":"Twitter"},{"id":"instagram","enabled":true,"source":"icon","url":"","color":"#8a3ab9","background":"transparent","icon":"instagram","label":"Instagram"}]},"section-hb-social-icons-7-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-social-7-space":{"desktop":"","tablet":"","mobile":""},"footer-social-7-bg-space":"","footer-social-7-size":{"desktop":18,"tablet":"","mobile":""},"footer-social-7-radius":"","footer-social-7-color":"","footer-social-7-h-color":"","footer-social-7-bg-color":"","footer-social-7-bg-h-color":"","footer-social-7-label-toggle":false,"footer-social-7-color-type":"custom","footer-social-7-brand-color":"","footer-social-7-brand-label-color":"","footer-social-7-brand-hover-toggle":false,"font-size-section-fb-social-icons-7":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-social-icons-7":{"items":[{"id":"facebook","enabled":true,"source":"icon","url":"","color":"#557dbc","background":"transparent","icon":"facebook","label":"Facebook"},{"id":"twitter","enabled":true,"source":"icon","url":"","color":"#7acdee","background":"transparent","icon":"twitter","label":"Twitter"},{"id":"instagram","enabled":true,"source":"icon","url":"","color":"#8a3ab9","background":"transparent","icon":"instagram","label":"Instagram"}]},"footer-social-7-alignment":{"desktop":"center","tablet":"center","mobile":"center"},"section-fb-social-icons-7-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-widget-7-title-color":{"desktop":"","tablet":"","mobile":""},"header-widget-7-color":{"desktop":"","tablet":"","mobile":""},"header-widget-7-link-color":{"desktop":"","tablet":"","mobile":""},"header-widget-7-link-h-color":{"desktop":"","tablet":"","mobile":""},"header-widget-7-font-family":"inherit","header-widget-7-font-weight":"inherit","header-widget-7-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-widget-7-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"header-widget-7-content-font-family":"inherit","header-widget-7-content-font-weight":"inherit","header-widget-7-content-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-widget-7-content-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"sidebar-widgets-header-widget-7-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-widget-7-title-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-7-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-7-link-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-7-link-h-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-7-font-family":"inherit","footer-widget-7-font-weight":"inherit","footer-widget-7-text-transform":"","footer-widget-7-line-height":"","footer-widget-7-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-widget-7-content-font-family":"inherit","footer-widget-7-content-font-weight":"inherit","footer-widget-7-content-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"footer-widget-7-content-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-widget-alignment-7":{"desktop":"left","tablet":"center","mobile":"center"},"sidebar-widgets-footer-widget-7-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu7-bg-color":"","header-menu7-color":"","header-menu7-h-bg-color":"","header-menu7-h-color":"","header-menu7-a-bg-color":"","header-menu7-a-color":"","header-menu7-bg-obj-responsive":{"desktop":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""},"tablet":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""}},"header-menu7-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu7-h-bg-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu7-h-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu7-a-bg-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu7-a-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu7-menu-hover-animation":"","header-menu7-submenu-container-animation":"","section-hb-menu-7-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu7-menu-spacing":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu7-submenu-item-border":false,"header-menu7-submenu-item-b-size":"1","header-menu7-submenu-item-b-color":"#eaeaea","header-menu7-submenu-border-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu7-submenu-top-offset":"","header-menu7-submenu-width":"","header-menu7-submenu-border":{"top":2,"bottom":0,"left":0,"right":0},"header-menu7-menu-stack-on-mobile":true,"header-menu7-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu7-font-weight":"inherit","header-menu7-font-family":"inherit","header-menu7-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"section-hb-divider-7-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-fb-divider-7-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button8-text":"Button","header-button8-link-option":{"url":"https:\/\/www.wpastra.com","new_tab":false,"link_rel":""},"header-button8-font-family":"inherit","header-button8-font-weight":"inherit","header-button8-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"header-button8-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button8-text-color":{"desktop":"","tablet":"","mobile":""},"header-button8-back-color":{"desktop":"","tablet":"","mobile":""},"header-button8-text-h-color":{"desktop":"","tablet":"","mobile":""},"header-button8-back-h-color":{"desktop":"","tablet":"","mobile":""},"header-button8-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button8-border-size":{"top":"","right":"","bottom":"","left":""},"header-button8-border-color":{"desktop":"","tablet":"","mobile":""},"header-button8-border-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button8-border-radius":"","section-hb-button-8-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-hb-button-8-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"sticky-header-button8-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button8-text":"Button","footer-button8-link-option":{"url":"https:\/\/www.wpastra.com","new_tab":false,"link_rel":""},"footer-button8-font-family":"inherit","footer-button8-font-weight":"inherit","footer-button8-text-transform":"","footer-button8-line-height":"","footer-button8-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button8-text-color":{"desktop":"","tablet":"","mobile":""},"footer-button8-back-color":{"desktop":"","tablet":"","mobile":""},"footer-button8-text-h-color":{"desktop":"","tablet":"","mobile":""},"footer-button8-back-h-color":{"desktop":"","tablet":"","mobile":""},"footer-button8-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button8-border-size":{"top":"","right":"","bottom":"","left":""},"footer-button8-border-color":{"desktop":"","tablet":"","mobile":""},"footer-button8-border-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button-8-alignment":{"desktop":"center","tablet":"center","mobile":"center"},"section-fb-button-8-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-fb-button-8-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-html-8":"Insert HTML text here.","header-html-8color":{"desktop":"","tablet":"","mobile":""},"header-html-8link-color":{"desktop":"","tablet":"","mobile":""},"header-html-8link-h-color":{"desktop":"","tablet":"","mobile":""},"font-size-section-hb-html-8":{"desktop":15,"tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"font-weight-section-hb-html-8":"inherit","font-family-section-hb-html-8":"inherit","font-extras-section-hb-html-8":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"section-hb-html-8-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-html-8":"Insert HTML text here.","footer-html-8color":{"desktop":"","tablet":"","mobile":""},"footer-html-8link-color":{"desktop":"","tablet":"","mobile":""},"footer-html-8link-h-color":{"desktop":"","tablet":"","mobile":""},"font-size-section-fb-html-8":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-html-8-alignment":{"desktop":"center","tablet":"center","mobile":"center"},"font-weight-section-fb-html-8":"inherit","font-family-section-fb-html-8":"inherit","font-extras-section-fb-html-8":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"section-fb-html-8-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-social-8-space":{"desktop":"","tablet":"","mobile":""},"header-social-8-bg-space":"","header-social-8-size":{"desktop":18,"tablet":"","mobile":""},"header-social-8-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-social-8-color":"","header-social-8-h-color":"","header-social-8-bg-color":"","header-social-8-bg-h-color":"","header-social-8-label-toggle":false,"header-social-8-color-type":"custom","header-social-8-brand-hover-toggle":false,"font-size-section-hb-social-icons-8":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-social-icons-8":{"items":[{"id":"facebook","enabled":true,"source":"icon","url":"","color":"#557dbc","background":"transparent","icon":"facebook","label":"Facebook"},{"id":"twitter","enabled":true,"source":"icon","url":"","color":"#7acdee","background":"transparent","icon":"twitter","label":"Twitter"},{"id":"instagram","enabled":true,"source":"icon","url":"","color":"#8a3ab9","background":"transparent","icon":"instagram","label":"Instagram"}]},"section-hb-social-icons-8-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-social-8-space":{"desktop":"","tablet":"","mobile":""},"footer-social-8-bg-space":"","footer-social-8-size":{"desktop":18,"tablet":"","mobile":""},"footer-social-8-radius":"","footer-social-8-color":"","footer-social-8-h-color":"","footer-social-8-bg-color":"","footer-social-8-bg-h-color":"","footer-social-8-label-toggle":false,"footer-social-8-color-type":"custom","footer-social-8-brand-color":"","footer-social-8-brand-label-color":"","footer-social-8-brand-hover-toggle":false,"font-size-section-fb-social-icons-8":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-social-icons-8":{"items":[{"id":"facebook","enabled":true,"source":"icon","url":"","color":"#557dbc","background":"transparent","icon":"facebook","label":"Facebook"},{"id":"twitter","enabled":true,"source":"icon","url":"","color":"#7acdee","background":"transparent","icon":"twitter","label":"Twitter"},{"id":"instagram","enabled":true,"source":"icon","url":"","color":"#8a3ab9","background":"transparent","icon":"instagram","label":"Instagram"}]},"footer-social-8-alignment":{"desktop":"center","tablet":"center","mobile":"center"},"section-fb-social-icons-8-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-widget-8-title-color":{"desktop":"","tablet":"","mobile":""},"header-widget-8-color":{"desktop":"","tablet":"","mobile":""},"header-widget-8-link-color":{"desktop":"","tablet":"","mobile":""},"header-widget-8-link-h-color":{"desktop":"","tablet":"","mobile":""},"header-widget-8-font-family":"inherit","header-widget-8-font-weight":"inherit","header-widget-8-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-widget-8-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"header-widget-8-content-font-family":"inherit","header-widget-8-content-font-weight":"inherit","header-widget-8-content-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-widget-8-content-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"sidebar-widgets-header-widget-8-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-widget-8-title-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-8-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-8-link-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-8-link-h-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-8-font-family":"inherit","footer-widget-8-font-weight":"inherit","footer-widget-8-text-transform":"","footer-widget-8-line-height":"","footer-widget-8-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-widget-8-content-font-family":"inherit","footer-widget-8-content-font-weight":"inherit","footer-widget-8-content-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"footer-widget-8-content-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-widget-alignment-8":{"desktop":"left","tablet":"center","mobile":"center"},"sidebar-widgets-footer-widget-8-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu8-bg-color":"","header-menu8-color":"","header-menu8-h-bg-color":"","header-menu8-h-color":"","header-menu8-a-bg-color":"","header-menu8-a-color":"","header-menu8-bg-obj-responsive":{"desktop":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""},"tablet":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""}},"header-menu8-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu8-h-bg-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu8-h-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu8-a-bg-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu8-a-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu8-menu-hover-animation":"","header-menu8-submenu-container-animation":"","section-hb-menu-8-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu8-menu-spacing":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu8-submenu-item-border":false,"header-menu8-submenu-item-b-size":"1","header-menu8-submenu-item-b-color":"#eaeaea","header-menu8-submenu-border-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu8-submenu-top-offset":"","header-menu8-submenu-width":"","header-menu8-submenu-border":{"top":2,"bottom":0,"left":0,"right":0},"header-menu8-menu-stack-on-mobile":true,"header-menu8-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu8-font-weight":"inherit","header-menu8-font-family":"inherit","header-menu8-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"section-hb-divider-8-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-fb-divider-8-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button9-text":"Button","header-button9-link-option":{"url":"https:\/\/www.wpastra.com","new_tab":false,"link_rel":""},"header-button9-font-family":"inherit","header-button9-font-weight":"inherit","header-button9-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"header-button9-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button9-text-color":{"desktop":"","tablet":"","mobile":""},"header-button9-back-color":{"desktop":"","tablet":"","mobile":""},"header-button9-text-h-color":{"desktop":"","tablet":"","mobile":""},"header-button9-back-h-color":{"desktop":"","tablet":"","mobile":""},"header-button9-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button9-border-size":{"top":"","right":"","bottom":"","left":""},"header-button9-border-color":{"desktop":"","tablet":"","mobile":""},"header-button9-border-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button9-border-radius":"","section-hb-button-9-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-hb-button-9-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"sticky-header-button9-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button9-text":"Button","footer-button9-link-option":{"url":"https:\/\/www.wpastra.com","new_tab":false,"link_rel":""},"footer-button9-font-family":"inherit","footer-button9-font-weight":"inherit","footer-button9-text-transform":"","footer-button9-line-height":"","footer-button9-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button9-text-color":{"desktop":"","tablet":"","mobile":""},"footer-button9-back-color":{"desktop":"","tablet":"","mobile":""},"footer-button9-text-h-color":{"desktop":"","tablet":"","mobile":""},"footer-button9-back-h-color":{"desktop":"","tablet":"","mobile":""},"footer-button9-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button9-border-size":{"top":"","right":"","bottom":"","left":""},"footer-button9-border-color":{"desktop":"","tablet":"","mobile":""},"footer-button9-border-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button-9-alignment":{"desktop":"center","tablet":"center","mobile":"center"},"section-fb-button-9-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-fb-button-9-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-html-9":"Insert HTML text here.","header-html-9color":{"desktop":"","tablet":"","mobile":""},"header-html-9link-color":{"desktop":"","tablet":"","mobile":""},"header-html-9link-h-color":{"desktop":"","tablet":"","mobile":""},"font-size-section-hb-html-9":{"desktop":15,"tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"font-weight-section-hb-html-9":"inherit","font-family-section-hb-html-9":"inherit","font-extras-section-hb-html-9":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"section-hb-html-9-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-html-9":"Insert HTML text here.","footer-html-9color":{"desktop":"","tablet":"","mobile":""},"footer-html-9link-color":{"desktop":"","tablet":"","mobile":""},"footer-html-9link-h-color":{"desktop":"","tablet":"","mobile":""},"font-size-section-fb-html-9":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-html-9-alignment":{"desktop":"center","tablet":"center","mobile":"center"},"font-weight-section-fb-html-9":"inherit","font-family-section-fb-html-9":"inherit","font-extras-section-fb-html-9":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"section-fb-html-9-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-social-9-space":{"desktop":"","tablet":"","mobile":""},"header-social-9-bg-space":"","header-social-9-size":{"desktop":18,"tablet":"","mobile":""},"header-social-9-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-social-9-color":"","header-social-9-h-color":"","header-social-9-bg-color":"","header-social-9-bg-h-color":"","header-social-9-label-toggle":false,"header-social-9-color-type":"custom","header-social-9-brand-hover-toggle":false,"font-size-section-hb-social-icons-9":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-social-icons-9":{"items":[{"id":"facebook","enabled":true,"source":"icon","url":"","color":"#557dbc","background":"transparent","icon":"facebook","label":"Facebook"},{"id":"twitter","enabled":true,"source":"icon","url":"","color":"#7acdee","background":"transparent","icon":"twitter","label":"Twitter"},{"id":"instagram","enabled":true,"source":"icon","url":"","color":"#8a3ab9","background":"transparent","icon":"instagram","label":"Instagram"}]},"section-hb-social-icons-9-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-social-9-space":{"desktop":"","tablet":"","mobile":""},"footer-social-9-bg-space":"","footer-social-9-size":{"desktop":18,"tablet":"","mobile":""},"footer-social-9-radius":"","footer-social-9-color":"","footer-social-9-h-color":"","footer-social-9-bg-color":"","footer-social-9-bg-h-color":"","footer-social-9-label-toggle":false,"footer-social-9-color-type":"custom","footer-social-9-brand-color":"","footer-social-9-brand-label-color":"","footer-social-9-brand-hover-toggle":false,"font-size-section-fb-social-icons-9":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-social-icons-9":{"items":[{"id":"facebook","enabled":true,"source":"icon","url":"","color":"#557dbc","background":"transparent","icon":"facebook","label":"Facebook"},{"id":"twitter","enabled":true,"source":"icon","url":"","color":"#7acdee","background":"transparent","icon":"twitter","label":"Twitter"},{"id":"instagram","enabled":true,"source":"icon","url":"","color":"#8a3ab9","background":"transparent","icon":"instagram","label":"Instagram"}]},"footer-social-9-alignment":{"desktop":"center","tablet":"center","mobile":"center"},"section-fb-social-icons-9-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-widget-9-title-color":{"desktop":"","tablet":"","mobile":""},"header-widget-9-color":{"desktop":"","tablet":"","mobile":""},"header-widget-9-link-color":{"desktop":"","tablet":"","mobile":""},"header-widget-9-link-h-color":{"desktop":"","tablet":"","mobile":""},"header-widget-9-font-family":"inherit","header-widget-9-font-weight":"inherit","header-widget-9-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-widget-9-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"header-widget-9-content-font-family":"inherit","header-widget-9-content-font-weight":"inherit","header-widget-9-content-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-widget-9-content-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"sidebar-widgets-header-widget-9-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-widget-9-title-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-9-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-9-link-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-9-link-h-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-9-font-family":"inherit","footer-widget-9-font-weight":"inherit","footer-widget-9-text-transform":"","footer-widget-9-line-height":"","footer-widget-9-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-widget-9-content-font-family":"inherit","footer-widget-9-content-font-weight":"inherit","footer-widget-9-content-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"footer-widget-9-content-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-widget-alignment-9":{"desktop":"left","tablet":"center","mobile":"center"},"sidebar-widgets-footer-widget-9-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu9-bg-color":"","header-menu9-color":"","header-menu9-h-bg-color":"","header-menu9-h-color":"","header-menu9-a-bg-color":"","header-menu9-a-color":"","header-menu9-bg-obj-responsive":{"desktop":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""},"tablet":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""}},"header-menu9-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu9-h-bg-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu9-h-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu9-a-bg-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu9-a-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu9-menu-hover-animation":"","header-menu9-submenu-container-animation":"","section-hb-menu-9-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu9-menu-spacing":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu9-submenu-item-border":false,"header-menu9-submenu-item-b-size":"1","header-menu9-submenu-item-b-color":"#eaeaea","header-menu9-submenu-border-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu9-submenu-top-offset":"","header-menu9-submenu-width":"","header-menu9-submenu-border":{"top":2,"bottom":0,"left":0,"right":0},"header-menu9-menu-stack-on-mobile":true,"header-menu9-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu9-font-weight":"inherit","header-menu9-font-family":"inherit","header-menu9-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"section-hb-divider-9-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-fb-divider-9-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button10-text":"Button","header-button10-link-option":{"url":"https:\/\/www.wpastra.com","new_tab":false,"link_rel":""},"header-button10-font-family":"inherit","header-button10-font-weight":"inherit","header-button10-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"header-button10-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button10-text-color":{"desktop":"","tablet":"","mobile":""},"header-button10-back-color":{"desktop":"","tablet":"","mobile":""},"header-button10-text-h-color":{"desktop":"","tablet":"","mobile":""},"header-button10-back-h-color":{"desktop":"","tablet":"","mobile":""},"header-button10-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button10-border-size":{"top":"","right":"","bottom":"","left":""},"header-button10-border-color":{"desktop":"","tablet":"","mobile":""},"header-button10-border-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-button10-border-radius":"","section-hb-button-10-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-hb-button-10-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"sticky-header-button10-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button10-text":"Button","footer-button10-link-option":{"url":"https:\/\/www.wpastra.com","new_tab":false,"link_rel":""},"footer-button10-font-family":"inherit","footer-button10-font-weight":"inherit","footer-button10-text-transform":"","footer-button10-line-height":"","footer-button10-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button10-text-color":{"desktop":"","tablet":"","mobile":""},"footer-button10-back-color":{"desktop":"","tablet":"","mobile":""},"footer-button10-text-h-color":{"desktop":"","tablet":"","mobile":""},"footer-button10-back-h-color":{"desktop":"","tablet":"","mobile":""},"footer-button10-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button10-border-size":{"top":"","right":"","bottom":"","left":""},"footer-button10-border-color":{"desktop":"","tablet":"","mobile":""},"footer-button10-border-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-button-10-alignment":{"desktop":"center","tablet":"center","mobile":"center"},"section-fb-button-10-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-fb-button-10-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-html-10":"Insert HTML text here.","header-html-10color":{"desktop":"","tablet":"","mobile":""},"header-html-10link-color":{"desktop":"","tablet":"","mobile":""},"header-html-10link-h-color":{"desktop":"","tablet":"","mobile":""},"font-size-section-hb-html-10":{"desktop":15,"tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"font-weight-section-hb-html-10":"inherit","font-family-section-hb-html-10":"inherit","font-extras-section-hb-html-10":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"section-hb-html-10-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-html-10":"Insert HTML text here.","footer-html-10color":{"desktop":"","tablet":"","mobile":""},"footer-html-10link-color":{"desktop":"","tablet":"","mobile":""},"footer-html-10link-h-color":{"desktop":"","tablet":"","mobile":""},"font-size-section-fb-html-10":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-html-10-alignment":{"desktop":"center","tablet":"center","mobile":"center"},"font-weight-section-fb-html-10":"inherit","font-family-section-fb-html-10":"inherit","font-extras-section-fb-html-10":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"section-fb-html-10-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-social-10-space":{"desktop":"","tablet":"","mobile":""},"header-social-10-bg-space":"","header-social-10-size":{"desktop":18,"tablet":"","mobile":""},"header-social-10-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-social-10-color":"","header-social-10-h-color":"","header-social-10-bg-color":"","header-social-10-bg-h-color":"","header-social-10-label-toggle":false,"header-social-10-color-type":"custom","header-social-10-brand-hover-toggle":false,"font-size-section-hb-social-icons-10":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-social-icons-10":{"items":[{"id":"facebook","enabled":true,"source":"icon","url":"","color":"#557dbc","background":"transparent","icon":"facebook","label":"Facebook"},{"id":"twitter","enabled":true,"source":"icon","url":"","color":"#7acdee","background":"transparent","icon":"twitter","label":"Twitter"},{"id":"instagram","enabled":true,"source":"icon","url":"","color":"#8a3ab9","background":"transparent","icon":"instagram","label":"Instagram"}]},"section-hb-social-icons-10-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-social-10-space":{"desktop":"","tablet":"","mobile":""},"footer-social-10-bg-space":"","footer-social-10-size":{"desktop":18,"tablet":"","mobile":""},"footer-social-10-radius":"","footer-social-10-color":"","footer-social-10-h-color":"","footer-social-10-bg-color":"","footer-social-10-bg-h-color":"","footer-social-10-label-toggle":false,"footer-social-10-color-type":"custom","footer-social-10-brand-color":"","footer-social-10-brand-label-color":"","footer-social-10-brand-hover-toggle":false,"font-size-section-fb-social-icons-10":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-social-icons-10":{"items":[{"id":"facebook","enabled":true,"source":"icon","url":"","color":"#557dbc","background":"transparent","icon":"facebook","label":"Facebook"},{"id":"twitter","enabled":true,"source":"icon","url":"","color":"#7acdee","background":"transparent","icon":"twitter","label":"Twitter"},{"id":"instagram","enabled":true,"source":"icon","url":"","color":"#8a3ab9","background":"transparent","icon":"instagram","label":"Instagram"}]},"footer-social-10-alignment":{"desktop":"center","tablet":"center","mobile":"center"},"section-fb-social-icons-10-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-widget-10-title-color":{"desktop":"","tablet":"","mobile":""},"header-widget-10-color":{"desktop":"","tablet":"","mobile":""},"header-widget-10-link-color":{"desktop":"","tablet":"","mobile":""},"header-widget-10-link-h-color":{"desktop":"","tablet":"","mobile":""},"header-widget-10-font-family":"inherit","header-widget-10-font-weight":"inherit","header-widget-10-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-widget-10-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"header-widget-10-content-font-family":"inherit","header-widget-10-content-font-weight":"inherit","header-widget-10-content-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-widget-10-content-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"sidebar-widgets-header-widget-10-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-widget-10-title-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-10-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-10-link-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-10-link-h-color":{"desktop":"","tablet":"","mobile":""},"footer-widget-10-font-family":"inherit","footer-widget-10-font-weight":"inherit","footer-widget-10-text-transform":"","footer-widget-10-line-height":"","footer-widget-10-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-widget-10-content-font-family":"inherit","footer-widget-10-content-font-weight":"inherit","footer-widget-10-content-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"footer-widget-10-content-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-widget-alignment-10":{"desktop":"left","tablet":"center","mobile":"center"},"sidebar-widgets-footer-widget-10-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu10-bg-color":"","header-menu10-color":"","header-menu10-h-bg-color":"","header-menu10-h-color":"","header-menu10-a-bg-color":"","header-menu10-a-color":"","header-menu10-bg-obj-responsive":{"desktop":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""},"tablet":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""}},"header-menu10-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu10-h-bg-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu10-h-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu10-a-bg-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu10-a-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu10-menu-hover-animation":"","header-menu10-submenu-container-animation":"","section-hb-menu-10-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu10-menu-spacing":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu10-submenu-item-border":false,"header-menu10-submenu-item-b-size":"1","header-menu10-submenu-item-b-color":"#eaeaea","header-menu10-submenu-border-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu10-submenu-top-offset":"","header-menu10-submenu-width":"","header-menu10-submenu-border":{"top":2,"bottom":0,"left":0,"right":0},"header-menu10-menu-stack-on-mobile":true,"header-menu10-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-menu10-font-weight":"inherit","header-menu10-font-family":"inherit","header-menu10-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"section-hb-divider-10-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"section-fb-divider-10-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"sticky-header-on-devices":"desktop","sticky-header-style":"none","footer-desktop-items":{"above":{"above_1":[],"above_2":[],"above_3":[],"above_4":[],"above_5":[],"above_6":[]},"primary":{"primary_1":[],"primary_2":["widget-1"],"primary_3":[],"primary_4":[],"primary_5":[],"primary_6":[]},"below":{"below_1":["copyright"],"below_2":[],"below_3":[],"below_4":[],"below_5":[],"below_6":[]},"group":"astra-settings[footer-desktop-items]","rows":["above","primary","below"],"zones":{"above":{"above_1":"Above Section 1","above_2":"Above Section 2","above_3":"Above Section 3","above_4":"Above Section 4","above_5":"Above Section 5","above_6":"Above Section 6"},"primary":{"primary_1":"Primary Section 1","primary_2":"Primary Section 2","primary_3":"Primary Section 3","primary_4":"Primary Section 4","primary_5":"Primary Section 5","primary_6":"Primary Section 6"},"below":{"below_1":"Below Section 1","below_2":"Below Section 2","below_3":"Below Section 3","below_4":"Below Section 4","below_5":"Below Section 5","below_6":"Below Section 6"}},"layouts":{"above":{"column":2,"layout":{"desktop":"2-equal","tablet":"2-equal","mobile":"full"}},"primary":{"column":"3","layout":{"desktop":"3-cwide","tablet":"full","mobile":"full","flag":true}},"below":{"column":"1","layout":{"mobile":"full","tablet":"full","desktop":"full"}}},"status":{"above":true,"primary":true,"below":true},"flag":true},"hba-footer-height":60,"hba-footer-column":2,"hba-footer-layout":{"desktop":"2-equal","tablet":"2-equal","mobile":"full"},"hba-footer-bg-obj-responsive":{"desktop":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"tablet":"","mobile":""},"hbb-footer-bg-obj-responsive":{"desktop":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"color","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"tablet":"","mobile":""},"hb-footer-bg-obj-responsive":{"desktop":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-media":"","background-type":"color","overlay-type":"","overlay-color":"","overlay-gradient":""},"tablet":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""}},"hbb-footer-top-border-color":"rgba(255,255,255,0.2)","hbb-footer-separator":"1","section-header-builder-layout-margin":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"hbb-footer-height":80,"hbb-footer-column":"1","hbb-footer-layout":{"desktop":"full","tablet":"full","mobile":"full","flag":true},"hba-footer-layout-width":"content","hb-footer-layout-width":"content","hbb-footer-layout-width":"content","hba-footer-vertical-alignment":"flex-start","hb-footer-vertical-alignment":"center","hbb-footer-vertical-alignment":"center","footer-bg-obj-responsive":{"desktop":{"background-color":"var(--ast-global-color-1)","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"color","overlay-type":"","overlay-color":"","overlay-gradient":""},"tablet":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""}},"hb-footer-column":"3","hb-footer-separator":1,"hb-footer-bottom-border-color":"#e6e6e6","hb-footer-layout":{"desktop":"3-cwide","tablet":"full","mobile":"full","flag":true},"hb-footer-main-sep":"0","hb-footer-main-sep-color":"#e6e6e6","footer-copyright-editor":"Copyright \u00a9 [current_year] [site_title]","footer-copyright-color":"var(--ast-global-color-5)","line-height-section-footer-copyright":2,"footer-copyright-alignment":{"desktop":"center","tablet":"center","mobile":"center"},"font-size-section-footer-copyright":{"desktop":"16","tablet":"15","mobile":"15","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"font-weight-section-footer-copyright":"inherit","font-family-section-footer-copyright":"inherit","font-extras-section-footer-copyright":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"footer-menu-alignment":{"desktop":"center","tablet":"center","mobile":"center"},"section-below-footer-builder-padding":{"desktop":{"top":"30","right":"30","bottom":"30","left":"30"},"tablet":{"top":"30","right":"25","bottom":"30","left":"25"},"mobile":{"top":"30","right":"20","bottom":"30","left":"20"},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-search-icon-space":{"desktop":18,"tablet":18,"mobile":18},"header-search-icon-color":{"desktop":"","tablet":"","mobile":""},"header-search-width":{"desktop":"","tablet":"","mobile":""},"live-search":false,"live-search-post-types":{"post":1,"page":1},"transparent-header-social-icons-color":{"desktop":"","tablet":"","mobile":""},"transparent-header-social-icons-h-color":{"desktop":"","tablet":"","mobile":""},"transparent-header-social-icons-bg-color":{"desktop":"","tablet":"","mobile":""},"transparent-header-social-icons-bg-h-color":{"desktop":"","tablet":"","mobile":""},"transparent-header-html-text-color":"","transparent-header-html-link-color":"","transparent-header-html-link-h-color":"","transparent-header-widget-title-color":"","transparent-header-widget-content-color":"","transparent-header-widget-link-color":"","transparent-header-widget-link-h-color":"","transparent-header-button-text-color":"","transparent-header-button-text-h-color":"","transparent-header-button-bg-color":"","transparent-header-button-bg-h-color":"","off-canvas-layout":"side-panel","off-canvas-slide":"right","header-builder-menu-toggle-target":"icon","header-offcanvas-content-alignment":"flex-start","off-canvas-background":{"background-color":"#ffffff","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""},"off-canvas-close-color":"#3a3a3a","mobile-header-type":"dropdown","off-canvas-inner-spacing":"","footer-menu-layout":{"desktop":"horizontal","tablet":"vertical","mobile":"vertical"},"footer-menu-bg-obj-responsive":{"desktop":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""},"tablet":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""}},"footer-menu-color-responsive":{"desktop":"","tablet":"","mobile":""},"footer-menu-h-bg-color-responsive":{"desktop":"","tablet":"","mobile":""},"footer-menu-h-color-responsive":{"desktop":"","tablet":"","mobile":""},"footer-menu-a-bg-color-responsive":{"desktop":"","tablet":"","mobile":""},"footer-menu-a-color-responsive":{"desktop":"","tablet":"","mobile":""},"footer-menu-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-menu-font-weight":"inherit","footer-menu-font-family":"inherit","footer-menu-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"footer-main-menu-spacing":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"0","right":"20","bottom":"0","left":"20"},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-trigger-icon":"menu","mobile-header-toggle-icon-size":20,"mobile-header-toggle-btn-border-size":{"top":1,"right":1,"bottom":1,"left":1},"mobile-header-toggle-border-radius":2,"mobile-header-toggle-border-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"mobile-header-label-font-family":"inherit","mobile-header-label-font-weight":"inherit","mobile-header-label-text-transform":"","mobile-header-label-line-height":"","mobile-header-label-font-size":"","global-color-palette":{"labels":["Theme Color","Link Hover Color","Heading Color","Text Color","Background Color","Extra Color 1","Extra Color 2","Extra Color 3","Extra Color 4"],"palette":["#0274be","#0d68ae","#2f3f50","#3a3a3a","#fafafa","#ffffff","#fbfcff","#003bb1","#BFD1FF"],"flag":false},"header-logo-color":"","header-mobile-menu-bg-color":"","header-mobile-menu-color":"","header-mobile-menu-h-bg-color":"","header-mobile-menu-h-color":"","header-mobile-menu-a-bg-color":"","header-mobile-menu-a-color":"","header-mobile-menu-bg-obj-responsive":{"desktop":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""},"tablet":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","overlay-type":"","overlay-color":"","overlay-gradient":""}},"header-mobile-menu-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-mobile-menu-h-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-mobile-menu-a-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-mobile-menu-h-bg-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-mobile-menu-a-bg-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-mobile-menu-submenu-container-animation":"fade","header-mobile-menu-submenu-item-border":false,"header-mobile-menu-submenu-item-b-size":"1","header-mobile-menu-submenu-item-b-color":"#eaeaea","header-mobile-menu-submenu-border":{"top":2,"bottom":0,"left":0,"right":0},"header-mobile-menu-font-size":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"font-extras-header-mobile-menu":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"woo-header-cart-click-action":"default","woo-slide-in-cart-width":{"desktop":35,"tablet":"","mobile":"","desktop-unit":"%","tablet-unit":"%","mobile-unit":"%"},"woo-header-cart-icon-total-label-position":{"desktop":"","tablet":"","mobile":""},"header-woo-cart-icon-size":{"desktop":"","tablet":"","mobile":""},"woo-header-cart-icon":"default","woo-header-cart-icon-style":"outline","woo-desktop-cart-flyout-direction":"right","header-woo-cart-icon-color":"","transparent-header-woo-cart-icon-color":"","header-woo-cart-icon-hover-color":"","woo-header-cart-border-width":2,"woo-header-cart-icon-radius-fields":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"woo-header-cart-badge-display":true,"woo-header-cart-label-display":"Cart\/{cart_total_currency_symbol}","header-woo-cart-text-color":"","header-woo-cart-link-color":"","header-woo-cart-background-color":{"desktop":"","tablet":"","mobile":""},"header-woo-cart-background-hover-color":{"desktop":"","tablet":"","mobile":""},"header-woo-cart-separator-color":"","header-woo-cart-link-hover-color":"","header-woo-cart-btn-text-color":"","header-woo-cart-btn-background-color":"","header-woo-cart-btn-text-hover-color":"","header-woo-cart-btn-bg-hover-color":"","header-woo-checkout-btn-text-color":"","header-woo-checkout-btn-background-color":"","header-woo-checkout-btn-text-hover-color":"","header-woo-checkout-btn-bg-hover-color":"","edd-header-cart-icon-style":"outline","edd-header-cart-icon-color":"","edd-header-cart-icon-radius":3,"transparent-header-edd-cart-icon-color":"","edd-header-cart-total-display":true,"edd-header-cart-title-display":true,"header-edd-cart-text-color":"","header-edd-cart-link-color":"","header-edd-cart-background-color":"","header-edd-cart-separator-color":"","header-edd-checkout-btn-text-color":"","header-edd-checkout-btn-background-color":"","header-edd-checkout-btn-text-hover-color":"","header-edd-checkout-btn-bg-hover-color":"","header-account-type":"default","header-account-login-style":"icon","header-account-action-type":"link","header-account-link-type":"default","header-account-logout-style":"icon","header-account-logged-out-text":"Log In","header-account-logged-in-text":"My Account","header-account-logout-action":"link","header-account-image-width":{"desktop":"40","tablet":"","mobile":""},"header-account-icon-size":{"desktop":18,"tablet":18,"mobile":18},"header-account-icon-color":"","header-account-login-link":{"url":"","new_tab":false,"link_rel":""},"header-account-logout-link":{"url":"https:\/\/websitedemos.net\/learndash-academy-02\/wp-login.php","new_tab":false,"link_rel":""},"font-size-section-header-account":{"desktop":"","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-account-type-text-color":"","header-account-woo-menu":false,"cloned-component-track":{"header-button":2,"footer-button":2,"header-html":2,"footer-html":2,"header-menu":2,"header-widget":4,"footer-widget":4,"header-social-icons":1,"footer-social-icons":1,"header-divider":0,"footer-divider":0,"removed-items":[]},"blog-single-post-structure":["single-image","single-title-meta"],"blog-single-meta":["comments","category","author"],"button-radius":50,"button-v-padding":16,"button-h-padding":36,"display-site-title":false,"display-site-tagline":0,"site-layout-outside-bg-obj":{"background-color":"#fafafa","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll"},"site-content-layout":"boxed-container","single-page-content-layout":"default","single-post-content-layout":"default","archive-post-content-layout":"default","body-line-height":"","headings-text-transform":"","font-size-entry-title":{"desktop":"22","tablet":"22","mobile":"20","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"font-size-archive-summary-title":{"desktop":40,"tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"learndash-content-layout":"default","breadcrumb-text-transform":"","theme-auto-version":"4.6.3","astra-addon-auto-version":"3.9.1","learndash-distraction-free-learning":false,"learndash-profile-link-enabled":false,"learndash-table-border-radius":5,"woocommerce-content-layout":"plain-container","headings-font-variant":"700","line-height-h1":"1.2","font-size-primary-menu":{"desktop":"15","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"line-height-h2":"1.2","footer-sml-spacing":{"desktop":{"top":"20","right":"","bottom":"20","left":""},"tablet":{"top":"2","right":"","bottom":"2","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"em","mobile-unit":"px"},"font-size-footer-content":{"desktop":"14","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-bg-obj-responsive":{"desktop":{"background-color":"#272c6c","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":""},"tablet":{"background-color":"#272c6c","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":""},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":""}},"mobile-header-toggle-btn-style-color":"#ffffff","primary-menu-color-responsive":{"desktop":"rgba(255,255,255,0.84)","tablet":"#272c6c","mobile":""},"primary-menu-h-color-responsive":{"desktop":"#ffffff","tablet":"#f1653c","mobile":""},"primary-menu-a-color-responsive":{"desktop":"#ffffff","tablet":"#f1653c","mobile":""},"primary-menu-bg-obj-responsive":{"desktop":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":""},"tablet":{"background-color":"#ffffff","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":""},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":""}},"primary-submenu-bg-color-responsive":{"desktop":"","tablet":"#ffffff","mobile":""},"primary-submenu-color-responsive":{"desktop":"#272c6c","tablet":"","mobile":""},"primary-submenu-h-color-responsive":{"desktop":"#272c6c","tablet":"","mobile":""},"shop-quick-view-stick-cart":true,"learndash-profile-link":"\/my-account\/","container-outside-spacing":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"1.5","right":"0","bottom":"1.5","left":"0"},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"em","mobile-unit":"px"},"container-inside-spacing":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"1.5","right":"2.14","bottom":"1.5","left":"2.14"},"mobile":{"top":"1.5","right":"1","bottom":"1.5","left":"1"},"desktop-unit":"px","tablet-unit":"em","mobile-unit":"em"},"ast-single-post-navigation":true,"single-post-inside-spacing":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"header-spacing":{"desktop":{"top":"10","right":"","bottom":"10","left":""},"tablet":{"top":"1","right":"","bottom":"1","left":""},"mobile":{"top":"0.5","right":"","bottom":"1","left":""},"desktop-unit":"px","tablet-unit":"em","mobile-unit":"em"},"above-header-layout":"disabled","above-header-section-1":"","above-header-section-2":"","above-header-text-color-responsive":{"desktop":"rgba(255,255,255,0.8)","tablet":"","mobile":""},"above-header-link-color-responsive":{"desktop":"#ffffff","tablet":"","mobile":""},"above-header-link-h-color-responsive":{"desktop":"#ffffff","tablet":"","mobile":""},"above-header-bg-obj-responsive":{"desktop":{"background-color":"#272c6c","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":""},"tablet":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":""},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":""}},"above-header-spacing":{"desktop":{"top":"5","right":"","bottom":"5","left":""},"tablet":{"top":"0","right":"","bottom":"0","left":""},"mobile":{"top":"0.5","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"em"},"above-header-divider-color":"rgba(255,255,255,0.19)","above-header-menu-color-responsive":{"desktop":"rgba(255,255,255,0.84)","tablet":"","mobile":""},"above-header-menu-h-color-responsive":{"desktop":"#ffffff","tablet":"","mobile":""},"font-weight-primary-menu":"500","learndash-table-heading-color":"","learndash-table-title-color":"","learndash-incomplete-icon-color":"","font-size-learndash-table-heading":{"desktop":"","tablet":"","mobile":"12","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"font-size-learndash-table-content":{"desktop":"","tablet":"","mobile":"12","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"sidebar-widget-title-color":"#272c6c","sidebar-link-color":"#f1653c","sidebar-link-h-color":"#272c6c","font-size-widget-title":{"desktop":"20","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"font-weight-widget-title":"500","font-size-widget-content":{"desktop":"16","tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"font-weight-widget-content":"400","sidebar-text-color":"#3a3a3a","sidebar-bg-obj":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":""},"primary-submenu-a-color-responsive":{"desktop":"","tablet":"","mobile":""},"primary-submenu-spacing":{"desktop":{"top":"1.2","right":"1","bottom":"1.2","left":"1"},"tablet":{"top":"0","right":"20","bottom":"0","left":"30"},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"em","tablet-unit":"px","mobile-unit":"px"},"primary-submenu-h-bg-color-responsive":{"desktop":"rgba(39,44,108,0.05)","tablet":"","mobile":""},"sidebar-outside-spacing":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"1.5","right":"1","bottom":"1.5","left":"1"},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"em","mobile-unit":"px"},"sidebar-inside-spacing":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"primary-menu-spacing":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"0","right":"20","bottom":"0","left":"20"},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"_astra_pb_compatibility_completed":true,"submenu-open-below-header":false,"is_addon_queue_running":true,"is_astra_addon_queue_running":false,"ele-default-color-typo-setting-comp":false,"gtn-full-wide-image-grp-css":false,"gtn-full-wide-grp-cover-css":false,"footer-adv-bg-obj-responsive":{"desktop":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll"},"tablet":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll"},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll"}},"guntenberg-core-blocks-comp-css":false,"guntenberg-media-text-block-padding-css":false,"is-header-footer-builder":true,"header-main-rt-trans-section-button-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"footer-copyright-link-color":"","footer-copyright-link-h-color":"","footer-html-1-color":{"desktop":"#ffffff","tablet":"","mobile":""},"footer-html-1-link-color":{"desktop":"","tablet":"","mobile":""},"footer-html-1-link-h-color":{"desktop":"","tablet":"","mobile":""},"hba-footer-separator":"","hba-footer-top-border-color":"#7a7a7a","header-menu1-submenu-b-color":"#adadad","header-menu1-submenu-color-responsive":{"desktop":"#272c6c","tablet":"","mobile":""},"header-menu1-submenu-bg-color-responsive":{"desktop":"","tablet":"#ffffff","mobile":""},"header-menu1-submenu-h-color-responsive":{"desktop":"#272c6c","tablet":"","mobile":""},"header-menu1-submenu-h-bg-color-responsive":{"desktop":"rgba(39,44,108,0.05)","tablet":"","mobile":""},"header-menu1-submenu-a-color-responsive":{"desktop":"","tablet":"","mobile":""},"header-menu1-submenu-spacing":{"desktop":{"top":"1.2","right":"1","bottom":"1.2","left":"1"},"tablet":{"top":"0","right":"20","bottom":"0","left":"30"},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"em","tablet-unit":"px","mobile-unit":"px"},"mobile-header-menu-label":"","mobile-header-toggle-btn-color":"var(--ast-global-color-2)","mobile-header-toggle-border-color":"#ffffff","v3-option-migration":true,"mobile-header-toggle-btn-bg-color":"var(--ast-global-color-5)","guntenberg-button-pattern-compat-css":false,"can-support-widget-and-editor-fonts":false,"can-remove-logo-max-width-css":false,"transparent-header-default-border":false,"btn-default-padding-updated":false,"support-footer-widget-right-margin":false,"remove-elementor-toc-margin-css":false,"remove-widget-design-options":false,"support-global-color-format":false,"improve-gb-editor-ui":false,"text-transform-button":"","heading-typo-selector":"h1","apply-content-background-fullwidth-layouts":false,"customizer-default-layout-update":false,"woocommerce-single-product-fallback-default":true,"can-update-page-header-compatibility-to-header-builder":true,"can-reflect-cart-color-in-old-header":false,"add-outline-cart-bg-new-header":false,"remove-header-sections-deps-in-new-header":false,"support-swap-mobile-header-sections":false,"sticky-header-default-site-title-tagline-css":false,"shop-button-padding":{"desktop":{"top":"","right":"","bottom":"","left":""},"tablet":{"top":"","right":"","bottom":"","left":""},"mobile":{"top":"","right":"","bottom":"","left":""},"desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"ast-callback-notice-header-transparent-header-logo":"","ast-callback-notice-header-transparent-header-logo-link":"","ast-callback-notice-header-transparent-meta-enabled":"","ast-callback-notice-header-transparent-header-meta-link":"","astra-product-gallery-layout-flag":false,"shop-toolbar-structure":["results","sorting"],"shop-toolbar-structure-with-hiddenset":{"results":true,"filters":false,"sorting":true,"easy_view":false},"astra-old-global-sidebar-default":false,"dynamic-blog-layouts":false,"theme-dynamic-customizer-support":true,"ast-dynamic-single-product-structure":["ast-dynamic-single-product-image","ast-dynamic-single-product-title"],"ast-dynamic-single-product-metadata":["comments","author"],"ast-archive-product-title":false,"ast-single-product-title":false,"ast-dynamic-archive-product-banner-image-type":"none","ast-dynamic-archive-product-banner-custom-bg":{"desktop":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"tablet":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""}},"ast-dynamic-archive-product-title-font-family":"","ast-dynamic-archive-product-title-font-size":{"desktop":40,"tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"ast-dynamic-archive-product-title-font-weight":"","ast-dynamic-archive-product-title-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"ast-dynamic-archive-product-banner-title-color":"","ast-dynamic-archive-product-banner-text-color":"","ast-dynamic-single-product-banner-title-color":"","ast-dynamic-single-product-title-font-family":"","ast-dynamic-single-product-title-font-size":{"desktop":"22","tablet":"22","mobile":"20","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"ast-dynamic-single-product-title-font-weight":"","ast-dynamic-single-product-title-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"ast-dynamic-single-sfwd-courses-structure":["ast-dynamic-single-sfwd-courses-image","ast-dynamic-single-sfwd-courses-title"],"ast-dynamic-single-sfwd-courses-metadata":["comments","author"],"ast-archive-sfwd-courses-title":true,"ast-single-sfwd-courses-title":true,"ast-dynamic-archive-sfwd-courses-banner-image-type":"none","ast-dynamic-archive-sfwd-courses-banner-custom-bg":{"desktop":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"tablet":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""}},"ast-dynamic-archive-sfwd-courses-title-font-family":"","ast-dynamic-archive-sfwd-courses-title-font-size":{"desktop":40,"tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"ast-dynamic-archive-sfwd-courses-title-font-weight":"","ast-dynamic-archive-sfwd-courses-title-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"ast-dynamic-archive-sfwd-courses-banner-title-color":"","ast-dynamic-archive-sfwd-courses-banner-text-color":"","ast-dynamic-single-sfwd-courses-banner-title-color":"","ast-dynamic-single-sfwd-courses-title-font-family":"","ast-dynamic-single-sfwd-courses-title-font-size":{"desktop":"22","tablet":"22","mobile":"20","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"ast-dynamic-single-sfwd-courses-title-font-weight":"","ast-dynamic-single-sfwd-courses-title-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"ast-dynamic-single-sfwd-lessons-structure":["ast-dynamic-single-sfwd-lessons-image","ast-dynamic-single-sfwd-lessons-title"],"ast-dynamic-single-sfwd-lessons-metadata":["comments","author"],"ast-archive-sfwd-lessons-title":true,"ast-single-sfwd-lessons-title":true,"ast-dynamic-archive-sfwd-lessons-banner-image-type":"none","ast-dynamic-archive-sfwd-lessons-banner-custom-bg":{"desktop":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"tablet":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""}},"ast-dynamic-archive-sfwd-lessons-title-font-family":"","ast-dynamic-archive-sfwd-lessons-title-font-size":{"desktop":40,"tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"ast-dynamic-archive-sfwd-lessons-title-font-weight":"","ast-dynamic-archive-sfwd-lessons-title-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"ast-dynamic-archive-sfwd-lessons-banner-title-color":"","ast-dynamic-archive-sfwd-lessons-banner-text-color":"","ast-dynamic-single-sfwd-lessons-banner-title-color":"","ast-dynamic-single-sfwd-lessons-title-font-family":"","ast-dynamic-single-sfwd-lessons-title-font-size":{"desktop":"22","tablet":"22","mobile":"20","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"ast-dynamic-single-sfwd-lessons-title-font-weight":"","ast-dynamic-single-sfwd-lessons-title-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"ast-dynamic-single-sfwd-topic-structure":["ast-dynamic-single-sfwd-topic-image","ast-dynamic-single-sfwd-topic-title"],"ast-dynamic-single-sfwd-topic-metadata":["comments","author"],"ast-archive-sfwd-topic-title":true,"ast-single-sfwd-topic-title":true,"ast-dynamic-archive-sfwd-topic-banner-image-type":"none","ast-dynamic-archive-sfwd-topic-banner-custom-bg":{"desktop":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"tablet":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""}},"ast-dynamic-archive-sfwd-topic-title-font-family":"","ast-dynamic-archive-sfwd-topic-title-font-size":{"desktop":40,"tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"ast-dynamic-archive-sfwd-topic-title-font-weight":"","ast-dynamic-archive-sfwd-topic-title-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"ast-dynamic-archive-sfwd-topic-banner-title-color":"","ast-dynamic-archive-sfwd-topic-banner-text-color":"","ast-dynamic-single-sfwd-topic-banner-title-color":"","ast-dynamic-single-sfwd-topic-title-font-family":"","ast-dynamic-single-sfwd-topic-title-font-size":{"desktop":"22","tablet":"22","mobile":"20","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"ast-dynamic-single-sfwd-topic-title-font-weight":"","ast-dynamic-single-sfwd-topic-title-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"ast-dynamic-single-cartflows_step-structure":["ast-dynamic-single-cartflows_step-image","ast-dynamic-single-cartflows_step-title"],"ast-dynamic-single-cartflows_step-metadata":["comments","author"],"ast-archive-cartflows_step-title":true,"ast-single-cartflows_step-title":true,"ast-dynamic-archive-cartflows_step-banner-image-type":"none","ast-dynamic-archive-cartflows_step-banner-custom-bg":{"desktop":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"tablet":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""}},"ast-dynamic-archive-cartflows_step-title-font-family":"","ast-dynamic-archive-cartflows_step-title-font-size":{"desktop":40,"tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"ast-dynamic-archive-cartflows_step-title-font-weight":"","ast-dynamic-archive-cartflows_step-title-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"ast-dynamic-archive-cartflows_step-banner-title-color":"","ast-dynamic-archive-cartflows_step-banner-text-color":"","ast-dynamic-single-cartflows_step-banner-title-color":"","ast-dynamic-single-cartflows_step-title-font-family":"","ast-dynamic-single-cartflows_step-title-font-size":{"desktop":"22","tablet":"22","mobile":"20","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"ast-dynamic-single-cartflows_step-title-font-weight":"","ast-dynamic-single-cartflows_step-title-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"ast-dynamic-single-astra-sites-structure":["ast-dynamic-single-astra-sites-image","ast-dynamic-single-astra-sites-title"],"ast-dynamic-single-astra-sites-metadata":["comments","author"],"ast-archive-astra-sites-title":true,"ast-single-astra-sites-title":true,"ast-dynamic-archive-astra-sites-banner-image-type":"none","ast-dynamic-archive-astra-sites-banner-custom-bg":{"desktop":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"tablet":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""}},"ast-dynamic-archive-astra-sites-title-font-family":"","ast-dynamic-archive-astra-sites-title-font-size":{"desktop":40,"tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"ast-dynamic-archive-astra-sites-title-font-weight":"","ast-dynamic-archive-astra-sites-title-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"ast-dynamic-archive-astra-sites-banner-title-color":"","ast-dynamic-archive-astra-sites-banner-text-color":"","ast-dynamic-single-astra-sites-banner-title-color":"","ast-dynamic-single-astra-sites-title-font-family":"","ast-dynamic-single-astra-sites-title-font-size":{"desktop":"22","tablet":"22","mobile":"20","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"ast-dynamic-single-astra-sites-title-font-weight":"","ast-dynamic-single-astra-sites-title-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"ast-dynamic-single-site-pages-structure":["ast-dynamic-single-site-pages-image","ast-dynamic-single-site-pages-title"],"ast-dynamic-single-site-pages-metadata":["comments","author"],"ast-archive-site-pages-title":true,"ast-single-site-pages-title":true,"ast-dynamic-archive-site-pages-banner-image-type":"none","ast-dynamic-archive-site-pages-banner-custom-bg":{"desktop":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"tablet":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""}},"ast-dynamic-archive-site-pages-title-font-family":"","ast-dynamic-archive-site-pages-title-font-size":{"desktop":40,"tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"ast-dynamic-archive-site-pages-title-font-weight":"","ast-dynamic-archive-site-pages-title-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"ast-dynamic-archive-site-pages-banner-title-color":"","ast-dynamic-archive-site-pages-banner-text-color":"","ast-dynamic-single-site-pages-banner-title-color":"","ast-dynamic-single-site-pages-title-font-family":"","ast-dynamic-single-site-pages-title-font-size":{"desktop":"22","tablet":"22","mobile":"20","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"ast-dynamic-single-site-pages-title-font-weight":"","ast-dynamic-single-site-pages-title-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"ast-dynamic-single-astra-blocks-structure":["ast-dynamic-single-astra-blocks-image","ast-dynamic-single-astra-blocks-title"],"ast-dynamic-single-astra-blocks-metadata":["comments","author"],"ast-archive-astra-blocks-title":true,"ast-single-astra-blocks-title":true,"ast-dynamic-archive-astra-blocks-banner-image-type":"none","ast-dynamic-archive-astra-blocks-banner-custom-bg":{"desktop":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"tablet":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""}},"ast-dynamic-archive-astra-blocks-title-font-family":"","ast-dynamic-archive-astra-blocks-title-font-size":{"desktop":40,"tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"ast-dynamic-archive-astra-blocks-title-font-weight":"","ast-dynamic-archive-astra-blocks-title-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"ast-dynamic-archive-astra-blocks-banner-title-color":"","ast-dynamic-archive-astra-blocks-banner-text-color":"","ast-dynamic-single-astra-blocks-banner-title-color":"","ast-dynamic-single-astra-blocks-title-font-family":"","ast-dynamic-single-astra-blocks-title-font-size":{"desktop":"22","tablet":"22","mobile":"20","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"ast-dynamic-single-astra-blocks-title-font-weight":"","ast-dynamic-single-astra-blocks-title-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"ast-dynamic-single-post-structure":["ast-dynamic-single-post-image","ast-dynamic-single-post-title","ast-dynamic-single-post-meta"],"ast-dynamic-single-post-taxonomy":"category","ast-archive-post-title":true,"ast-single-post-title":true,"ast-dynamic-archive-post-banner-image-type":"none","ast-dynamic-archive-post-banner-custom-bg":{"desktop":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"tablet":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""}},"ast-dynamic-archive-post-title-font-family":"","ast-dynamic-archive-post-title-font-size":{"desktop":40,"tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"ast-dynamic-archive-post-title-font-weight":"","ast-dynamic-archive-post-title-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"ast-dynamic-archive-post-banner-title-color":"","ast-dynamic-archive-post-banner-text-color":"","ast-dynamic-single-post-banner-title-color":"","ast-dynamic-single-post-title-font-family":"","ast-dynamic-single-post-title-font-size":{"desktop":"22","tablet":"22","mobile":"20","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"ast-dynamic-single-post-title-font-weight":"","ast-dynamic-single-post-title-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"ast-dynamic-single-page-structure":["ast-dynamic-single-page-title"],"ast-dynamic-single-page-metadata":["comments","author"],"ast-archive-page-title":true,"ast-single-page-title":true,"ast-dynamic-archive-page-banner-image-type":"none","ast-dynamic-archive-page-banner-custom-bg":{"desktop":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"tablet":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""},"mobile":{"background-color":"","background-image":"","background-repeat":"repeat","background-position":"center center","background-size":"auto","background-attachment":"scroll","background-type":"","background-media":"","overlay-type":"","overlay-color":"","overlay-gradient":""}},"ast-dynamic-archive-page-title-font-family":"","ast-dynamic-archive-page-title-font-size":{"desktop":40,"tablet":"","mobile":"","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"ast-dynamic-archive-page-title-font-weight":"","ast-dynamic-archive-page-title-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"ast-dynamic-archive-page-banner-title-color":"","ast-dynamic-archive-page-banner-text-color":"","ast-dynamic-single-page-banner-title-color":"","ast-dynamic-single-page-title-font-family":"","ast-dynamic-single-page-title-font-size":{"desktop":"22","tablet":"22","mobile":"20","desktop-unit":"px","tablet-unit":"px","mobile-unit":"px"},"ast-dynamic-single-page-title-font-weight":"","ast-dynamic-single-page-title-font-extras":{"line-height":"","line-height-unit":"em","letter-spacing":"","letter-spacing-unit":"px","text-transform":"","text-decoration":""},"archive-download-content-layout":"default","archive-download-sidebar-layout":"no-sidebar","single-download-content-layout":"default","single-download-sidebar-layout":"default","update-default-color-typo":false,"v4-block-editor-compat":false,"v4-1-0-update-migration":true,"v4-1-4-update-migration":true,"list-block-vertical-spacing":false,"add-hr-styling-css":false,"astra-site-svg-logo-equal-height":false,"archive-post-content-style":"default","learndash-content-style":"default","learndash-sidebar-style":"default","fullwidth_sidebar_support":false,"v4-2-0-update-migration":true,"v4-2-2-core-form-btns-styling":false,"v4-4-0-backward-option":false,"ast-dynamic-single-product-article-featured-image-position-layout-1":"none","ast-dynamic-single-product-article-featured-image-position-layout-2":"none","ast-dynamic-single-product-article-featured-image-ratio-type":"default","ast-dynamic-single-sfwd-courses-article-featured-image-position-layout-1":"none","ast-dynamic-single-sfwd-courses-article-featured-image-position-layout-2":"none","ast-dynamic-single-sfwd-courses-article-featured-image-ratio-type":"default","ast-dynamic-single-sfwd-lessons-article-featured-image-position-layout-1":"none","ast-dynamic-single-sfwd-lessons-article-featured-image-position-layout-2":"none","ast-dynamic-single-sfwd-lessons-article-featured-image-ratio-type":"default","ast-dynamic-single-sfwd-topic-article-featured-image-position-layout-1":"none","ast-dynamic-single-sfwd-topic-article-featured-image-position-layout-2":"none","ast-dynamic-single-sfwd-topic-article-featured-image-ratio-type":"default","ast-dynamic-single-templates-article-featured-image-position-layout-1":"none","ast-dynamic-single-templates-article-featured-image-position-layout-2":"none","ast-dynamic-single-templates-article-featured-image-ratio-type":"default","ast-dynamic-single-cartflows_step-article-featured-image-position-layout-1":"none","ast-dynamic-single-cartflows_step-article-featured-image-position-layout-2":"none","ast-dynamic-single-cartflows_step-article-featured-image-ratio-type":"default","ast-dynamic-single-astra-sites-article-featured-image-position-layout-1":"none","ast-dynamic-single-astra-sites-article-featured-image-position-layout-2":"none","ast-dynamic-single-astra-sites-article-featured-image-ratio-type":"default","ast-dynamic-single-site-pages-article-featured-image-position-layout-1":"none","ast-dynamic-single-site-pages-article-featured-image-position-layout-2":"none","ast-dynamic-single-site-pages-article-featured-image-ratio-type":"default","ast-dynamic-single-astra-blocks-article-featured-image-position-layout-1":"none","ast-dynamic-single-astra-blocks-article-featured-image-position-layout-2":"none","ast-dynamic-single-astra-blocks-article-featured-image-ratio-type":"default","ast-dynamic-single-post-article-featured-image-position-layout-1":"none","ast-dynamic-single-post-article-featured-image-position-layout-2":"none","ast-dynamic-single-post-article-featured-image-ratio-type":"default","ast-dynamic-single-page-article-featured-image-position-layout-1":"none","ast-dynamic-single-page-article-featured-image-position-layout-2":"none","ast-dynamic-single-page-article-featured-image-ratio-type":"default","v4-5-0-backward-option":false,"is_theme_queue_running":false,"scndry-btn-default-padding":false,"v4-6-0-backward-option":false,"ast-font-style-update":false,"v4-6-2-backward-option":false},"custom-css":""}};
</script>
<script id="showcase-cta-js-js-after">
( window.self !== window.top ) || document.write( '<script src="https://websitedemos.net/learndash-academy-02/wp-content/plugins/astra-sites-server/admin/showcase-cta/switcher/dist/main.js?ver=308d53dc52d1fcf8ca1e"></scr' + 'ipt>' );
</script>
<script src="https://websitedemos.net/learndash-academy-02/wp-content/plugins/elementor/assets/js/webpack.runtime.js?ver=3.19.1" id="elementor-webpack-runtime-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-content/plugins/elementor/assets/js/frontend-modules.js?ver=3.19.1" id="elementor-frontend-modules-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.js?ver=4.0.2" id="elementor-waypoints-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/jquery/ui/core.js?ver=1.13.2" id="jquery-ui-core-js"></script>
<script id="elementor-frontend-js-before">
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":true},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","download":"Download","downloadImage":"Download image","fullscreen":"Fullscreen","zoom":"Zoom","share":"Share","playVideo":"Play Video","previous":"Previous","next":"Next","close":"Close","a11yCarouselWrapperAriaLabel":"Carousel | Horizontal scrolling: Arrow Left & Right","a11yCarouselPrevSlideMessage":"Previous slide","a11yCarouselNextSlideMessage":"Next slide","a11yCarouselFirstSlideMessage":"This is the first slide","a11yCarouselLastSlideMessage":"This is the last slide","a11yCarouselPaginationBulletMessage":"Go to slide"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"Mobile Portrait","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Landscape","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet Portrait","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Landscape","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}}},"version":"3.19.1","is_static":false,"experimentalFeatures":{"e_optimized_assets_loading":true,"additional_custom_breakpoints":true,"container":true,"block_editor_assets_optimize":true,"ai-layout":true,"landing-pages":true,"e_image_loading_optimization":true,"e_global_styleguide":true},"urls":{"assets":"https:\/\/websitedemos.net\/learndash-academy-02\/wp-content\/plugins\/elementor\/assets\/"},"swiperClass":"swiper-container","settings":{"page":[],"editorPreferences":[]},"kit":{"global_image_lightbox":"yes","active_breakpoints":["viewport_mobile","viewport_tablet"],"lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":17,"title":"Home%20-%20LearnDash%20Academy","excerpt":"","featuredImage":false}};
</script>
<script src="https://websitedemos.net/learndash-academy-02/wp-content/plugins/elementor/assets/js/frontend.js?ver=3.19.1" id="elementor-frontend-js"></script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/underscore.min.js?ver=1.13.4" id="underscore-js"></script>
<script id="wp-util-js-extra">
var _wpUtilSettings = {"ajax":{"url":"\/learndash-academy-02\/wp-admin\/admin-ajax.php"}};
</script>
<script src="https://websitedemos.net/learndash-academy-02/wp-includes/js/wp-util.js?ver=6.4.3" id="wp-util-js"></script>
<script id="wpforms-elementor-js-extra">
var wpformsElementorVars = {"captcha_provider":"recaptcha","recaptcha_type":"v2"};
</script>
<script src="https://websitedemos.net/learndash-academy-02/wp-content/plugins/wpforms-lite/assets/js/integrations/elementor/frontend.min.js?ver=1.8.6.4" id="wpforms-elementor-js"></script>
<script>
			/(trident|msie)/i.test(navigator.userAgent)&&document.getElementById&&window.addEventListener&&window.addEventListener("hashchange",function(){var t,e=location.hash.substring(1);/^[A-z0-9_-]+$/.test(e)&&(t=document.getElementById(e))&&(/^(?:a|select|input|button|textarea)$/i.test(t.tagName)||(t.tabIndex=-1),t.focus())},!1);
			</script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v84a3a4012de94ce1a686ba8c167c359c1696973893317" integrity="sha512-euoFGowhlaLqXsPWQ48qSkBSCFs3DPRyiwVu3FjR96cMPx+Fr+gpWRhIafcHwqwCqWS42RZhIudOvEI+Ckf6MA==" data-cf-beacon='{"rayId":"853c29a65beb8549","version":"2024.2.0","token":"974d812d4f9e465096df037cad7ee20d"}' crossorigin="anonymous"></script>
</body>
</html>
